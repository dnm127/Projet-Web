
$(document).ready(function(){

    //show hide pwd
    $('#form_pwd').attr('type','password');
    $('#showhide').click(function(){
        $('#form_pwd').attr('type',$(this).is(':checked')? 'text' : 'password');
        $('#userpwd').attr('type',$(this).is(':checked')? 'text' : 'password');
    });

    //Change button text
    $("#form_signup").text("S'inscrire");
    $("#form_login").text("Se connecter");
    $("#form_upload").text("Déposer");
    $("#form_more").text("+");
    $("#form_choose").text("Valider");

    // //get thumbnail
    // var str = document.getElementById("thumbnail0").getAttribute("src");
    // var s = str.replace("https://www.youtube.com/watch?v=", "");
    // var newstring ='http://img.youtube.com/vi/'+s+'/0.jpg';
    // document.getElementById("thumbnail0").setAttribute("src",newstring);
    //

    //********Content-home*********

    //Show more categories
    var i, j, k;
    i = $('.showmore')[3];
    j = $('.showmore')[4];
    k = $('.showmore')[5];

    $(i).hide();
    $(j).hide();
    $(k).hide();
    var show_index = 3;
    $('#btnmore').click(function () {
        if (show_index<=5) $($('.showmore')[show_index++]).show();
        if (show_index > 5) $('#btnmore').hide();
    });

    //Filter by cate
    var check =  $("#catefilter").find("input");
    $(check).click(function () {
        var i;
        for (i=0; i<check.length; i++) {
            if (check[i] !== this ) {
                check[i].disabled = true;
            }
        }
    });

    $('#annulercate').click(function () {
        for (var i=0; i<check.length; i++) {
            check[i].checked = false;
            check[i].disabled= false;
        }
    });

    var radio = $(".form-radio").find("input");
    $(radio).click(function () {
        var i;
        for (i=0; i<radio.length; i++) {
            if (radio[i] !== this ) {
                radio[i].disabled = true;
            }
        }
    });
    $('#annuler').click(function () {
        var i;
        for (i=0; i<radio.length; i++) {
            radio[i].checked = false;
            radio[i].disabled= false;
        }
    });

    //********Content video**********

    //Break line for each step
    var text = $('#instruction').text();
    var result = text.replace(/<br>/g, '\n \n');
    $('#instruction').text(result);

    //Print instruction
    $('#printbtn').click(function () {
        // // open in new window and modify new window
        var mywindow = window.open('_target');
        mywindow.document.write('<html><head><title>' + document.title  + '</title></head><body>');
        mywindow.document.write('<p style="font-family: Futura; background-color: rgb(254,207,101); ;text-align: center; font-size: 43px ;padding-top: 20px ;padding-bottom: 20px; margin-top: 0px;color: rgb(44,59,77);">' + document.getElementById('titre').innerHTML + '</p>');
        mywindow.document.write('<h5 style="font-weight: normal ;font-family: Verdana; margin-left: 20px;">Par ' + '<strong>'+document.getElementById("user").innerHTML +'</strong>' + " à" + document.getElementById('date').innerHTML +'</h5></br>');
        mywindow.document.write('<h4 style="font-family: Futura; margin-left: 35px; font-weight: normal; margin-bottom: 30px;margin-top: 0px ;white-space: pre-line;">'+ $('#instruction').text() +'</h4>');
        mywindow.document.write('<footer style="position: absolute; right: 0; bottom: 0; left: 0 ;text-align: center; font-family: Futura; font-weight: bold; background-color: rgb(254,207,101); padding-top: 20px; padding-bottom: 20px ; color: rgb(44,59,77);">Goûter</footer>')
        mywindow.document.write('</body></html>');
        mywindow.print();
        mywindow.close();
        return true;
    });

    //*****************************

    //**********User page**********

        if ($('#usrintro').text().length > 160 ) {
            let str = $('#usrintro').text().substr(0, 255);
            $('#usrintro').text(str);
        }

    //********** UPLOAD PAGE ***********
    $('#form_upload').click(function () {
        var str = document.getElementById('form_instruction').value;
        // var etape = str.replace(/(?:\r\n|\r|\n)/g, '<br>');
        document.getElementById('form_instruction').value = str.replace(/(?:\r\n|\r|\n)/g, '<br>');
    });

    //************ Upload form **************
    $('#form_user').hide();

});

//Animation neon light Goûter
var c = 0;
function myCounter() {
    // document.getElementById("banner").innerHTML = ++c;
    if (c%2 === 0){
        document.getElementById('banner').setAttribute('style',' font-family: Pacifico; color: white; font-size: 100px; text-align: center; margin-bottom: 25px; letter-spacing: 4px; text-shadow: 0 0 3px #FFFF33, 0 0 5px #FFFF33 ;');
    }
    else document.getElementById('banner').setAttribute('style', 'font-family: Pacifico; color: white; font-size: 100px; text-align: center; margin-bottom: 25px; letter-spacing: 4px; text-shadow: 2px 2px 8px transparent;');
    c++;
}

