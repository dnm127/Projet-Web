$(document).ready(function () {
    $('#videos').css('display','block');
    $('#default').addClass ('active');
    
    $('#liste').click(function () {
        $('#videos').css('display','none');
        $('#default').removeClass('active');

        $('#liste').addClass('active');
        $('#playlists').css('display','block')
    });

    $('#default').click(function () {
        $('#videos').css('display','block');
        $('#default').addClass ('active');

        $('#liste').removeClass('active');
        $('#playlists').css('display','none');
    });

    // Text limit
    $('#usrintro').click(function () {
        document.getElementById('notice').innerHTML = '<div class="alert alert-info" style="margin-top: 15px"> <strong>100 mots maximum</strong></div>';
        setTimeout(function(){
            var x = document.getElementById("notice");
            // x.remove();
            x.innerHTML = "<div id='notice'></div>";
        }, 3000);
    });

    //Profile setting
    $('#form_text').hide();
    $('#form_text').maxLength=255;
    $('#form_save').hide();
    $('#form_save').attr('type','submit');
    $('#form_save').wrapInner('<i class="glyphicon glyphicon-floppy-disk"></i>')
    $('#form_save').text('Enregistrer');

    //About me
    var i=0;
    var stock = $('#usrintro').text();
    $('#changeabout').click(function () {
        if(i % 2 === 0) {
            document.getElementById('changeabout').innerHTML = 'Annuler';
            $('#form_text').show();
            $('#form_save').show();
            i++;
            console.log(i);
            return;
        }
        if(i % 2 !== 0){
            document.getElementById('changeabout').innerHTML ='<span class="glyphicon glyphicon-wrench"></span>';
            $('#form_text').hide();
            $('#form_save').hide();
            $('#usrintro').text(stock);
            i++;
            return;
        }
    });

});
