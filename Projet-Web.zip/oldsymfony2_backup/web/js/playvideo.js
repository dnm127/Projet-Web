$(document).ready(function () {

    //Like button
    $('#form_likebtn').attr('type','submit');
    $('.like').wrapInner('<i id="coeur" class="glyphicon glyphicon-heart-empty"></i>');
    $('.unlike').wrapInner('<i id="coeur" class="glyphicon glyphicon-heart"></i>');
    $('#coeur').text("");

    //Flash-notice
    setTimeout(function(){$('.flash-notice').hide();}, 3000);

});