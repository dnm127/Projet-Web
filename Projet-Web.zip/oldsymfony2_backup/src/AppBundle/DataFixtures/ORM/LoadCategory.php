<?php
// src/AppBundle/DataFixtures/ORM/LoadCategory.php
namespace AppBundle\DataFixtures\ORM;

use Doctrine\Bundle\FixturesBundle\ORMFixtureInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Persistence\ObjectManager;
use Projet\MainBundle\Entity\Category;

class LoadCategory implements ORMFixtureInterface {
    public function load(ObjectManager $manager){
        $namesCate = new ArrayCollection(array(
            'Entrée',
            'Plat',
            'Dessert',
            'Boisson',
            'Soupe',
            'Sauce'
        ));
        foreach ($namesCate as $name) {
            // create new video from $id
            $cate = new Category();
            $cate->setName($name);
            // add to DB
            $manager->persist($cate);
        }
        $manager->flush();
    }

}

