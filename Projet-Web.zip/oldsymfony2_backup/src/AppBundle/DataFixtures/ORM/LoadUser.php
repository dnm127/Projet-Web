<?php
// src/AppBundle/DataFixtures/ORM/LoadUser.php
namespace AppBundle\DataFixtures\ORM;

use Doctrine\Bundle\FixturesBundle\ORMFixtureInterface;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Tests\Common\DataFixtures\TestEntity\User;
use Projet\MainBundle\Entity\Category;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class LoadUser extends AbstractFixture implements ORMFixtureInterface, ContainerAwareInterface {
    /**
     * @var ContainerInterface
     */
    private $container;

    public function setContainer(ContainerInterface $container = null) {
        $this->container = $container;
    }

    public function load(ObjectManager $manager){
        $UserManager = $this->container->get('fos_user.user_manager');
        $nhatminh = $UserManager->CreateUser();
        $nhatminh->setUsername('nhatminh');
        $nhatminh->setEmail('nhatminh@admin.com');
        $nhatminh->setPlainPassword('nhatminhpass');
        $nhatminh->setEnabled(true);
        $nhatminh->addRole('ROLE_SUPER_ADMIN');
        $nhatminh->setAbout('Super Founder of Gouter');
        $UserManager->updateUser($nhatminh);

        $admin = $UserManager->CreateUser();
        $admin->setUsername('admin');
        $admin->setEmail('admin@admin.com');
        $admin->setPlainPassword('adminhpass!');
        $admin->setEnabled(1);
        $admin->addRole('ROLE_SUPER_ADMIN');
        $admin->setAbout('Admin of Gouter!');
        $UserManager->updateUser($admin);

    }


}

