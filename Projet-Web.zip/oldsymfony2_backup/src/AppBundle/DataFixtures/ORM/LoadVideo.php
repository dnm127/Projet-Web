<?php
// src/AppBundle/DataFixtures/ORM/LoadVideo.php
namespace AppBundle\DataFixtures\ORM;

use Doctrine\Bundle\FixturesBundle\ORMFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\Collections\ArrayCollection;
use Projet\MainBundle\Entity\Video;

class LoadVideo implements ORMFixtureInterface {
   public function load(ObjectManager $manager){
      $list_id = new ArrayCollection(array(
         'uKoCArmHD7Y',
         '03_EDK9Sn_E',
         'LYX7CnSiBSM',
         '4GVgZmzEme4',
         'SekXLtW28W8',
         'GB-sBrPllKY',
         'OadEthwrxPk',
         '07ICf3UfhkI',
         'li7M7RBJP_M',
         'u24ZJqeGa0I',
         '3lxBpyYWUKg',
         'y1vm2pncEwQ',
         'lWl3KHCO6vg',
         'SZNLVpAC0NU',
         '8NwGT2Pb7_E',
         'YuDhbLQtt2k',
         'RKPBw7CwQsY',
         'SrT0isLA64I',
         '8VT-ntw-B_U',
         '8S-SbF55wRg',
         'zq6z-yv1ZVA',
         'rFc_mJlTm3E',
         'Xu7SBqblppQ',
         '0zMpkN0mNJo',
         'jQVMNHWhWhM',
         'd5nCbSNS9mA',
         'o5qr9PFOv8w',
         'nZ8RGWo0wwQ',
         'kGrTcdL_PcA',
         'LNuarCw8c8Y',
         'U17EhiH2L8Q',
         'cs1CbiYuCoo',
         'qaVby8aD8Zo',
         'vXBzaDQTzgs',
         'Ox4fw23gKts',
         'hVseiV8rbUw',
//          ========
         'yXNK7NvXQLQ',
          'XtMYj1EazBw',
          'kahYOB7kkjg',
          'k9Vz7kNIqI8',
          'TF2D-zrIW3g',
          'eOWxsR2r3PY',
          'cPYXqBaqUgU',
          'OUQr8lG45AU',
          'WiftqgijmYY',
          'Xu7SBqblppQ',
          'vvR1pde64ZA',
          '6A6-nhrl74k'
      ));

       // $categories ~ array contains all categories existed in DB
       $index = 0;
       $categories = $manager ->getRepository('ProjetMainBundle:Category')->findAll();
       // $author is nhatminh & admin for all
        $nhatminh = $manager ->getRepository('ProjetUserBundle:User')->findOneBy(array('username'=>'nhatminh'));
       $admin = $manager ->getRepository('ProjetUserBundle:User')->findOneBy(array('username'=>'admin'));


       foreach ($list_id as $id) { // 48 videos in total
         // create new video from $id
         $video = new Video();
         $video->setTitle('Recette Exemple '.$list_id->indexOf($id));
         $video->setSrc('https://www.youtube.com/embed/'.$id);
         $video->setThumb('https://img.youtube.com/vi/'.$id.'/hqdefault.jpg');

         // add Categories
         // each category have 8 vids
         $index_category = intdiv($list_id->indexOf($id),8); // add category $categories[$index_category] to video w/ $id
         $video->addCategory($categories[$index_category]);
         // add Author
         if ($list_id->indexOf($id) < 24) {
             $video->setAuthor($nhatminh);
             $br = '<br>';
             $video->setEtape("Étape 1: Cook.".$br."Étape 2: Eat.".$br."Étape 3: Clean.");
         }
         else {
             $video->setAuthor($admin);
             $br = '<br>';
             $video->setEtape("Étape 1: Cook.".$br."Étape 2: Eat.".$br."Étape 3: Clean.");
         }
         // Add Etape

         // add to DB
         $manager->persist($video);
         $index++;
      }

      // vi du


      $manager->flush();
   }


}
