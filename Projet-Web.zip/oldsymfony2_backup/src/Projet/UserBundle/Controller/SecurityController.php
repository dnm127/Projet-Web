<?php
// src/OC/UserBundle/Controller/SecurityController.php;

namespace Projet\UserBundle\Controller;

use Doctrine\Common\Collections\ArrayCollection;
use Projet\UserBundle\Entity\User;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Button;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Response;

class SecurityController extends Controller {
    public function signupAction(Request $request){
        $form = $this->createFormBuilder()
            ->add('name', TextType::class)
            ->add('mail', TextType::class)
            ->add('pwd', PasswordType::class)
            ->add('signup', SubmitType::class)
            ->getForm();

        // Si la requête est en POST
        if ($request->isMethod('POST')) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $data = $form->getData();
                //setup new user
//                $user = new User(); $user->set
                $userManager = $this->get('fos_user.user_manager');
                $user = $userManager->createUser();
                $user->setUsername($data['name']);
                $user->setEmail($data['mail']);
                $user->setEnabled(1);
                $user->setPlainPassword($data['pwd']);
                // test $user validity
                $test = $this->get('validator');
                $flags = $test->validate($user);
                // generate user response
                $message='';
                if (count($flags)>0) {
                    foreach ($flags as $flag) {
                        if (strpos($flag,'duplicate username') != false) { $message = 'Ce Nom est déjà utilisé.'; }
                        elseif (strpos($flag,'duplicate email') != false) { $message = 'Ce Mail est déjà utilisé.'; }
                        $this->addFlash('notice',$message);
                        $message = '';
                    }
                    return $this->render('ProjetUserBundle:Security:signup.html.twig',array('form' => $form->createView()));
                } else {
                    ///add to Database
                    $userManager->updateUser($user);
                    $this->addFlash('notice','Succes');
                    return $this->render('ProjetUserBundle:Security:signup.html.twig',array('form'=>$form->createView()));
                }
            }
        }

        $content = $this->get('templating')->render('ProjetUserBundle:Security:signup.html.twig',array(
            'form' => $form->createView()
        ));
        return new Response($content);
    }

    public function loginAction(Request $request)
   {
      if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
          // once logged in
         return $this->redirectToRoute('projet_main_homepage');
      }
      else {
          $this->addFlash(
              'notice',
              "Veuillez vous connecter !"
          );
      }

      $authenticationUtils = $this->get('security.authentication_utils');

       $connect = $this->createFormBuilder()
           ->add('mail', TextType::class)
           ->add('pwd', PasswordType::class)
           ->add('login', SubmitType::class)
           ->getForm();

       return $this->render('ProjetUserBundle:Security:login.html.twig', array(
            'last_username' => $authenticationUtils->getLastUsername(),
            'error'        => $authenticationUtils->getLastAuthenticationError(),
            'connect'      => $connect->createView(),
        ));
   }

   public function login_checkAction(Request $request ){
        return $this->render('ProjetUserBundle:Security:login_check.html.twig');
   }

   public function profileAction($username, Request $request){
       $user = $this->get('fos_user.user_manager')->findUserByUsername($username);

       $videos = $this
           ->getDoctrine()
           ->getManager()
           ->getRepository('ProjetMainBundle:Video');

       $about = $this->createFormBuilder()
           ->add('text',TextareaType::class)
           ->add('save',ButtonType::class)
           ->getForm();

       if ($request->isMethod('POST')){
           $about->handleRequest($request);
           if ($about->isValid()) {
               $data = $about->getData();
               $token = $this->get('security.token_storage')->getToken();
               if ($token == null) throw new Exception('$toekn is null');
               $user = $token->getUser();
               $user->setAbout($data['text']);

               $em = $this->getDoctrine()->getManager();
               $em->persist($user);
               $em->flush();
           }
       }

       $listVideo = $videos->findAll(); //all videos in DB - array of video ( video :object )
       $uploadedVideos = new ArrayCollection(); // array of video
       foreach ($listVideo as $video){
           if ($video->getAuthor()->getId() == $user->getId()) $uploadedVideos->add($video);
       }

       return $this->render('ProjetUserBundle:Security:content_user.html.twig',array(
           'user' => $user,
           'uploadedVideos' => $uploadedVideos,
           'about'=>$about->createView(),
       ));
   }
}

