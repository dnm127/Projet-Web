<?php
/**
 * Created by PhpStorm.
 * User: dang
 * Date: 1/6/18
 * Time: 12:46
 */

namespace Projet\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use FOS\UserBundle\Model\User as BaseUser;
use Projet\MainBundle\Entity\Video;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * @ORM\Entity(repositoryClass="Projet\UserBundle\Entity\UserRepository")
 * @ORM\Table(name="user")
 * @UniqueEntity("username",message="duplicate username")
 * @UniqueEntity("email",message="duplicate email")
 */
class User extends BaseUser{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(name="id", type="integer")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $about;

    // getter & setter
    public function __construct(){
        parent::__construct();
        $this->likedVideos = new ArrayCollection();
    }

    public function getId() {return $this->id;}

    public function getAbout(){ return $this->about;}
    public function setAbout($about) {$this->about = $about;}

    //TODO ver 2: like video
    /**
     * @ORM\ManyToMany(targetEntity="Projet\MainBundle\Entity\Video", cascade={"persist"})
     * @ORM\JoinTable(name="liked_video")
     */
    private $likedVideos;

    public function getLikedVideos()
    {
        return $this->likedVideos;
    }

    public function addLikedVideo(Video $likedVideo)
    {
        $this->likedVideos[] = $likedVideo;
    }

    public function removeLikedVideo(Video $likedvideo)
    {
        $this->likedVideos->removeElement($likedvideo);
    }

    public function haveLikedVideo(Video $likedVideo) {
        return $this->likedVideos->contains($likedVideo);
    }

}
