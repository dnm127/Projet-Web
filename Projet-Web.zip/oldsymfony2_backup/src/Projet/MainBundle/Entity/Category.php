<?php

namespace Projet\MainBundle\Entity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="category")
 * @ORM\Entity(repositoryClass="Projet\MainBundle\Entity\CategoryReposiory")
 */
class Category {
   /**
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
   private $id;

   /**
    * @ORM\Column(name="name", type="string", length=255)
    */
   private $name;
   /*
    * get & set & constructor
    * TODO ver 1 here
    */
   public function getId(){ return $this->id; }
   public function getName(){ return $this->name; }

   public function setName($name) { $this->name = $name; }
   /*==============================================*/
   /*
    * relations w/ other classes
    */

}
