<?php

namespace Projet\MainBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Projet\UserBundle\Entity\User;



/**
 * @ORM\Table(name="video")
 * @ORM\Entity(repositoryClass="Projet\MainBundle\Entity\VideoRepository")
 */
class Video
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(name="date", type="date")
     */
    private $date;

    /**
     * @ORM\Column(name="title", type="string", length=255)
     */
    private $title;

    /**
     * @ORM\Column(name="src", type="string", length=255)
     */
    private $src;

    /**
     * @ORM\Column(name="thumb", type="string", length=255)
     */
    private $thumb;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $etape;


    /*
     * get $ set & constructor
     * TODO Video ver 1
     */
    public function __construct()
    {
        $this->date = new \DateTime();
        $this->categories = new ArrayCollection();
        $this->hearts = 0;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }

    public function getSrc()
    {
        return $this->src;
    }

    public function setSrc($src)
    {
        $this->src = $src;
    }

    public function getThumb()
    {
        return $this->thumb;
    }

    public function setThumb($thumb)
    {
        $this->thumb = $thumb;
    }

    public function getEtape()
    {
        return $this->etape;
    }

    public function setEtape($etape = null)
    {
        $this->etape = $etape;
    }

    public function getDate()
    {
        return $this->date;
    }

    /*==================================*/
    /*
     * relations w/ other classes
     * TODO Video ver 2
     */
    /**
     * @ORM\ManyToMany(targetEntity="Projet\MainBundle\Entity\Category", cascade={"persist"})
     * @ORM\JoinTable(name="video_category")
     */
    private $categories;

    public function getCategories()
    {
        return $this->categories;
    }

    public function addCategory(Category $category)
    {
        $this->categories[] = $category;
    }

    public function removeCategory(Category $category)
    {
        $this->categories->removeElement($category);
    }

    public function haveCategory(Category $category) {
        return $this->categories->contains($category);
    }
    /*==================================*/
    /*
     */

    /*==================================*/

//   TODO Video ver 3: with User

    /**
     * @ORM\ManyToOne(targetEntity="Projet\UserBundle\Entity\User")
     * @ORM\JoinColumn(nullable=false)
     */
    private $author;

    public function getAuthor() { return $this->author; }
    public function setAuthor(User $author) { $this->author = $author; }
    /*==================================*/

    //TODO ver 4: like video
    /**
     * @ORM\Column(name="hearts", type="integer", nullable=true)
     */
    private $hearts;

    public function getHearts(){return $this->hearts;}
    public function setHearts($hearts){$this->hearts = $hearts;}
    public function likePlus(){ $this->hearts++; }
    public function likeMinus(){ $this->hearts--; }

}
