<?php

namespace Projet\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProjetMainBundle extends Bundle
{
}
