<?php
// src/Projet/MainBundle/Controller/MainController.php

namespace Projet\MainBundle\Controller;

use Projet\MainBundle\Entity\Category;
use Projet\MainBundle\Entity\Video;
use Projet\UserBundle\Entity\User;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\Form\Extension\Core\Type\RadioType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;


class MainController extends Controller {
    public function indexAction() {
        // Init
        $em = $this->getDoctrine()->getManager();
        $listVideos = new ArrayCollection(); // video list by category
        $maxCate = 6;
        // $arrayVideos contains (all) videos in the database
        $arrayVideos = $em   ->getRepository('ProjetMainBundle:Video')
            ->findAll();
        // Build $listCate
        $listCate = $em->getRepository('ProjetMainBundle:Category')->findAll();
        // Build $listVideos
        for($index = 0;$index<$maxCate;++$index) {
            // create $listVideos[$index]
            $newList = new ArrayCollection();
            foreach ($arrayVideos as $video) {
                if ($video->haveCategory($listCate[$index])) $newList->add($video);
            }
            $listVideos->add($newList); // $listVideos[$index] is all the videos of $listCate[$index] category type
        }
        // return
        $content = $this->get('templating')->render('ProjetMainBundle:Main:index.html.twig',array(
            'listVideos' => $listVideos,
            'listCate' => $listCate,
        ));
        return new Response($content);
    }

    public function show_videoAction($id, Request $request){

//========== ID ===============
//=============================
        // Get video by $id
        $em = $this->getDoctrine()->getManager();
        $video = $em->getRepository('ProjetMainBundle:Video')->find($id);
        $categories = $video->getCategories();
        $namesCate = new ArrayCollection();

        $allvids = $em->getRepository('ProjetMainBundle:Video')->findAll();

        $tab = new ArrayCollection();
        $newtab = new ArrayCollection();

        foreach ($categories as $category) {
            $namesCate->add($category->getName());
        }

        $test='';
        for($i=0; $i<count($namesCate); $i++){
            $test = $namesCate[0];
        }
        $allcats = $em->getRepository('ProjetMainBundle:Category')->findBy(array('name'=>$test));


        for($i=0; $i<count($allcats); $i++){
            $tab[$i]=$allcats[$i];
        }
        for($j=0; $j<count($allvids); $j++){
            if ($allvids[$j]->getCategories()->contains($tab[0])){
                $newtab[$j] = $allvids[$j];

            }
        }

        if ($video == null)
            throw new NotFoundHttpException('Video not Found');

        // ******* LIKE BUTTON ********
        if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
            $liked = $this->get('security.token_storage')->getToken()->getUser()->haveLikedVideo($video);
        } else $liked = false;

        $like = $this->createFormBuilder()
            ->add('likebtn', ButtonType::class)
            ->getForm();
        if ($request->isMethod('POST')){
            $like->handleRequest($request);
            if ($like->isValid()) {
                if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')){
                    $token = $this->get('security.token_storage')->getToken();
                    if ($token == null) throw new Exception('$token is null');
                    $user = $token->getUser();

                    if ( !$user->haveLikedVideo($video)){
                        $user->addLikedVideo($video);
                        $video->likePlus();
                        $liked = true;
                        $this->addFlash(
                            'notice',
                            'Vous avez aimé cette vidéo'
                        );
                    }
                    else {
                        $user->removeLikedVideo($video);
                        $video->likeMinus();
                        $liked = false;
                        $this->addFlash(
                            'notice',
                            "Vous n'aimez plus cette vidéo"
                        );
                    }

                    $em = $this->getDoctrine()->getManager();
                    $em->persist($video);
                    $em->flush();
                } else return $this->redirectToRoute("projet_user_login");
            }
        }


        // render a response
        $content = $this->get('templating')->render('ProjetMainBundle:Main:content_video.html.twig',array(
            'video'=>$video,
            'cate'=>$namesCate,
            'related'=>$newtab,
            'like'=>$like->createView(),
            'liked'=>$liked,
        ));
        return new Response($content);
    }

    public function addvideoAction(Request $request){
//===============Init==================
        $repository = $this
            ->getDoctrine()
            ->getManager()
            ->getRepository('ProjetMainBundle:Video');
        $Cate = $this
            ->getDoctrine()
            ->getManager()
            ->getRepository('ProjetMainBundle:Category');
        // $categories all the categories array of category
        $choice_cate = new ArrayCollection(); // type array of 0,1 - 1 means choose this category
        $categories = $Cate->findAll();
//====================================
        // create form
        $upload = $this->createFormBuilder(null,array('csrf_protection'=>false))
            ->add('title', TextType::class)
            ->add('src', TextType::class)
            ->add('instruction', TextareaType::class)
            //=============
            ->add('cat0',RadioType::class)
            ->add('cat1', RadioType::class)
            ->add('cat2', RadioType::class)
            ->add('cat3', RadioType::class)
            ->add('cat4', RadioType::class)
            ->add('cat5', RadioType::class)
            //==============
            ->add('upload', SubmitType::class)
            ->getForm();

        // form submitted
        if ($request->isMethod('POST')){
            $upload->handleRequest($request);
            if ($upload->isValid()) { // if corrected form is submitted then add new video
                $data = $upload->getData();
                $key = substr($data['src'],32,11); // this is Youtube Video ID
                $src = 'https://www.youtube.com/embed/'.$key; // video src
                $thumb = 'https://img.youtube.com/vi/'.$key.'/hqdefault.jpg'; // video thumbnail

                // Save all buttons in $choice_cate
                for($index=0;$index<count($categories);$index++) { // for all category
                    $choice_cate->add($data['cat'.$index]);
                }

                //setup new video
                $vid = $repository->findOneBy(array('title' => $data['title']));

                if (( $vid === null) || ($data['title'] !== $vid->getTitle())) {
                    $video = new Video();
                    $video->setTitle($data['title']);
                    $video->setSrc($src);
                    $video->setThumb($thumb);
                    $video->setEtape($data['instruction']);

                    //Add category for video
                    for($index=0;$index<count($categories);$index++){
                        if ($choice_cate[$index]==1) $video->addCategory($categories[$index]);
                    }

                    //Add author
                    $token = $this->get('security.token_storage')->getToken();
                    if ($token == null) throw new Exception('$token is null');
                    $video->setAuthor($token->getUser());

                    ///Add to Database
                    $em = $this->getDoctrine()->getManager();
                    $em->persist($video);
                    $em->flush();

                    $this->addFlash(
                        'notice',
                        'Votre vidéo est déposé ! Merci à vous !'
                    );
                } else {
                    throw new AccessDeniedHttpException("Choisissez un autre titre s'il vous plaît");
                }
            }
        }

        if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
            $content = $this->get('templating')->render('ProjetMainBundle:Main:upload.html.twig',array(
                'upload' => $upload->createView()
            ));
            return new Response($content);
        }
        return $this->redirectToRoute("projet_user_login");
    }

    public function show_recipeAction($page, Request $request) {
        // Filter form by Date
        $date = $this->createFormBuilder(null,array('csrf_protection'=>false,'allow_extra_fields'=>true))
            ->add('date', DateType::class,array('format'=>'dd-MM-yyyy'))
            ->add('choose', SubmitType::class)
            ->getForm();

        //Filter form by Category
        $catefilter = $this->createFormBuilder(null,array('csrf_protection'=>false,'allow_extra_fields'=>true))
            ->add('cat0',RadioType::class)
            ->add('cat1', RadioType::class)
            ->add('cat2', RadioType::class)
            ->add('cat3', RadioType::class)
            ->add('cat4', RadioType::class)
            ->add('cat5', RadioType::class)
            ->add('filtrer', SubmitType::class)
            ->getForm();

        //Init
        $datefilter = '';
        $critereDate = '';
        $critereCate = '';

        $repository = $this  ->getDoctrine()->getManager()
            ->getRepository('ProjetMainBundle:Video');
        $Cate = $this  ->getDoctrine()->getManager()
            ->getRepository('ProjetMainBundle:Category');
        $all = $repository->findAll();


        //============Filter by Category Action=============/
        $list = new ArrayCollection();
        $choice_cate = new ArrayCollection(); // type array of 0,1 - 1 means choose this category
        $categories = $Cate->findAll();

        if($request->isMethod('POST')){
            $catefilter->handleRequest($request);
            if ($catefilter->isSubmitted())
            if($catefilter->isValid()){
                $data = $catefilter->getData();
                // Buttons of categories filter
                for($index=0;$index<count($categories);$index++) { // for all category
                    $choice_cate->add($data['cat'.$index]);
                }

                $all_videos = $repository->findAll();
                for($index=0;$index<count($categories);$index++) {
                    if ($choice_cate[$index] == 1) {  // if category in $choice_cate[$index] is chosen11
                        foreach ($all_videos as $video)
                            if ($video->haveCategory($categories[$index]))
                                if (!$list->contains($video))
                                    $list->add($video);
                    }
                }
                $critereCate = 'Catégorie';
                $critereDate = '';
            }
        }
        //============Filter by date Action===============/
        if ($request->isMethod('POST')) {
            $date->handleRequest($request);
            if($date->isSubmitted())
                if($date->isValid()){
                    $data = $date->getData();

                    $datefilter = $repository->findBy( array('date' => $data['date'] ));
                    $all = '';
                    $critereDate = 'Date';
                    $critereCate = '';
                }
        }
        //====================================================//
        // Return response
        $content = $this->get('templating')->render('ProjetMainBundle:Main:recette.html.twig',array(
            'date' => $date->createView(),
            'catefilter' => $catefilter->createView(),
            'resultDate'=> $datefilter,
            'critereDate'=> $critereDate,
            'critereCate'=> $critereCate,
            'all'=> $all,
            'resultCate' => $list,
        ));
        return new Response($content);
    }
}