<?php

/* ProjetMainBundle:Main:content_video.html.twig */
class __TwigTemplate_d0c4377a1c4e775e3fad874949c3a7ad8dff60d119d24aeb454a19f3812b6f65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetMainBundle:Main:content_video.html.twig", 3);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c5f9d185cfbec45959e2e3c9293cf43117411667db8ad267c5ca975339c9927d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5f9d185cfbec45959e2e3c9293cf43117411667db8ad267c5ca975339c9927d->enter($__internal_c5f9d185cfbec45959e2e3c9293cf43117411667db8ad267c5ca975339c9927d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:content_video.html.twig"));

        $__internal_8e6a48abae67ad80d95d899556cd94230d1f0cc40b30ac1f7bc0d5fda94c4603 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e6a48abae67ad80d95d899556cd94230d1f0cc40b30ac1f7bc0d5fda94c4603->enter($__internal_8e6a48abae67ad80d95d899556cd94230d1f0cc40b30ac1f7bc0d5fda94c4603_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:content_video.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c5f9d185cfbec45959e2e3c9293cf43117411667db8ad267c5ca975339c9927d->leave($__internal_c5f9d185cfbec45959e2e3c9293cf43117411667db8ad267c5ca975339c9927d_prof);

        
        $__internal_8e6a48abae67ad80d95d899556cd94230d1f0cc40b30ac1f7bc0d5fda94c4603->leave($__internal_8e6a48abae67ad80d95d899556cd94230d1f0cc40b30ac1f7bc0d5fda94c4603_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_e16d055d61195b078ceb29d4388e391f792596451f086f8653769d4ee28a51f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e16d055d61195b078ceb29d4388e391f792596451f086f8653769d4ee28a51f1->enter($__internal_e16d055d61195b078ceb29d4388e391f792596451f086f8653769d4ee28a51f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_cb90fb2901e54942cf78a3d25034fccb2983876de84a1b0f7dc5588212f0a717 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb90fb2901e54942cf78a3d25034fccb2983876de84a1b0f7dc5588212f0a717->enter($__internal_cb90fb2901e54942cf78a3d25034fccb2983876de84a1b0f7dc5588212f0a717_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "
    ";
        // line 8
        echo "    <div style=\"margin-top: 20px \" class=\"col-sm-1\"></div>

    <div style=\"margin-top: 20px; background-color: rgb(242,242,242); padding-top: 10px\" class=\"col-sm-7\">
        <!-- Video frame-->
        <div class=\"embed-responsive embed-responsive-16by9\">
            <iframe id=\"mainvideo\" class=\"embed-responsive-item\" src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "src", array()), "html", null, true);
        echo "\" frameborder=\"0\" allowfullscreen ></iframe></br>
        </div>

        <!-- Title and buttons -->
        <div>
            <span id=\"videotitle\" style=\"word-break: break-all; display: block; font-family: Futura; font-size: 35px;  letter-spacing: 2px; margin-top: 10px; margin-bottom: 15px\">
                ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "flashes", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 20
            echo "                    <div style=\"font-size: 13px; text-align: center\" class=\"flash-notice alert alert-info\">
                        <strong>";
            // line 21
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</strong>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "                <span id=\"titre\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "title", array()), "html", null, true);
        echo "</span>
                <span style=\"float: right; margin-top: 7px\">
                    ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["like"]) ? $context["like"] : $this->getContext($context, "like")), 'form_start');
        echo "
                    ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["like"]) ? $context["like"] : $this->getContext($context, "like")), 'errors');
        echo "
                    ";
        // line 28
        if (((isset($context["liked"]) ? $context["liked"] : $this->getContext($context, "liked")) == false)) {
            // line 29
            echo "                        ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["like"]) ? $context["like"] : $this->getContext($context, "like")), "likebtn", array()), 'widget', array("attr" => array("class" => "vidbtn like")));
            echo "
                    ";
        } else {
            // line 31
            echo "                        ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["like"]) ? $context["like"] : $this->getContext($context, "like")), "likebtn", array()), 'widget', array("attr" => array("class" => "vidbtn unlike")));
            echo "
                    ";
        }
        // line 33
        echo "                    ";
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["like"]) ? $context["like"] : $this->getContext($context, "like")), 'form_end');
        echo "
                </span>
                <span id=\"votes\" class=\"stats\">";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "hearts", array()), "html", null, true);
        echo "</span>
            </span>
        </div>

        <span id=\"credit\">Par <span id=\"user\"><a href=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_user_profile", array("username" => $this->getAttribute($this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "author", array()), "username", array()))), "html", null, true);
        echo "\" >";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "author", array()), "html", null, true);
        echo "</a></span> on <span id=\"date\"> ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "date", array()), "d/m/Y"), "html", null, true);
        echo " </span></span><br>

        <!-- Categories -->
        <div style=\"margin-top: 25px\">
            <span style=\"font-family: Futura; font-size: 20px; \">Catégories: </span>
            ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 45
            echo "            <span style=\"margin-bottom: 20px\">
                <a href=\"#\" class=\"tags\"> ";
            // line 47
            echo "                    ";
            echo twig_escape_filter($this->env, $context["category"], "html", null, true);
            echo "
                </a>
            </span>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "            <br>
        </div><br>
        <div style=\"background-color: white; width: 100%; height: 3px; margin: 10px 0px 10px 0px\"></div>

        <!-- Instruction -->
        <div style=\"background-color: rgb(242,242,242)\" >
            <span style=\"font-family: Futura; font-size: 30px; margin-top: 15px\">Instruction <button class=\"btn btn-info btn-lg\" id=\"printbtn\"><i class=\"glyphicon glyphicon-print\"></i></button></span>
            <div id=\"detail\">
                <p style=\"margin-top: 10px\">
                <ol id=\"instruction\" style=\"white-space: pre-line;\">
                    ";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "etape", array()), "html", null, true);
        echo "
                </ol><br>
            </div>
        </div>
    </div>

    <!-- Related video -->
    <div id=\"relatedvideos\" class=\"col-sm-3\">
        <button type=\"button\" id=\"relatedcollapse\" data-toggle=\"collapse\" data-target=\"#scrolldiv\">Vidéos similaires  <i style=\"font-size: 14px\" class=\"glyphicon glyphicon-chevron-down\"></i></button>
        <div id=\"scrolldiv\" class=\"collapse in\">
            ";
        // line 71
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["related"]) ? $context["related"] : $this->getContext($context, "related")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["rela"]) {
            // line 72
            echo "                ";
            if ((($this->getAttribute($context["loop"], "index", array()) <= 12) && ($this->getAttribute((isset($context["video"]) ? $context["video"] : $this->getContext($context, "video")), "title", array()) != $this->getAttribute($context["rela"], "title", array())))) {
                // line 73
                echo "                    <a class=\"similarvideos\" style=\"width: 100%; text-decoration: none; color: black\" href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["rela"], "id", array()))), "html", null, true);
                echo "\">
                        <div style=\"padding: 5px 0px 3px 5px ; width: 100% ;height: 120px;background-color: rgb(242,242,242); word-wrap: break-word; margin-bottom: 3px\">
                            <div style=\"margin-left: 7px; margin-right: 5px ;font-family: Futura; font-size: 15px; word-wrap: break-word; \">
                                <img style=\"float: left\" width=\"200\" height=\"112\" src=\"";
                // line 76
                echo twig_escape_filter($this->env, $this->getAttribute($context["rela"], "thumb", array()), "html", null, true);
                echo "\">
                                <span>";
                // line 77
                echo twig_escape_filter($this->env, $this->getAttribute($context["rela"], "title", array()), "html", null, true);
                echo "</span><br>
                                <span style=\"padding-top:20px; color: grey\">";
                // line 78
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["rela"], "date", array()), "d/m/Y"), "html", null, true);
                echo "</span>
                            </div>
                        </div>
                    </a>
                ";
            }
            // line 83
            echo "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rela'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 84
        echo "        </div>
        ";
        // line 85
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 86
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 87
        echo "
    </div>
    <div class=\"col-sm-1\"></div>

    <div style=\"margin-top: 10px\" class=\"col-sm-12\"></div>

    <div class=\"col-sm-1\"></div>
    <!-- Video instruction -->

    <div class=\"col-sm-4\"></div>

<!---------------->

";
        
        $__internal_cb90fb2901e54942cf78a3d25034fccb2983876de84a1b0f7dc5588212f0a717->leave($__internal_cb90fb2901e54942cf78a3d25034fccb2983876de84a1b0f7dc5588212f0a717_prof);

        
        $__internal_e16d055d61195b078ceb29d4388e391f792596451f086f8653769d4ee28a51f1->leave($__internal_e16d055d61195b078ceb29d4388e391f792596451f086f8653769d4ee28a51f1_prof);

    }

    public function getTemplateName()
    {
        return "ProjetMainBundle:Main:content_video.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  250 => 87,  244 => 86,  240 => 85,  237 => 84,  223 => 83,  215 => 78,  211 => 77,  207 => 76,  200 => 73,  197 => 72,  180 => 71,  167 => 61,  155 => 51,  144 => 47,  141 => 45,  137 => 44,  125 => 39,  118 => 35,  112 => 33,  106 => 31,  100 => 29,  98 => 28,  94 => 27,  90 => 26,  84 => 24,  75 => 21,  72 => 20,  68 => 19,  59 => 13,  52 => 8,  49 => 6,  40 => 5,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src\\Projet\\MainBundle\\Resources\\views\\Main\\content_video.html.twig #}

{% extends \"ProjetMainBundle:Main:layout.html.twig\" %}

{% block content %}

    {#================================#}
    <div style=\"margin-top: 20px \" class=\"col-sm-1\"></div>

    <div style=\"margin-top: 20px; background-color: rgb(242,242,242); padding-top: 10px\" class=\"col-sm-7\">
        <!-- Video frame-->
        <div class=\"embed-responsive embed-responsive-16by9\">
            <iframe id=\"mainvideo\" class=\"embed-responsive-item\" src=\"{{ video.src }}\" frameborder=\"0\" allowfullscreen ></iframe></br>
        </div>

        <!-- Title and buttons -->
        <div>
            <span id=\"videotitle\" style=\"word-break: break-all; display: block; font-family: Futura; font-size: 35px;  letter-spacing: 2px; margin-top: 10px; margin-bottom: 15px\">
                {% for message in app.flashes('notice') %}
                    <div style=\"font-size: 13px; text-align: center\" class=\"flash-notice alert alert-info\">
                        <strong>{{ message }}</strong>
                    </div>
                {% endfor %}
                <span id=\"titre\">{{ video.title }}</span>
                <span style=\"float: right; margin-top: 7px\">
                    {{ form_start(like) }}
                    {{ form_errors(like) }}
                    {% if liked == false %}
                        {{ form_widget(like.likebtn, {'attr':{'class':'vidbtn like'}}) }}
                    {% else %}
                        {{ form_widget(like.likebtn, {'attr':{'class':'vidbtn unlike'}}) }}
                    {% endif %}
                    {{ form_end(like) }}
                </span>
                <span id=\"votes\" class=\"stats\">{{ video.hearts }}</span>
            </span>
        </div>

        <span id=\"credit\">Par <span id=\"user\"><a href=\"{{ path('projet_user_profile',{'username': video.author.username}) }}\" >{{ video.author }}</a></span> on <span id=\"date\"> {{ video.date|date(\"d/m/Y\") }} </span></span><br>

        <!-- Categories -->
        <div style=\"margin-top: 25px\">
            <span style=\"font-family: Futura; font-size: 20px; \">Catégories: </span>
            {%  for category in cate %}
            <span style=\"margin-bottom: 20px\">
                <a href=\"#\" class=\"tags\"> {#TODO hyperlink to page of recette#}
                    {{ category }}
                </a>
            </span>
            {% endfor %}
            <br>
        </div><br>
        <div style=\"background-color: white; width: 100%; height: 3px; margin: 10px 0px 10px 0px\"></div>

        <!-- Instruction -->
        <div style=\"background-color: rgb(242,242,242)\" >
            <span style=\"font-family: Futura; font-size: 30px; margin-top: 15px\">Instruction <button class=\"btn btn-info btn-lg\" id=\"printbtn\"><i class=\"glyphicon glyphicon-print\"></i></button></span>
            <div id=\"detail\">
                <p style=\"margin-top: 10px\">
                <ol id=\"instruction\" style=\"white-space: pre-line;\">
                    {{ video.etape }}
                </ol><br>
            </div>
        </div>
    </div>

    <!-- Related video -->
    <div id=\"relatedvideos\" class=\"col-sm-3\">
        <button type=\"button\" id=\"relatedcollapse\" data-toggle=\"collapse\" data-target=\"#scrolldiv\">Vidéos similaires  <i style=\"font-size: 14px\" class=\"glyphicon glyphicon-chevron-down\"></i></button>
        <div id=\"scrolldiv\" class=\"collapse in\">
            {% for rela in related %}
                {%  if loop.index <= 12 and video.title != rela.title %}
                    <a class=\"similarvideos\" style=\"width: 100%; text-decoration: none; color: black\" href=\"{{ path('projet_main_show_video',{'id':rela.id}) }}\">
                        <div style=\"padding: 5px 0px 3px 5px ; width: 100% ;height: 120px;background-color: rgb(242,242,242); word-wrap: break-word; margin-bottom: 3px\">
                            <div style=\"margin-left: 7px; margin-right: 5px ;font-family: Futura; font-size: 15px; word-wrap: break-word; \">
                                <img style=\"float: left\" width=\"200\" height=\"112\" src=\"{{ rela.thumb }}\">
                                <span>{{ rela.title }}</span><br>
                                <span style=\"padding-top:20px; color: grey\">{{ rela.date|date(\"d/m/Y\") }}</span>
                            </div>
                        </div>
                    </a>
                {% endif %}
            {% endfor %}
        </div>
        {%  for category in cate %}
        {% endfor %}

    </div>
    <div class=\"col-sm-1\"></div>

    <div style=\"margin-top: 10px\" class=\"col-sm-12\"></div>

    <div class=\"col-sm-1\"></div>
    <!-- Video instruction -->

    <div class=\"col-sm-4\"></div>

<!---------------->

{% endblock %}
", "ProjetMainBundle:Main:content_video.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/MainBundle/Resources/views/Main/content_video.html.twig");
    }
}
