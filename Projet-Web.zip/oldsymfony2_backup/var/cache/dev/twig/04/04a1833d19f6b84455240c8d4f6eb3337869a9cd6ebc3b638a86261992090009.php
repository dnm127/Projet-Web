<?php

/* WebProfilerBundle:Profiler:header.html.twig */
class __TwigTemplate_8003a0ee9d8dbb8165eae5bd7b3f6fbb2d0b6f4abfcd906b58ea40d480c08bf6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ed8ad3b8d08ecbdbfaec28de803e62b7c5347b6bb6eb24418eb1526ad63d99c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ed8ad3b8d08ecbdbfaec28de803e62b7c5347b6bb6eb24418eb1526ad63d99c->enter($__internal_0ed8ad3b8d08ecbdbfaec28de803e62b7c5347b6bb6eb24418eb1526ad63d99c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:header.html.twig"));

        $__internal_abc7eb81316f02a493ed585129b14cba827999c352c595a07cee274a9e6ebc3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_abc7eb81316f02a493ed585129b14cba827999c352c595a07cee274a9e6ebc3f->enter($__internal_abc7eb81316f02a493ed585129b14cba827999c352c595a07cee274a9e6ebc3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_0ed8ad3b8d08ecbdbfaec28de803e62b7c5347b6bb6eb24418eb1526ad63d99c->leave($__internal_0ed8ad3b8d08ecbdbfaec28de803e62b7c5347b6bb6eb24418eb1526ad63d99c_prof);

        
        $__internal_abc7eb81316f02a493ed585129b14cba827999c352c595a07cee274a9e6ebc3f->leave($__internal_abc7eb81316f02a493ed585129b14cba827999c352c595a07cee274a9e6ebc3f_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"header\">
    <div class=\"container\">
        <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
", "WebProfilerBundle:Profiler:header.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/header.html.twig");
    }
}
