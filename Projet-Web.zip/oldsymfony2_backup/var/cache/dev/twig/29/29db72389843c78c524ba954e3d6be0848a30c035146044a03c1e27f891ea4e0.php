<?php

/* FOSUserBundle:Profile:show_content.html.twig */
class __TwigTemplate_57bbb3c16b61313c2b80e4c61605755ea347282db79fb740253b25ae3cc56f37 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b29bae5fa8d81b0e84161bfcb2760667d49ff89bc9a3bfa734aafcca18771145 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b29bae5fa8d81b0e84161bfcb2760667d49ff89bc9a3bfa734aafcca18771145->enter($__internal_b29bae5fa8d81b0e84161bfcb2760667d49ff89bc9a3bfa734aafcca18771145_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        $__internal_299ef47dba251b3909f069ea827f4762e63cea4ec9e5ef2bdd2a6efd7b2cebdf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_299ef47dba251b3909f069ea827f4762e63cea4ec9e5ef2bdd2a6efd7b2cebdf->enter($__internal_299ef47dba251b3909f069ea827f4762e63cea4ec9e5ef2bdd2a6efd7b2cebdf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_user_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.username", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</p>
    <p>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.email", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_b29bae5fa8d81b0e84161bfcb2760667d49ff89bc9a3bfa734aafcca18771145->leave($__internal_b29bae5fa8d81b0e84161bfcb2760667d49ff89bc9a3bfa734aafcca18771145_prof);

        
        $__internal_299ef47dba251b3909f069ea827f4762e63cea4ec9e5ef2bdd2a6efd7b2cebdf->leave($__internal_299ef47dba251b3909f069ea827f4762e63cea4ec9e5ef2bdd2a6efd7b2cebdf_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 5,  29 => 4,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"fos_user_user_show\">
    <p>{{ 'profile.show.username'|trans }}: {{ user.username }}</p>
    <p>{{ 'profile.show.email'|trans }}: {{ user.email }}</p>
</div>
", "FOSUserBundle:Profile:show_content.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/show_content.html.twig");
    }
}
