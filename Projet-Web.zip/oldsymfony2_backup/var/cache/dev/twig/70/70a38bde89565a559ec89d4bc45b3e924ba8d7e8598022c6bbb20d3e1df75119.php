<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_9f1f4ecf93569d56084c2103d2b77c4378151c4cf8b4fd72359a0e0ebefeafe6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_681b8ed8d9c7a8779e770fca11ed7268d60593d32907d6fa893c41f2070d6a72 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_681b8ed8d9c7a8779e770fca11ed7268d60593d32907d6fa893c41f2070d6a72->enter($__internal_681b8ed8d9c7a8779e770fca11ed7268d60593d32907d6fa893c41f2070d6a72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_a7d63ddd3915c70f5982f10c66e8b9df818d8f35caf8fcafa1da5bf953b72f92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7d63ddd3915c70f5982f10c66e8b9df818d8f35caf8fcafa1da5bf953b72f92->enter($__internal_a7d63ddd3915c70f5982f10c66e8b9df818d8f35caf8fcafa1da5bf953b72f92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_681b8ed8d9c7a8779e770fca11ed7268d60593d32907d6fa893c41f2070d6a72->leave($__internal_681b8ed8d9c7a8779e770fca11ed7268d60593d32907d6fa893c41f2070d6a72_prof);

        
        $__internal_a7d63ddd3915c70f5982f10c66e8b9df818d8f35caf8fcafa1da5bf953b72f92->leave($__internal_a7d63ddd3915c70f5982f10c66e8b9df818d8f35caf8fcafa1da5bf953b72f92_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
