<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_a1d1f09240314e91bf5a919e6d40ba4988f2881619330fecd487b2a6e6eadb20 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa28cb10400d8d46d4148d580ad6e983884a9976d36c4fec721001d323806ad9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa28cb10400d8d46d4148d580ad6e983884a9976d36c4fec721001d323806ad9->enter($__internal_fa28cb10400d8d46d4148d580ad6e983884a9976d36c4fec721001d323806ad9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $__internal_057e64e6c111b8c85f8699ca9380a6408c4efde9573a3a0c7a27b8ef0d57bd76 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_057e64e6c111b8c85f8699ca9380a6408c4efde9573a3a0c7a27b8ef0d57bd76->enter($__internal_057e64e6c111b8c85f8699ca9380a6408c4efde9573a3a0c7a27b8ef0d57bd76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fa28cb10400d8d46d4148d580ad6e983884a9976d36c4fec721001d323806ad9->leave($__internal_fa28cb10400d8d46d4148d580ad6e983884a9976d36c4fec721001d323806ad9_prof);

        
        $__internal_057e64e6c111b8c85f8699ca9380a6408c4efde9573a3a0c7a27b8ef0d57bd76->leave($__internal_057e64e6c111b8c85f8699ca9380a6408c4efde9573a3a0c7a27b8ef0d57bd76_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4572257f5eb759273e4f53298ffbf1bf02e8c09150eb9b7a39c4de6af150fab8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4572257f5eb759273e4f53298ffbf1bf02e8c09150eb9b7a39c4de6af150fab8->enter($__internal_4572257f5eb759273e4f53298ffbf1bf02e8c09150eb9b7a39c4de6af150fab8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_23a97afb1a471ebe03e0bc26d7e840373d65818cd80aec8732621dc8deae5e81 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23a97afb1a471ebe03e0bc26d7e840373d65818cd80aec8732621dc8deae5e81->enter($__internal_23a97afb1a471ebe03e0bc26d7e840373d65818cd80aec8732621dc8deae5e81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_23a97afb1a471ebe03e0bc26d7e840373d65818cd80aec8732621dc8deae5e81->leave($__internal_23a97afb1a471ebe03e0bc26d7e840373d65818cd80aec8732621dc8deae5e81_prof);

        
        $__internal_4572257f5eb759273e4f53298ffbf1bf02e8c09150eb9b7a39c4de6af150fab8->leave($__internal_4572257f5eb759273e4f53298ffbf1bf02e8c09150eb9b7a39c4de6af150fab8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/register.html.twig");
    }
}
