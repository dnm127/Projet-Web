<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_eb28aa22dd221e7ed5ae630ec1536d5bfc2f2d24fcecb21b5eb1b9da430709be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9576151261fb93310962f8022913748e11865c97428cdd9ac1eab9f9e27f9bc1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9576151261fb93310962f8022913748e11865c97428cdd9ac1eab9f9e27f9bc1->enter($__internal_9576151261fb93310962f8022913748e11865c97428cdd9ac1eab9f9e27f9bc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_994414eed60c2ec9d2c150246ea0f4837b03b390f7118169932d04c5e8771ba7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_994414eed60c2ec9d2c150246ea0f4837b03b390f7118169932d04c5e8771ba7->enter($__internal_994414eed60c2ec9d2c150246ea0f4837b03b390f7118169932d04c5e8771ba7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_9576151261fb93310962f8022913748e11865c97428cdd9ac1eab9f9e27f9bc1->leave($__internal_9576151261fb93310962f8022913748e11865c97428cdd9ac1eab9f9e27f9bc1_prof);

        
        $__internal_994414eed60c2ec9d2c150246ea0f4837b03b390f7118169932d04c5e8771ba7->leave($__internal_994414eed60c2ec9d2c150246ea0f4837b03b390f7118169932d04c5e8771ba7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
