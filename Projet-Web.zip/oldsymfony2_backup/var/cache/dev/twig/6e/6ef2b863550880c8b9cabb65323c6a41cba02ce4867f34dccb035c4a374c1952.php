<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_9b9f1d51099ac8126abd87d816e93d57d235e08122a769f76a1bc68def51f127 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8a20dc105b670ffa1f4e69656e75d7d10f25a53171cc2b57a0bede9b3625880 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a8a20dc105b670ffa1f4e69656e75d7d10f25a53171cc2b57a0bede9b3625880->enter($__internal_a8a20dc105b670ffa1f4e69656e75d7d10f25a53171cc2b57a0bede9b3625880_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_7e49e2aab56dfbb9aa4a9afd8b6dcb082e5ab3c92a35b7712a0f4eb4e01a1c5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e49e2aab56dfbb9aa4a9afd8b6dcb082e5ab3c92a35b7712a0f4eb4e01a1c5d->enter($__internal_7e49e2aab56dfbb9aa4a9afd8b6dcb082e5ab3c92a35b7712a0f4eb4e01a1c5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
";
        
        $__internal_a8a20dc105b670ffa1f4e69656e75d7d10f25a53171cc2b57a0bede9b3625880->leave($__internal_a8a20dc105b670ffa1f4e69656e75d7d10f25a53171cc2b57a0bede9b3625880_prof);

        
        $__internal_7e49e2aab56dfbb9aa4a9afd8b6dcb082e5ab3c92a35b7712a0f4eb4e01a1c5d->leave($__internal_7e49e2aab56dfbb9aa4a9afd8b6dcb082e5ab3c92a35b7712a0f4eb4e01a1c5d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
