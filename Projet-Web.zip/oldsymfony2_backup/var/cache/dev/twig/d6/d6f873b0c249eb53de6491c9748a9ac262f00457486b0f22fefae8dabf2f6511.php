<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_e9e7374c2ac544845b65693d1136c0bdf017040152c874bfbf7693d1e7534695 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1cd58dbd8eb3b4b740603cffcebbeedb54ec479f288a81ff589dca97747e4fc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cd58dbd8eb3b4b740603cffcebbeedb54ec479f288a81ff589dca97747e4fc7->enter($__internal_1cd58dbd8eb3b4b740603cffcebbeedb54ec479f288a81ff589dca97747e4fc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_3c27f1e9e87162d0281acc59753640eb3c7d0f74077a5e8ada0315ba050dfa28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c27f1e9e87162d0281acc59753640eb3c7d0f74077a5e8ada0315ba050dfa28->enter($__internal_3c27f1e9e87162d0281acc59753640eb3c7d0f74077a5e8ada0315ba050dfa28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_1cd58dbd8eb3b4b740603cffcebbeedb54ec479f288a81ff589dca97747e4fc7->leave($__internal_1cd58dbd8eb3b4b740603cffcebbeedb54ec479f288a81ff589dca97747e4fc7_prof);

        
        $__internal_3c27f1e9e87162d0281acc59753640eb3c7d0f74077a5e8ada0315ba050dfa28->leave($__internal_3c27f1e9e87162d0281acc59753640eb3c7d0f74077a5e8ada0315ba050dfa28_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
