<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_3849f3f434d274058228eabe55ac89fa0c2c41cdcf3d5141d105e80d61ae1d9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bcf0cd8202e5b86f1beb2ba34b3fd269eab355e3f4815af88b0834a61cb9b1f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bcf0cd8202e5b86f1beb2ba34b3fd269eab355e3f4815af88b0834a61cb9b1f6->enter($__internal_bcf0cd8202e5b86f1beb2ba34b3fd269eab355e3f4815af88b0834a61cb9b1f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_eee4121b61b6ded4f48f159485f870ab678702c6707c610524e746e5fd3479d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eee4121b61b6ded4f48f159485f870ab678702c6707c610524e746e5fd3479d3->enter($__internal_eee4121b61b6ded4f48f159485f870ab678702c6707c610524e746e5fd3479d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_bcf0cd8202e5b86f1beb2ba34b3fd269eab355e3f4815af88b0834a61cb9b1f6->leave($__internal_bcf0cd8202e5b86f1beb2ba34b3fd269eab355e3f4815af88b0834a61cb9b1f6_prof);

        
        $__internal_eee4121b61b6ded4f48f159485f870ab678702c6707c610524e746e5fd3479d3->leave($__internal_eee4121b61b6ded4f48f159485f870ab678702c6707c610524e746e5fd3479d3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget.html.php");
    }
}
