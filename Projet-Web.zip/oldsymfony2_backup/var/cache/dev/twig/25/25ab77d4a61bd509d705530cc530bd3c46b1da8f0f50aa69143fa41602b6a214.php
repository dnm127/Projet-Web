<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_9f20f48ce4eda8961016c33b85820ee58d4bd9bb0356b8dd3acc20dfc746431b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c65ef36e8b4cec0ea2ff67dc9c3f1018638d1ef9b5fe5fe269bfce52a48e21f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c65ef36e8b4cec0ea2ff67dc9c3f1018638d1ef9b5fe5fe269bfce52a48e21f->enter($__internal_4c65ef36e8b4cec0ea2ff67dc9c3f1018638d1ef9b5fe5fe269bfce52a48e21f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_032ff0515f47af3276aa57560e0687c0ba45c6453e119928172ef0dea1b99ca5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_032ff0515f47af3276aa57560e0687c0ba45c6453e119928172ef0dea1b99ca5->enter($__internal_032ff0515f47af3276aa57560e0687c0ba45c6453e119928172ef0dea1b99ca5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_4c65ef36e8b4cec0ea2ff67dc9c3f1018638d1ef9b5fe5fe269bfce52a48e21f->leave($__internal_4c65ef36e8b4cec0ea2ff67dc9c3f1018638d1ef9b5fe5fe269bfce52a48e21f_prof);

        
        $__internal_032ff0515f47af3276aa57560e0687c0ba45c6453e119928172ef0dea1b99ca5->leave($__internal_032ff0515f47af3276aa57560e0687c0ba45c6453e119928172ef0dea1b99ca5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.atom.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
