<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_7a378f78f6449f746ae3003d6a64220becc764bc9467e5e3c09d4ec68db9cc74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b61e92efdcc2580c5af776a3572d4bc01249dd1f29b7505972e55a589f4d8d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b61e92efdcc2580c5af776a3572d4bc01249dd1f29b7505972e55a589f4d8d1->enter($__internal_9b61e92efdcc2580c5af776a3572d4bc01249dd1f29b7505972e55a589f4d8d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_a847aa43091dbea16a7f39f55232c1e49d0748ade64b14771fe5748e5655869c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a847aa43091dbea16a7f39f55232c1e49d0748ade64b14771fe5748e5655869c->enter($__internal_a847aa43091dbea16a7f39f55232c1e49d0748ade64b14771fe5748e5655869c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_9b61e92efdcc2580c5af776a3572d4bc01249dd1f29b7505972e55a589f4d8d1->leave($__internal_9b61e92efdcc2580c5af776a3572d4bc01249dd1f29b7505972e55a589f4d8d1_prof);

        
        $__internal_a847aa43091dbea16a7f39f55232c1e49d0748ade64b14771fe5748e5655869c->leave($__internal_a847aa43091dbea16a7f39f55232c1e49d0748ade64b14771fe5748e5655869c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
