<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_490525e59e087cf2c63139a5a1d609081f0cfad9585e0147a18f7fd240778907 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_086c0d8cb31e3ef9407bdc9c285e0c52086dad0eaf147b18f558e8d92be8f587 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_086c0d8cb31e3ef9407bdc9c285e0c52086dad0eaf147b18f558e8d92be8f587->enter($__internal_086c0d8cb31e3ef9407bdc9c285e0c52086dad0eaf147b18f558e8d92be8f587_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_b896a64c65ebcf86a760fa277cc2d3a610d410395dc96216c8528dcde48ae5dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b896a64c65ebcf86a760fa277cc2d3a610d410395dc96216c8528dcde48ae5dc->enter($__internal_b896a64c65ebcf86a760fa277cc2d3a610d410395dc96216c8528dcde48ae5dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_086c0d8cb31e3ef9407bdc9c285e0c52086dad0eaf147b18f558e8d92be8f587->leave($__internal_086c0d8cb31e3ef9407bdc9c285e0c52086dad0eaf147b18f558e8d92be8f587_prof);

        
        $__internal_b896a64c65ebcf86a760fa277cc2d3a610d410395dc96216c8528dcde48ae5dc->leave($__internal_b896a64c65ebcf86a760fa277cc2d3a610d410395dc96216c8528dcde48ae5dc_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
