<?php

/* ProjetMainBundle:Main:index.html.twig */
class __TwigTemplate_250f044a23801a264eb7e5b0eccc60a6a0a58343cc46cd92f3fad6bc489f9440 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetMainBundle:Main:index.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c37a30e35a9d474505bd299102350c4f19caa636ccdcbaeb8f4a95f6cc8116b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c37a30e35a9d474505bd299102350c4f19caa636ccdcbaeb8f4a95f6cc8116b->enter($__internal_9c37a30e35a9d474505bd299102350c4f19caa636ccdcbaeb8f4a95f6cc8116b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:index.html.twig"));

        $__internal_67e47fe21f41adc559e7379ccb2698115650f9efe26dcd0f0f334ee4ceec4dad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67e47fe21f41adc559e7379ccb2698115650f9efe26dcd0f0f334ee4ceec4dad->enter($__internal_67e47fe21f41adc559e7379ccb2698115650f9efe26dcd0f0f334ee4ceec4dad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c37a30e35a9d474505bd299102350c4f19caa636ccdcbaeb8f4a95f6cc8116b->leave($__internal_9c37a30e35a9d474505bd299102350c4f19caa636ccdcbaeb8f4a95f6cc8116b_prof);

        
        $__internal_67e47fe21f41adc559e7379ccb2698115650f9efe26dcd0f0f334ee4ceec4dad->leave($__internal_67e47fe21f41adc559e7379ccb2698115650f9efe26dcd0f0f334ee4ceec4dad_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_1018614945ce26f0697f8589538c3a021c9e790efa462f37f3b1da3fe9e6ebdc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1018614945ce26f0697f8589538c3a021c9e790efa462f37f3b1da3fe9e6ebdc->enter($__internal_1018614945ce26f0697f8589538c3a021c9e790efa462f37f3b1da3fe9e6ebdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_727191de5b87904bae36cd313749f68f1fb9b376f27f280566b337150026e5d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_727191de5b87904bae36cd313749f68f1fb9b376f27f280566b337150026e5d0->enter($__internal_727191de5b87904bae36cd313749f68f1fb9b376f27f280566b337150026e5d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    ";
        $this->displayParentBlock("title", $context, $blocks);
        echo " - Main Page
";
        
        $__internal_727191de5b87904bae36cd313749f68f1fb9b376f27f280566b337150026e5d0->leave($__internal_727191de5b87904bae36cd313749f68f1fb9b376f27f280566b337150026e5d0_prof);

        
        $__internal_1018614945ce26f0697f8589538c3a021c9e790efa462f37f3b1da3fe9e6ebdc->leave($__internal_1018614945ce26f0697f8589538c3a021c9e790efa462f37f3b1da3fe9e6ebdc_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_3e7af216f421c70c19d963341b947fc87217ebe01997a94b04ac8b9b327e8b20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e7af216f421c70c19d963341b947fc87217ebe01997a94b04ac8b9b327e8b20->enter($__internal_3e7af216f421c70c19d963341b947fc87217ebe01997a94b04ac8b9b327e8b20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_058fec30f6a4447a4ba37022bcb55d999e29f30d1842fd1f3583020543a195ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_058fec30f6a4447a4ba37022bcb55d999e29f30d1842fd1f3583020543a195ad->enter($__internal_058fec30f6a4447a4ba37022bcb55d999e29f30d1842fd1f3583020543a195ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listVideos"]) ? $context["listVideos"] : $this->getContext($context, "listVideos")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["arrayVideos"]) {
            // line 11
            echo "        ";
            if ((($this->getAttribute($context["loop"], "index", array()) % 2) == 0)) {
                // line 12
                echo "            <div class=\"col-sm-12 divpair showmore\">
                <span class=\"cate\">";
                // line 13
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["listCate"]) ? $context["listCate"] : $this->getContext($context, "listCate")), $this->getAttribute($context["loop"], "index0", array()), array(), "array"), "name", array()), "html", null, true);
                echo "</span>
                <span><a href=\"";
                // line 14
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_recipe", array("page" => 1));
                echo "\"><button class=\"voirplus\" style=\"float: right\">Voir plus</button></a></span>
                <br>
                ";
                // line 16
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, $context["arrayVideos"], 1, 4));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["video"]) {
                    // line 17
                    echo "
                    ";
                    // line 18
                    if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 1)) {
                        // line 19
                        echo "                        <div class=\"col-sm-2\"></div>
                    ";
                    }
                    // line 21
                    echo "                    <div class=\"col-sm-2 imgdiv\">
                        <a class=\"avideo\" href=\"";
                    // line 22
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["video"], "id", array()))), "html", null, true);
                    echo "\">
                            <img class=\"thumb\" width=\"380\" height=\"200\" src=\"";
                    // line 23
                    echo twig_escape_filter($this->env, $this->getAttribute($context["video"], "thumb", array()), "html", null, true);
                    echo "\">
                            <div class=\"titrerecette\">";
                    // line 24
                    echo twig_escape_filter($this->env, $this->getAttribute($context["video"], "title", array()), "html", null, true);
                    echo "</div>
                        </a>
                    </div>
                    ";
                    // line 27
                    if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 0)) {
                        // line 28
                        echo "                        <div class=\"col-sm-2\"></div>
                        <div class=\"col-sm-12\"></div>
                    ";
                    }
                    // line 31
                    echo "
                ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['video'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 33
                echo "            </div>

        ";
            } elseif ((($this->getAttribute(            // line 35
$context["loop"], "index", array()) % 2) != 0)) {
                // line 36
                echo "            <div class=\"col-sm-12 divimpair showmore\">
            <span>
            <span class=\"cate\" >";
                // line 38
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["listCate"]) ? $context["listCate"] : $this->getContext($context, "listCate")), $this->getAttribute($context["loop"], "index0", array()), array(), "array"), "name", array()), "html", null, true);
                echo "</span>
            <span><a href=\"";
                // line 39
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_recipe", array("page" => 1));
                echo "\"><button class=\"voirplus\"  style=\"float: right\">Voir plus</button></a></span>
            </span><br>
                ";
                // line 41
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, $context["arrayVideos"], 1, 4));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["video"]) {
                    // line 42
                    echo "
                    ";
                    // line 43
                    if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 1)) {
                        // line 44
                        echo "                        <div class=\"col-sm-2\"></div>
                    ";
                    }
                    // line 46
                    echo "                    <div class=\"col-sm-2 imgdiv\">
                        <a class=\"avideo\" href=\"";
                    // line 47
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["video"], "id", array()))), "html", null, true);
                    echo "\">
                            <img class=\"thumb\" width=\"380\" height=\"200\" src=\"";
                    // line 48
                    echo twig_escape_filter($this->env, $this->getAttribute($context["video"], "thumb", array()), "html", null, true);
                    echo "\">
                            <div class=\"titrerecette\">";
                    // line 49
                    echo twig_escape_filter($this->env, $this->getAttribute($context["video"], "title", array()), "html", null, true);
                    echo "</div>
                        </a>
                    </div>
                    ";
                    // line 52
                    if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 0)) {
                        // line 53
                        echo "                        <div class=\"col-sm-2\"></div>
                        <div style=\"margin-top: 20px\" class=\"col-sm-12\"></div>
                    ";
                    }
                    // line 56
                    echo "
                ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['video'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 58
                echo "            </div>

        ";
            }
            // line 61
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['arrayVideos'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "
    <div class=\"col-sm-4\"></div>
    <div style=\"text-align: center;\" class=\"col-sm-4\"><button id=\"btnmore\"><i style=\"\" class=\"glyphicon glyphicon-plus-sign\" ></i> Voir plus</button></div>
    <div class=\"col-sm-4\"></div>

";
        
        $__internal_058fec30f6a4447a4ba37022bcb55d999e29f30d1842fd1f3583020543a195ad->leave($__internal_058fec30f6a4447a4ba37022bcb55d999e29f30d1842fd1f3583020543a195ad_prof);

        
        $__internal_3e7af216f421c70c19d963341b947fc87217ebe01997a94b04ac8b9b327e8b20->leave($__internal_3e7af216f421c70c19d963341b947fc87217ebe01997a94b04ac8b9b327e8b20_prof);

    }

    public function getTemplateName()
    {
        return "ProjetMainBundle:Main:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  273 => 62,  259 => 61,  254 => 58,  239 => 56,  234 => 53,  232 => 52,  226 => 49,  222 => 48,  218 => 47,  215 => 46,  211 => 44,  209 => 43,  206 => 42,  189 => 41,  184 => 39,  180 => 38,  176 => 36,  174 => 35,  170 => 33,  155 => 31,  150 => 28,  148 => 27,  142 => 24,  138 => 23,  134 => 22,  131 => 21,  127 => 19,  125 => 18,  122 => 17,  105 => 16,  100 => 14,  96 => 13,  93 => 12,  90 => 11,  72 => 10,  63 => 9,  50 => 6,  41 => 5,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src\\Projet\\MainBundle\\Resources\\views\\Main\\index.html.twig #}

{% extends 'ProjetMainBundle:Main:layout.html.twig' %}

{% block title %}
    {{ parent() }} - Main Page
{% endblock %}

{% block content %}
    {% for arrayVideos in listVideos %}
        {% if loop.index % 2 == 0  %}
            <div class=\"col-sm-12 divpair showmore\">
                <span class=\"cate\">{{ listCate[loop.index0].name }}</span>
                <span><a href=\"{{ path('projet_main_show_recipe',{'page':1}) }}\"><button class=\"voirplus\" style=\"float: right\">Voir plus</button></a></span>
                <br>
                {% for video in arrayVideos|slice(1,4) %}

                    {% if loop.index % 4 == 1  %}
                        <div class=\"col-sm-2\"></div>
                    {% endif %}
                    <div class=\"col-sm-2 imgdiv\">
                        <a class=\"avideo\" href=\"{{ path('projet_main_show_video',{'id':video.id}) }}\">
                            <img class=\"thumb\" width=\"380\" height=\"200\" src=\"{{ video.thumb }}\">
                            <div class=\"titrerecette\">{{ video.title }}</div>
                        </a>
                    </div>
                    {% if loop.index % 4 == 0 %}
                        <div class=\"col-sm-2\"></div>
                        <div class=\"col-sm-12\"></div>
                    {% endif %}

                {% endfor %}
            </div>

        {% elseif loop.index % 2 != 0 %}
            <div class=\"col-sm-12 divimpair showmore\">
            <span>
            <span class=\"cate\" >{{ listCate[loop.index0].name }}</span>
            <span><a href=\"{{ path('projet_main_show_recipe',{'page':1}) }}\"><button class=\"voirplus\"  style=\"float: right\">Voir plus</button></a></span>
            </span><br>
                {% for video in arrayVideos| slice(1,4) %}

                    {% if loop.index % 4 == 1  %}
                        <div class=\"col-sm-2\"></div>
                    {% endif %}
                    <div class=\"col-sm-2 imgdiv\">
                        <a class=\"avideo\" href=\"{{ path('projet_main_show_video',{'id':video.id}) }}\">
                            <img class=\"thumb\" width=\"380\" height=\"200\" src=\"{{ video.thumb }}\">
                            <div class=\"titrerecette\">{{ video.title }}</div>
                        </a>
                    </div>
                    {% if loop.index % 4 == 0 %}
                        <div class=\"col-sm-2\"></div>
                        <div style=\"margin-top: 20px\" class=\"col-sm-12\"></div>
                    {% endif %}

                {% endfor %}
            </div>

        {% endif %}
    {% endfor %}

    <div class=\"col-sm-4\"></div>
    <div style=\"text-align: center;\" class=\"col-sm-4\"><button id=\"btnmore\"><i style=\"\" class=\"glyphicon glyphicon-plus-sign\" ></i> Voir plus</button></div>
    <div class=\"col-sm-4\"></div>

{% endblock %}

", "ProjetMainBundle:Main:index.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/MainBundle/Resources/views/Main/index.html.twig");
    }
}
