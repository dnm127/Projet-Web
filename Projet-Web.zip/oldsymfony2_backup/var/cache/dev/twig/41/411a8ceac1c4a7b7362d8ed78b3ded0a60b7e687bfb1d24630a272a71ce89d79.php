<?php

/* ProjetUserBundle:Security:login.html.twig */
class __TwigTemplate_0379ffb4e5039a1338da70384d65911586861958c21421d13adc14eb7bd9d045 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetUserBundle:Security:login.html.twig", 3);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a1bdee989e5ed3a7d75b645a4cde211eef9fc7a34f57593cbeea5fdb177b723 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a1bdee989e5ed3a7d75b645a4cde211eef9fc7a34f57593cbeea5fdb177b723->enter($__internal_9a1bdee989e5ed3a7d75b645a4cde211eef9fc7a34f57593cbeea5fdb177b723_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:login.html.twig"));

        $__internal_ad745d413507f7db2aa0ec5b200e4d53709f9f5ab0c94e0abe6fe870700ddfb8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad745d413507f7db2aa0ec5b200e4d53709f9f5ab0c94e0abe6fe870700ddfb8->enter($__internal_ad745d413507f7db2aa0ec5b200e4d53709f9f5ab0c94e0abe6fe870700ddfb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9a1bdee989e5ed3a7d75b645a4cde211eef9fc7a34f57593cbeea5fdb177b723->leave($__internal_9a1bdee989e5ed3a7d75b645a4cde211eef9fc7a34f57593cbeea5fdb177b723_prof);

        
        $__internal_ad745d413507f7db2aa0ec5b200e4d53709f9f5ab0c94e0abe6fe870700ddfb8->leave($__internal_ad745d413507f7db2aa0ec5b200e4d53709f9f5ab0c94e0abe6fe870700ddfb8_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_29904ffcd55b7954c9228c6ab9d9064a4ab3e36645a4311fd7080f652543faa5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29904ffcd55b7954c9228c6ab9d9064a4ab3e36645a4311fd7080f652543faa5->enter($__internal_29904ffcd55b7954c9228c6ab9d9064a4ab3e36645a4311fd7080f652543faa5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_756b0ac07dc9abe725a4b944c3bba2fd0a6078fab90ef342b2956cbb602702ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_756b0ac07dc9abe725a4b944c3bba2fd0a6078fab90ef342b2956cbb602702ca->enter($__internal_756b0ac07dc9abe725a4b944c3bba2fd0a6078fab90ef342b2956cbb602702ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <h3 style=\"text-align: center; font-family: Pacifico; font-size: 40px ;margin-bottom: 30px; margin-top: 40px\">Connexion</h3>

    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "flashes", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 9
            echo "        <div style=\"text-align: center;\" class=\"flash-notice alert alert-info\">
            <strong>";
            // line 10
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</strong>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "
   ";
        // line 15
        echo "    <div class=\"col-sm-3\"></div>
      <div style=\"font-family: Verdana\" class=\"formdiv col-sm-6\">
          <form action=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login_check");
        echo "\" method=\"post\">
            <div class=\"form-group\">
               <label for=\"username\">Nom d'utilisateur: </label><br>
               <input class=\"form-control\" placeholder=\"Nom et Prénom\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" />
            </div>
            <div class=\"form-group\">
               <label for=\"password\">Mot de passe :</label><br>
               <input class=\"form-control\" type=\"password\" placeholder=\"**********\" id=\"userpwd\" name=\"_password\" />
            </div>
             <div class=\"checkbox\">
                 <label style=\"font-family: Verdana ;font-weight: normal ;float: right; max-width:96%; margin-top: 5px; margin-bottom: 20px; margin-right: 35px;\"><input id=\"showhide\" type=\"checkbox\" style=\"margin-right: 5px;\"> Montrer/Cacher le mot de passe</label>
             </div><br>
            <input id=\"connectbtn\" type=\"submit\" value=\"Connexion\" />
         </form>
          <p style=\"text-align: center; margin-top: 10px\"> Si vous n'avez pas de compte, cliquez sur
              <a style=\"margin-top: 10px ;text-align: center\" href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_user_signup");
        echo "\">Inscription</a>
          </p>
      </div>
   <div class=\"col-sm-3\"></div>

   ";
        // line 38
        echo "
   ";
        // line 40
        echo "   ";
        // line 41
        echo "       ";
        // line 42
        echo "
        ";
        // line 44
        echo "       ";
        // line 45
        echo "
      ";
        // line 47
        echo "           ";
        // line 48
        echo "          ";
        // line 49
        echo "           ";
        // line 50
        echo "          ";
        // line 51
        echo "      ";
        // line 52
        echo "      ";
        // line 53
        echo "           ";
        // line 54
        echo "          ";
        // line 55
        echo "           ";
        // line 56
        echo "          ";
        // line 57
        echo "      ";
        // line 58
        echo "
      ";
        // line 60
        echo "         ";
        // line 61
        echo "      ";
        // line 62
        echo "      ";
        // line 63
        echo "          ";
        // line 64
        echo "          ";
        // line 65
        echo "      ";
        // line 66
        echo "       ";
        // line 67
        echo "      ";
        // line 68
        echo "         ";
        // line 69
        echo "      ";
        // line 70
        echo "   ";
        // line 71
        echo "   ";
        // line 72
        echo "

";
        
        $__internal_756b0ac07dc9abe725a4b944c3bba2fd0a6078fab90ef342b2956cbb602702ca->leave($__internal_756b0ac07dc9abe725a4b944c3bba2fd0a6078fab90ef342b2956cbb602702ca_prof);

        
        $__internal_29904ffcd55b7954c9228c6ab9d9064a4ab3e36645a4311fd7080f652543faa5->leave($__internal_29904ffcd55b7954c9228c6ab9d9064a4ab3e36645a4311fd7080f652543faa5_prof);

    }

    public function getTemplateName()
    {
        return "ProjetUserBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 72,  167 => 71,  165 => 70,  163 => 69,  161 => 68,  159 => 67,  157 => 66,  155 => 65,  153 => 64,  151 => 63,  149 => 62,  147 => 61,  145 => 60,  142 => 58,  140 => 57,  138 => 56,  136 => 55,  134 => 54,  132 => 53,  130 => 52,  128 => 51,  126 => 50,  124 => 49,  122 => 48,  120 => 47,  117 => 45,  115 => 44,  112 => 42,  110 => 41,  108 => 40,  105 => 38,  97 => 32,  82 => 20,  76 => 17,  72 => 15,  69 => 13,  60 => 10,  57 => 9,  53 => 8,  49 => 6,  40 => 5,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/UserBundle/Resources/views/Security/login.html.twig #}

{% extends \"ProjetMainBundle:Main:layout.html.twig\" %}

{% block content %}
    <h3 style=\"text-align: center; font-family: Pacifico; font-size: 40px ;margin-bottom: 30px; margin-top: 40px\">Connexion</h3>

    {% for message in app.flashes('notice') %}
        <div style=\"text-align: center;\" class=\"flash-notice alert alert-info\">
            <strong>{{ message }}</strong>
        </div>
    {% endfor %}

   {# Le formulaire, avec URL de soumission vers la route « login_check » comme on l'a vu #}
    <div class=\"col-sm-3\"></div>
      <div style=\"font-family: Verdana\" class=\"formdiv col-sm-6\">
          <form action=\"{{ path('login_check') }}\" method=\"post\">
            <div class=\"form-group\">
               <label for=\"username\">Nom d'utilisateur: </label><br>
               <input class=\"form-control\" placeholder=\"Nom et Prénom\" type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" />
            </div>
            <div class=\"form-group\">
               <label for=\"password\">Mot de passe :</label><br>
               <input class=\"form-control\" type=\"password\" placeholder=\"**********\" id=\"userpwd\" name=\"_password\" />
            </div>
             <div class=\"checkbox\">
                 <label style=\"font-family: Verdana ;font-weight: normal ;float: right; max-width:96%; margin-top: 5px; margin-bottom: 20px; margin-right: 35px;\"><input id=\"showhide\" type=\"checkbox\" style=\"margin-right: 5px;\"> Montrer/Cacher le mot de passe</label>
             </div><br>
            <input id=\"connectbtn\" type=\"submit\" value=\"Connexion\" />
         </form>
          <p style=\"text-align: center; margin-top: 10px\"> Si vous n'avez pas de compte, cliquez sur
              <a style=\"margin-top: 10px ;text-align: center\" href=\"{{ path('projet_user_signup') }}\">Inscription</a>
          </p>
      </div>
   <div class=\"col-sm-3\"></div>

   {#<h3 style=\"text-align: center; font-family: Pacifico; font-size: 40px ;margin-bottom: 30px; margin-top: 40px\">Connexion</h3>#}

   {#<div class=\"col-sm-3\"></div>#}
   {#<div style=\"font-family: Verdana\" class=\"formdiv col-sm-6\">#}
       {#{{ form_start(connect,{'attr': {'method': 'post',}}) }}#}

        {#Les erreurs générales du connect.#}
       {#{{ form_errors(connect) }}#}

      {#<div class=\"form-group\">#}
           {#Génération du label.#}
          {#{{ form_label(connect.mail, \"Nom d'utilisateur:\", {'attr': {'class': 'formlabel'}}) }}#}
           {#Génération de l'input.#}
          {#{{ form_widget(connect.mail,{'attr':{'class':'form-control','placeholder':'Nom et prénom'}} ) }}#}
      {#</div>#}
      {#<div class=\"form-group\">#}
           {#Génération du label.#}
          {#{{ form_label(connect.pwd, \"Password:\", {'attr': {'class': 'formlabel'}}) }}#}
           {#Génération de l'input.#}
          {#{{ form_widget(connect.pwd,{'attr':{'class':'form-control','type':'password','placeholder':'********'}} ) }}#}
      {#</div>#}

      {#<div class=\"checkbox\">#}
         {#<label style=\"font-family: Verdana ;font-weight: normal ;float: right; max-width:96%; margin-top: 5px; margin-bottom: 20px; margin-right: 35px;\"><input id=\"showhide\" type=\"checkbox\" style=\"margin-right: 5px;\"> Montrer/Cacher le mot de passe</label>#}
      {#</div><br>#}
      {#<div style=\"text-align: center\">#}
          {#{{ form_widget(form.connecttion) }}<br>#}
          {#{{ form_widget(connect.login,{'attr':{'type':'submit'}}) }}#}
      {#</div>#}
       {#{{ form_end(connect) }}#}
      {#<p style=\"text-align: center; margin-top: 10px\"> Si vous n'avez pas de compte, cliquez sur#}
         {#<a style=\"margin-top: 10px ;text-align: center\" href=\"{{ path('projet_main_signup') }}\">Inscription</a>#}
      {#</p>#}
   {#</div>#}
   {#<div class=\"col-sm-3\"></div>#}


{% endblock %}", "ProjetUserBundle:Security:login.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/UserBundle/Resources/views/Security/login.html.twig");
    }
}
