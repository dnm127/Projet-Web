<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_923e12f13ddb2b4b9ab038d5945350dd0c48a12610aa6a9b95956e3a6613ee90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68cf1d839310b7f85b37f0f3ff02625654cbdddce617a7d22d21bd46509d5ea3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68cf1d839310b7f85b37f0f3ff02625654cbdddce617a7d22d21bd46509d5ea3->enter($__internal_68cf1d839310b7f85b37f0f3ff02625654cbdddce617a7d22d21bd46509d5ea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $__internal_7d43a8ec44f827ccec2340208cf82b080e8898a73f69f921a58542c00bad8057 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d43a8ec44f827ccec2340208cf82b080e8898a73f69f921a58542c00bad8057->enter($__internal_7d43a8ec44f827ccec2340208cf82b080e8898a73f69f921a58542c00bad8057_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_68cf1d839310b7f85b37f0f3ff02625654cbdddce617a7d22d21bd46509d5ea3->leave($__internal_68cf1d839310b7f85b37f0f3ff02625654cbdddce617a7d22d21bd46509d5ea3_prof);

        
        $__internal_7d43a8ec44f827ccec2340208cf82b080e8898a73f69f921a58542c00bad8057->leave($__internal_7d43a8ec44f827ccec2340208cf82b080e8898a73f69f921a58542c00bad8057_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_15e77da48f45460414e4b1a2ceb99b76e221fc9b05c70baad3c29f209a8f229c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15e77da48f45460414e4b1a2ceb99b76e221fc9b05c70baad3c29f209a8f229c->enter($__internal_15e77da48f45460414e4b1a2ceb99b76e221fc9b05c70baad3c29f209a8f229c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_22e843b3271170022be670a6c562f5045061c678fff01179e2084f76959a3c6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22e843b3271170022be670a6c562f5045061c678fff01179e2084f76959a3c6a->enter($__internal_22e843b3271170022be670a6c562f5045061c678fff01179e2084f76959a3c6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Profile/show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_22e843b3271170022be670a6c562f5045061c678fff01179e2084f76959a3c6a->leave($__internal_22e843b3271170022be670a6c562f5045061c678fff01179e2084f76959a3c6a_prof);

        
        $__internal_15e77da48f45460414e4b1a2ceb99b76e221fc9b05c70baad3c29f209a8f229c->leave($__internal_15e77da48f45460414e4b1a2ceb99b76e221fc9b05c70baad3c29f209a8f229c_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Profile/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:show.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/show.html.twig");
    }
}
