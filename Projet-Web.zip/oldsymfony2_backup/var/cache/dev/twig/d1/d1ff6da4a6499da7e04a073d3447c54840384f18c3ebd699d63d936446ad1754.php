<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_8bd0757cf4afe44e6e46239db1cedc365d0f275bd26d0ce2abe03d08077f1d2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa9efe655a7ff392f071df5abea8047acc3f90001e688619b2aaabb04cfcf010 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa9efe655a7ff392f071df5abea8047acc3f90001e688619b2aaabb04cfcf010->enter($__internal_aa9efe655a7ff392f071df5abea8047acc3f90001e688619b2aaabb04cfcf010_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_9609cefafc95c24bb564dea8efa80db2bc4406ef81695aa94a57ba9bd5525038 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9609cefafc95c24bb564dea8efa80db2bc4406ef81695aa94a57ba9bd5525038->enter($__internal_9609cefafc95c24bb564dea8efa80db2bc4406ef81695aa94a57ba9bd5525038_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_aa9efe655a7ff392f071df5abea8047acc3f90001e688619b2aaabb04cfcf010->leave($__internal_aa9efe655a7ff392f071df5abea8047acc3f90001e688619b2aaabb04cfcf010_prof);

        
        $__internal_9609cefafc95c24bb564dea8efa80db2bc4406ef81695aa94a57ba9bd5525038->leave($__internal_9609cefafc95c24bb564dea8efa80db2bc4406ef81695aa94a57ba9bd5525038_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
