<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_851e4cecf476be3fc85b3a116a496730c5c50eca6d6d9590627e5817d0eaff9c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_74752231e9bcca6c301461f7ed6fa036b8af3af5e9a074a68d8a93bbea0bb6c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74752231e9bcca6c301461f7ed6fa036b8af3af5e9a074a68d8a93bbea0bb6c1->enter($__internal_74752231e9bcca6c301461f7ed6fa036b8af3af5e9a074a68d8a93bbea0bb6c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_28a8e501c00b3242d10cbdb98f9d421f77ad5ed44a1ab5159c23b0a6836420c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28a8e501c00b3242d10cbdb98f9d421f77ad5ed44a1ab5159c23b0a6836420c6->enter($__internal_28a8e501c00b3242d10cbdb98f9d421f77ad5ed44a1ab5159c23b0a6836420c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_74752231e9bcca6c301461f7ed6fa036b8af3af5e9a074a68d8a93bbea0bb6c1->leave($__internal_74752231e9bcca6c301461f7ed6fa036b8af3af5e9a074a68d8a93bbea0bb6c1_prof);

        
        $__internal_28a8e501c00b3242d10cbdb98f9d421f77ad5ed44a1ab5159c23b0a6836420c6->leave($__internal_28a8e501c00b3242d10cbdb98f9d421f77ad5ed44a1ab5159c23b0a6836420c6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
