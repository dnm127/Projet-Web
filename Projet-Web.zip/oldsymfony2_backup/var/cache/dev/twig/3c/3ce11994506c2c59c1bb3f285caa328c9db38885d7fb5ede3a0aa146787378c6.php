<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_d55969e6d0bb87342fcf80815e243d99d37bd5f1a2552cfbeee955bb82ad3dc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1f52b6964594dcaa0fbf528e7e86b3fe9dbc2a8d950227b720f9fb23e1f2970 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1f52b6964594dcaa0fbf528e7e86b3fe9dbc2a8d950227b720f9fb23e1f2970->enter($__internal_f1f52b6964594dcaa0fbf528e7e86b3fe9dbc2a8d950227b720f9fb23e1f2970_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_5d3b3e381de413b62ea29c8fe8a01c9608ca6469a54a0f756298d9c446e874d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d3b3e381de413b62ea29c8fe8a01c9608ca6469a54a0f756298d9c446e874d5->enter($__internal_5d3b3e381de413b62ea29c8fe8a01c9608ca6469a54a0f756298d9c446e874d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f1f52b6964594dcaa0fbf528e7e86b3fe9dbc2a8d950227b720f9fb23e1f2970->leave($__internal_f1f52b6964594dcaa0fbf528e7e86b3fe9dbc2a8d950227b720f9fb23e1f2970_prof);

        
        $__internal_5d3b3e381de413b62ea29c8fe8a01c9608ca6469a54a0f756298d9c446e874d5->leave($__internal_5d3b3e381de413b62ea29c8fe8a01c9608ca6469a54a0f756298d9c446e874d5_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_650e2c24cd1d30a20e092b88a3f33026ea29dab30c427766661ad0efb9a70b5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_650e2c24cd1d30a20e092b88a3f33026ea29dab30c427766661ad0efb9a70b5a->enter($__internal_650e2c24cd1d30a20e092b88a3f33026ea29dab30c427766661ad0efb9a70b5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_80cb8797a0cd90b9d55f2733bd4b47ab0f937037934c1bcdf07262f7bba4af2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80cb8797a0cd90b9d55f2733bd4b47ab0f937037934c1bcdf07262f7bba4af2c->enter($__internal_80cb8797a0cd90b9d55f2733bd4b47ab0f937037934c1bcdf07262f7bba4af2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_80cb8797a0cd90b9d55f2733bd4b47ab0f937037934c1bcdf07262f7bba4af2c->leave($__internal_80cb8797a0cd90b9d55f2733bd4b47ab0f937037934c1bcdf07262f7bba4af2c_prof);

        
        $__internal_650e2c24cd1d30a20e092b88a3f33026ea29dab30c427766661ad0efb9a70b5a->leave($__internal_650e2c24cd1d30a20e092b88a3f33026ea29dab30c427766661ad0efb9a70b5a_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_e5ed32414f7efa37f45625401b99a3683e3ed03abf998a94f805a67fb986bd0a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5ed32414f7efa37f45625401b99a3683e3ed03abf998a94f805a67fb986bd0a->enter($__internal_e5ed32414f7efa37f45625401b99a3683e3ed03abf998a94f805a67fb986bd0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_99dafea445f9f313af959541023dcd80afed711eb559e96b2e450cf322de9172 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99dafea445f9f313af959541023dcd80afed711eb559e96b2e450cf322de9172->enter($__internal_99dafea445f9f313af959541023dcd80afed711eb559e96b2e450cf322de9172_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_99dafea445f9f313af959541023dcd80afed711eb559e96b2e450cf322de9172->leave($__internal_99dafea445f9f313af959541023dcd80afed711eb559e96b2e450cf322de9172_prof);

        
        $__internal_e5ed32414f7efa37f45625401b99a3683e3ed03abf998a94f805a67fb986bd0a->leave($__internal_e5ed32414f7efa37f45625401b99a3683e3ed03abf998a94f805a67fb986bd0a_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
