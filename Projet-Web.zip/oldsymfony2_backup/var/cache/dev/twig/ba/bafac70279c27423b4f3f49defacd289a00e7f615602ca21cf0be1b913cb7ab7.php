<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_f7a994cb7ae0ac904ffa045d23c30d3c82602fd72d94f480348f5e5fc3e32883 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13039874e345c51c6331e4218b57493bbaf1e81d785e0ae0cd81c803dc0abf50 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13039874e345c51c6331e4218b57493bbaf1e81d785e0ae0cd81c803dc0abf50->enter($__internal_13039874e345c51c6331e4218b57493bbaf1e81d785e0ae0cd81c803dc0abf50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $__internal_3906805de0fcd2f3ae978711923eef28a0f3579ac529d51281ad90195c97cdb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3906805de0fcd2f3ae978711923eef28a0f3579ac529d51281ad90195c97cdb0->enter($__internal_3906805de0fcd2f3ae978711923eef28a0f3579ac529d51281ad90195c97cdb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13039874e345c51c6331e4218b57493bbaf1e81d785e0ae0cd81c803dc0abf50->leave($__internal_13039874e345c51c6331e4218b57493bbaf1e81d785e0ae0cd81c803dc0abf50_prof);

        
        $__internal_3906805de0fcd2f3ae978711923eef28a0f3579ac529d51281ad90195c97cdb0->leave($__internal_3906805de0fcd2f3ae978711923eef28a0f3579ac529d51281ad90195c97cdb0_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b56be88c90a16714df4affd9f0a3eaf7f35a0e7b0cbeae1fd3d89cf900314008 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b56be88c90a16714df4affd9f0a3eaf7f35a0e7b0cbeae1fd3d89cf900314008->enter($__internal_b56be88c90a16714df4affd9f0a3eaf7f35a0e7b0cbeae1fd3d89cf900314008_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_1b25b6f1d674577f6743b54add2bc814358630d24f8d3a187324cee6cb147708 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b25b6f1d674577f6743b54add2bc814358630d24f8d3a187324cee6cb147708->enter($__internal_1b25b6f1d674577f6743b54add2bc814358630d24f8d3a187324cee6cb147708_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_1b25b6f1d674577f6743b54add2bc814358630d24f8d3a187324cee6cb147708->leave($__internal_1b25b6f1d674577f6743b54add2bc814358630d24f8d3a187324cee6cb147708_prof);

        
        $__internal_b56be88c90a16714df4affd9f0a3eaf7f35a0e7b0cbeae1fd3d89cf900314008->leave($__internal_b56be88c90a16714df4affd9f0a3eaf7f35a0e7b0cbeae1fd3d89cf900314008_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/request_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:request.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/request.html.twig");
    }
}
