<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_a7f5e08d53e4c3b3ec0bebae927dcb6eef934298b1a5c18c9caeb518c38b62d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20a2906e30fb8054afb87b21223aec185f8adb8914e66a15ba67fed5b81f5e4b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_20a2906e30fb8054afb87b21223aec185f8adb8914e66a15ba67fed5b81f5e4b->enter($__internal_20a2906e30fb8054afb87b21223aec185f8adb8914e66a15ba67fed5b81f5e4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_659168aa71ca0140002afec2c1176995b5bc52068f2aff65b7f9c27beae1778d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_659168aa71ca0140002afec2c1176995b5bc52068f2aff65b7f9c27beae1778d->enter($__internal_659168aa71ca0140002afec2c1176995b5bc52068f2aff65b7f9c27beae1778d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_20a2906e30fb8054afb87b21223aec185f8adb8914e66a15ba67fed5b81f5e4b->leave($__internal_20a2906e30fb8054afb87b21223aec185f8adb8914e66a15ba67fed5b81f5e4b_prof);

        
        $__internal_659168aa71ca0140002afec2c1176995b5bc52068f2aff65b7f9c27beae1778d->leave($__internal_659168aa71ca0140002afec2c1176995b5bc52068f2aff65b7f9c27beae1778d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget_expanded.html.php");
    }
}
