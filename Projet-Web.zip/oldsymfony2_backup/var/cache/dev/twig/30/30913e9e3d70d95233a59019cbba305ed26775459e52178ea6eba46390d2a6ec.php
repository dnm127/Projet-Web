<?php

/* ProjetUserBundle:Default:index.html.twig */
class __TwigTemplate_e87d55824d7d41f0a31471c1222f3d6361b9d346c49f9f619781ef8d3f237ed4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d4385fc46c5d8da52134f300791346749647a93ca675031b7c910a2714b559ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4385fc46c5d8da52134f300791346749647a93ca675031b7c910a2714b559ef->enter($__internal_d4385fc46c5d8da52134f300791346749647a93ca675031b7c910a2714b559ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Default:index.html.twig"));

        $__internal_e96418f6472cf2d3ecd63747a3469abd99fb2578523ce41007dd086d4cdfe418 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e96418f6472cf2d3ecd63747a3469abd99fb2578523ce41007dd086d4cdfe418->enter($__internal_e96418f6472cf2d3ecd63747a3469abd99fb2578523ce41007dd086d4cdfe418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_d4385fc46c5d8da52134f300791346749647a93ca675031b7c910a2714b559ef->leave($__internal_d4385fc46c5d8da52134f300791346749647a93ca675031b7c910a2714b559ef_prof);

        
        $__internal_e96418f6472cf2d3ecd63747a3469abd99fb2578523ce41007dd086d4cdfe418->leave($__internal_e96418f6472cf2d3ecd63747a3469abd99fb2578523ce41007dd086d4cdfe418_prof);

    }

    public function getTemplateName()
    {
        return "ProjetUserBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!
", "ProjetUserBundle:Default:index.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/UserBundle/Resources/views/Default/index.html.twig");
    }
}
