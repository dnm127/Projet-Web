<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_a9d39dd2e4992fe9825fd11c3a6b42aa3e3342977b90acc6d483f30dfbfae0f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b1ebaa2feac9b727cd46c345f2755561ea78c7eecf09541cd1c7cf78fb2b6945 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b1ebaa2feac9b727cd46c345f2755561ea78c7eecf09541cd1c7cf78fb2b6945->enter($__internal_b1ebaa2feac9b727cd46c345f2755561ea78c7eecf09541cd1c7cf78fb2b6945_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_c67ae525d9b831505fd79daaa7167177bffde52d0828007cdeb47437db45d442 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c67ae525d9b831505fd79daaa7167177bffde52d0828007cdeb47437db45d442->enter($__internal_c67ae525d9b831505fd79daaa7167177bffde52d0828007cdeb47437db45d442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_b1ebaa2feac9b727cd46c345f2755561ea78c7eecf09541cd1c7cf78fb2b6945->leave($__internal_b1ebaa2feac9b727cd46c345f2755561ea78c7eecf09541cd1c7cf78fb2b6945_prof);

        
        $__internal_c67ae525d9b831505fd79daaa7167177bffde52d0828007cdeb47437db45d442->leave($__internal_c67ae525d9b831505fd79daaa7167177bffde52d0828007cdeb47437db45d442_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}
