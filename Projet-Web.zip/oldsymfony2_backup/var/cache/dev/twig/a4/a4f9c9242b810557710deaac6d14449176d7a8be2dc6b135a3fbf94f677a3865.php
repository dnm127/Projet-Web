<?php

/* FOSUserBundle:Resetting:check_email.html.twig */
class __TwigTemplate_81ca8da0b53382229a39f12946346680d45b6377caa3c668c79ea341cee26330 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_becbb734b4c6e5eb0a024e474e2c152a33f3f918968a9e3859ba2ccbd8ad7173 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_becbb734b4c6e5eb0a024e474e2c152a33f3f918968a9e3859ba2ccbd8ad7173->enter($__internal_becbb734b4c6e5eb0a024e474e2c152a33f3f918968a9e3859ba2ccbd8ad7173_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $__internal_3a6168e07882840dc3f5859c1771bf9a5b9c55e2340f286586ddc666be436171 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a6168e07882840dc3f5859c1771bf9a5b9c55e2340f286586ddc666be436171->enter($__internal_3a6168e07882840dc3f5859c1771bf9a5b9c55e2340f286586ddc666be436171_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_becbb734b4c6e5eb0a024e474e2c152a33f3f918968a9e3859ba2ccbd8ad7173->leave($__internal_becbb734b4c6e5eb0a024e474e2c152a33f3f918968a9e3859ba2ccbd8ad7173_prof);

        
        $__internal_3a6168e07882840dc3f5859c1771bf9a5b9c55e2340f286586ddc666be436171->leave($__internal_3a6168e07882840dc3f5859c1771bf9a5b9c55e2340f286586ddc666be436171_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_2676309a91ef594bbf4caf1876bfc943b9e52af425a3ca1637c40b517ccf246f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2676309a91ef594bbf4caf1876bfc943b9e52af425a3ca1637c40b517ccf246f->enter($__internal_2676309a91ef594bbf4caf1876bfc943b9e52af425a3ca1637c40b517ccf246f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_2378aeea604ca9aa94bf0baee15764d99bf11de59b0f18b791ae92d82d92e8d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2378aeea604ca9aa94bf0baee15764d99bf11de59b0f18b791ae92d82d92e8d9->enter($__internal_2378aeea604ca9aa94bf0baee15764d99bf11de59b0f18b791ae92d82d92e8d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo nl2br(twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.check_email", array("%tokenLifetime%" => (isset($context["tokenLifetime"]) ? $context["tokenLifetime"] : $this->getContext($context, "tokenLifetime"))), "FOSUserBundle"), "html", null, true));
        echo "
</p>
";
        
        $__internal_2378aeea604ca9aa94bf0baee15764d99bf11de59b0f18b791ae92d82d92e8d9->leave($__internal_2378aeea604ca9aa94bf0baee15764d99bf11de59b0f18b791ae92d82d92e8d9_prof);

        
        $__internal_2676309a91ef594bbf4caf1876bfc943b9e52af425a3ca1637c40b517ccf246f->leave($__internal_2676309a91ef594bbf4caf1876bfc943b9e52af425a3ca1637c40b517ccf246f_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 7,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
<p>
{{ 'resetting.check_email'|trans({'%tokenLifetime%': tokenLifetime})|nl2br }}
</p>
{% endblock %}
", "FOSUserBundle:Resetting:check_email.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/check_email.html.twig");
    }
}
