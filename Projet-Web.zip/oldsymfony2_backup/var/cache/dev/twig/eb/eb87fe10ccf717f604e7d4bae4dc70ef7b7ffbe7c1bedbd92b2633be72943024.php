<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_d38be9daee816618b8662238779cbab805f2e030bf53495e9f39d8b25285740f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_72026c5872947e6400f30219b450debe491660a3a264b831683d052d55229945 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_72026c5872947e6400f30219b450debe491660a3a264b831683d052d55229945->enter($__internal_72026c5872947e6400f30219b450debe491660a3a264b831683d052d55229945_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_cfda9df1899699b42b8e2800b25c9dbd48acde23925b0bdfb423f77618e49312 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfda9df1899699b42b8e2800b25c9dbd48acde23925b0bdfb423f77618e49312->enter($__internal_cfda9df1899699b42b8e2800b25c9dbd48acde23925b0bdfb423f77618e49312_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_72026c5872947e6400f30219b450debe491660a3a264b831683d052d55229945->leave($__internal_72026c5872947e6400f30219b450debe491660a3a264b831683d052d55229945_prof);

        
        $__internal_cfda9df1899699b42b8e2800b25c9dbd48acde23925b0bdfb423f77618e49312->leave($__internal_cfda9df1899699b42b8e2800b25c9dbd48acde23925b0bdfb423f77618e49312_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
