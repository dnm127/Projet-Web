<?php

/* ProjetMainBundle:Main:upload.html.twig */
class __TwigTemplate_50e335ea6101cd5a9172d29dc204ac9adc666df32c1c2c70129a5c66865f4dcf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetMainBundle:Main:upload.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2d35090ae4fa979dfdd2ada9f2440931f3c18436da11bc4ae19bf221a9f0b9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2d35090ae4fa979dfdd2ada9f2440931f3c18436da11bc4ae19bf221a9f0b9e->enter($__internal_b2d35090ae4fa979dfdd2ada9f2440931f3c18436da11bc4ae19bf221a9f0b9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:upload.html.twig"));

        $__internal_40ba8feaca32c668920467ed46d8458acaf1cb1f23d69ea9cc5028ba1fa941d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40ba8feaca32c668920467ed46d8458acaf1cb1f23d69ea9cc5028ba1fa941d7->enter($__internal_40ba8feaca32c668920467ed46d8458acaf1cb1f23d69ea9cc5028ba1fa941d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:upload.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b2d35090ae4fa979dfdd2ada9f2440931f3c18436da11bc4ae19bf221a9f0b9e->leave($__internal_b2d35090ae4fa979dfdd2ada9f2440931f3c18436da11bc4ae19bf221a9f0b9e_prof);

        
        $__internal_40ba8feaca32c668920467ed46d8458acaf1cb1f23d69ea9cc5028ba1fa941d7->leave($__internal_40ba8feaca32c668920467ed46d8458acaf1cb1f23d69ea9cc5028ba1fa941d7_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_71f12fa5202c947a917aea34cbed36ea33107486aeb7199b6e892f4de744d49a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_71f12fa5202c947a917aea34cbed36ea33107486aeb7199b6e892f4de744d49a->enter($__internal_71f12fa5202c947a917aea34cbed36ea33107486aeb7199b6e892f4de744d49a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_bef1cfda0a0f53cbf6def7b4a30c48699e8769fbc8d1c09f419a247ee6bf44c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bef1cfda0a0f53cbf6def7b4a30c48699e8769fbc8d1c09f419a247ee6bf44c5->enter($__internal_bef1cfda0a0f53cbf6def7b4a30c48699e8769fbc8d1c09f419a247ee6bf44c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h3 style=\"text-align: center; font-family: Pacifico; font-size: 40px ;margin-bottom: 30px; margin-top: 40px\">Déposer votre video</h3>

    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "flashes", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 7
            echo "        <div class=\"flash-notice alert alert-success\">
            <strong>";
            // line 8
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</strong>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "
    <div class=\"col-sm-3\"></div>
    <div style=\"font-family: Verdana\" class=\"formdiv col-sm-6\">
        ";
        // line 14
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), 'form_start');
        echo "

        ";
        // line 17
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), 'errors');
        echo "

    <div class=\"form-group\">
            ";
        // line 21
        echo "            ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "title", array()), 'label', array("attr" => array("class" => "formlabel"), "label" => "Titre de vidéo"));
        echo "
            ";
        // line 23
        echo "            ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "title", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Titre")));
        echo "
        </div>
        <div class=\"form-group\">
            ";
        // line 27
        echo "            ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "src", array()), 'label', array("attr" => array("class" => "formlabel"), "label" => "Source de vidéo sur Youtube:"));
        echo "
            ";
        // line 29
        echo "            ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "src", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Lien de Youtube de vidéo")));
        echo "
        </div>
        <div class=\"form-group\">
            ";
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "instruction", array()), 'label', array("attr" => array("class" => "formlabel"), "label" => "Instruction"));
        echo "
            ";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "instruction", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => " Étape 1: 

 Étape 2: 

 Érape 3:")));
        echo "
        </div>
        <span style=\"margin-bottom: 15px; font-weight: bold\">Choisissez la catégeorie de votre vidéo <button type=\"button\" class=\"btn btn-info\" id=\"annuler\">Annuler</button> </span>
        <div style=\"padding-left: 15px\" class=\"form-radio\">
            <p style=\"margin-bottom: 15px\"></p>
            ";
        // line 38
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat0", array()), 'widget', array("attr" => array("style" => "margin-left:7px ;margin-right: 5px", "name" => "critere")));
        echo "
            ";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat0", array()), 'label', array("attr" => array("class" => "radiobtn"), "label" => "Entrée"));
        echo "

            ";
        // line 41
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat1", array()), 'widget', array("attr" => array("style" => "margin-left:7px ;margin-right: 5px", "name" => "critere")));
        echo "
            ";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat1", array()), 'label', array("attr" => array("class" => "radiobtn"), "label" => "Plat"));
        echo "

            ";
        // line 44
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat2", array()), 'widget', array("attr" => array("style" => "margin-left:7px ;margin-right: 5px", "name" => "critere")));
        echo "
            ";
        // line 45
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat2", array()), 'label', array("attr" => array("class" => "radiobtn"), "label" => "Dessert"));
        echo "

            ";
        // line 47
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat3", array()), 'widget', array("attr" => array("style" => "margin-left:7px ;margin-right: 5px", "name" => "critere")));
        echo "
            ";
        // line 48
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat3", array()), 'label', array("attr" => array("class" => "radiobtn"), "label" => "Boisson"));
        echo "

            ";
        // line 50
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat4", array()), 'widget', array("attr" => array("style" => "margin-left:7px ;margin-right: 5px", "name" => "critere")));
        echo "
            ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat4", array()), 'label', array("attr" => array("class" => "radiobtn"), "label" => "Soupe"));
        echo "

            ";
        // line 53
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat5", array()), 'widget', array("attr" => array("style" => "margin-left:7px ;margin-right: 5px", "name" => "critere")));
        echo "
            ";
        // line 54
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), "cat5", array()), 'label', array("attr" => array("class" => "radiobtn"), "label" => "Sauce"));
        echo "

            ";
        // line 56
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["upload"]) ? $context["upload"] : $this->getContext($context, "upload")), 'form_end');
        echo "
        <p style=\"text-align: center; margin-top: 10px\"> Merci de coller le lien <strong>Youtube</strong> de votre video
        </p>
    </div>
    <div class=\"col-sm-3\"></div>

";
        
        $__internal_bef1cfda0a0f53cbf6def7b4a30c48699e8769fbc8d1c09f419a247ee6bf44c5->leave($__internal_bef1cfda0a0f53cbf6def7b4a30c48699e8769fbc8d1c09f419a247ee6bf44c5_prof);

        
        $__internal_71f12fa5202c947a917aea34cbed36ea33107486aeb7199b6e892f4de744d49a->leave($__internal_71f12fa5202c947a917aea34cbed36ea33107486aeb7199b6e892f4de744d49a_prof);

    }

    public function getTemplateName()
    {
        return "ProjetMainBundle:Main:upload.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  180 => 56,  175 => 54,  171 => 53,  166 => 51,  162 => 50,  157 => 48,  153 => 47,  148 => 45,  144 => 44,  139 => 42,  135 => 41,  130 => 39,  126 => 38,  114 => 33,  110 => 32,  103 => 29,  98 => 27,  91 => 23,  86 => 21,  79 => 17,  74 => 14,  69 => 11,  60 => 8,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'ProjetMainBundle:Main:layout.html.twig' %}

{% block content %}
    <h3 style=\"text-align: center; font-family: Pacifico; font-size: 40px ;margin-bottom: 30px; margin-top: 40px\">Déposer votre video</h3>

    {% for message in app.flashes('notice') %}
        <div class=\"flash-notice alert alert-success\">
            <strong>{{ message }}</strong>
        </div>
    {% endfor %}

    <div class=\"col-sm-3\"></div>
    <div style=\"font-family: Verdana\" class=\"formdiv col-sm-6\">
        {{ form_start(upload) }}

        {# Les erreurs générales du formulaire. #}
        {{ form_errors(upload) }}

    <div class=\"form-group\">
            {# Génération du label. #}
            {{ form_label(upload.title, \"Titre de vidéo\", {'attr': {'class': 'formlabel'}}) }}
            {# Génération de l'input. #}
            {{ form_widget(upload.title,{'attr':{'class':'form-control','placeholder':'Titre'}} ) }}
        </div>
        <div class=\"form-group\">
            {# Génération du label. #}
            {{ form_label(upload.src, \"Source de vidéo sur Youtube:\", {'attr': {'class': 'formlabel'}}) }}
            {# Génération de l'input. #}
            {{ form_widget(upload.src,{'attr':{'class':'form-control','placeholder':'Lien de Youtube de vidéo'}} ) }}
        </div>
        <div class=\"form-group\">
            {{ form_label(upload.instruction, \"Instruction\", {'attr': {'class': 'formlabel'}}) }}
            {{ form_widget(upload.instruction,{'attr':{'class':'form-control','placeholder':\" Étape 1: \\n\\n Étape 2: \\n\\n Érape 3:\"}} ) }}
        </div>
        <span style=\"margin-bottom: 15px; font-weight: bold\">Choisissez la catégeorie de votre vidéo <button type=\"button\" class=\"btn btn-info\" id=\"annuler\">Annuler</button> </span>
        <div style=\"padding-left: 15px\" class=\"form-radio\">
            <p style=\"margin-bottom: 15px\"></p>
            {{ form_widget(upload.cat0,{'attr':{'style':'margin-left:7px ;margin-right: 5px','name':'critere'}}) }}
            {{ form_label(upload.cat0,\"Entrée\",{'attr':{'class':'radiobtn'}}) }}

            {{ form_widget(upload.cat1,{'attr':{'style':'margin-left:7px ;margin-right: 5px','name':'critere'}}) }}
            {{ form_label(upload.cat1,\"Plat\",{'attr':{'class':'radiobtn'}}) }}

            {{ form_widget(upload.cat2,{'attr':{'style':'margin-left:7px ;margin-right: 5px','name':'critere'}}) }}
            {{ form_label(upload.cat2,\"Dessert\",{'attr':{'class':'radiobtn'}}) }}

            {{ form_widget(upload.cat3,{'attr':{'style':'margin-left:7px ;margin-right: 5px','name':'critere'}}) }}
            {{ form_label(upload.cat3,\"Boisson\",{'attr':{'class':'radiobtn'}}) }}

            {{ form_widget(upload.cat4,{'attr':{'style':'margin-left:7px ;margin-right: 5px','name':'critere'}}) }}
            {{ form_label(upload.cat4,\"Soupe\",{'attr':{'class':'radiobtn'}}) }}

            {{ form_widget(upload.cat5,{'attr':{'style':'margin-left:7px ;margin-right: 5px','name':'critere'}}) }}
            {{ form_label(upload.cat5,\"Sauce\",{'attr':{'class':'radiobtn'}}) }}

            {{ form_end(upload) }}
        <p style=\"text-align: center; margin-top: 10px\"> Merci de coller le lien <strong>Youtube</strong> de votre video
        </p>
    </div>
    <div class=\"col-sm-3\"></div>

{% endblock %}", "ProjetMainBundle:Main:upload.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/MainBundle/Resources/views/Main/upload.html.twig");
    }
}
