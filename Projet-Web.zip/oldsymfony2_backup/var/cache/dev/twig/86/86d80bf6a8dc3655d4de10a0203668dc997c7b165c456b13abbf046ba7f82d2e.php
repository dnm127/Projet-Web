<?php

/* ProjetUserBundle:Security:signup.html.twig */
class __TwigTemplate_677d55416ec1741e0099bb05cb91be08d7cc9ae89e3923261e3bc207d99683cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetUserBundle:Security:signup.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56d4a7ac85977f0a4c7ca6a16de252c9f0f7feb6521bc4ebaf1cf6cc33d00729 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_56d4a7ac85977f0a4c7ca6a16de252c9f0f7feb6521bc4ebaf1cf6cc33d00729->enter($__internal_56d4a7ac85977f0a4c7ca6a16de252c9f0f7feb6521bc4ebaf1cf6cc33d00729_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:signup.html.twig"));

        $__internal_c7535069f8d9b6496a47d74a5607fb6690e2b2fcf3700872feffa8f87d1b0cf2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7535069f8d9b6496a47d74a5607fb6690e2b2fcf3700872feffa8f87d1b0cf2->enter($__internal_c7535069f8d9b6496a47d74a5607fb6690e2b2fcf3700872feffa8f87d1b0cf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:signup.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_56d4a7ac85977f0a4c7ca6a16de252c9f0f7feb6521bc4ebaf1cf6cc33d00729->leave($__internal_56d4a7ac85977f0a4c7ca6a16de252c9f0f7feb6521bc4ebaf1cf6cc33d00729_prof);

        
        $__internal_c7535069f8d9b6496a47d74a5607fb6690e2b2fcf3700872feffa8f87d1b0cf2->leave($__internal_c7535069f8d9b6496a47d74a5607fb6690e2b2fcf3700872feffa8f87d1b0cf2_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_ee347848f64672b4f085915809c4bcf46fd28535a282eae94a5db6e6aa4919cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee347848f64672b4f085915809c4bcf46fd28535a282eae94a5db6e6aa4919cb->enter($__internal_ee347848f64672b4f085915809c4bcf46fd28535a282eae94a5db6e6aa4919cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_2947be2034465539ebd925dc6527e11e5beb95d0df65203449c5e57be7a5d7ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2947be2034465539ebd925dc6527e11e5beb95d0df65203449c5e57be7a5d7ca->enter($__internal_2947be2034465539ebd925dc6527e11e5beb95d0df65203449c5e57be7a5d7ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h3 style=\"text-align: center; font-family: Pacifico; font-size: 40px ;margin-bottom: 30px; margin-top: 40px\">Inscription</h3>

    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "flashes", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 7
            echo "        <div style=\"text-align: center;\" class=\"flash-notice alert alert-info\">
            <strong>";
            // line 8
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</strong>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "
    <div class=\"col-sm-3\"></div>
    <div style=\"font-family: Verdana\" class=\"formdiv col-sm-6\">
        ";
        // line 14
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

        ";
        // line 17
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

    <div class=\"form-group\">
        ";
        // line 21
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label', array("attr" => array("class" => "formlabel"), "label" => "Nom d'utilisateur:"));
        echo "
        ";
        // line 23
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nom et Prénom")));
        echo "
    </div>
    <div class=\"form-group\">
        ";
        // line 27
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mail", array()), 'label', array("attr" => array("class" => "formlabel"), "label" => "Email:"));
        echo "
        ";
        // line 29
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mail", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "nom.prenom@gmail.com")));
        echo "
    </div>
    <div class=\"form-group\">
        ";
        // line 33
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pwd", array()), 'label', array("attr" => array("class" => "formlabel"), "label" => "Password:"));
        echo "
        ";
        // line 35
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pwd", array()), 'widget', array("attr" => array("class" => "form-control", "type" => "password", "placeholder" => "********")));
        echo "
    </div>

    <div class=\"checkbox\">
        <label style=\"font-family: Verdana ;font-weight: normal ;float: right; max-width:96%; margin-top: 5px; margin-bottom: 20px; margin-right: 35px;\"><input id=\"showhide\" type=\"checkbox\" style=\"margin-right: 5px;\"> Montrer/Cacher le mot de passe</label>
    </div><br>
    <div style=\"text-align: center\">
        ";
        // line 43
        echo "        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "signup", array()), 'widget');
        echo "
    </div>
    ";
        // line 45
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <p style=\"text-align: center; margin-top: 10px\"> Si vous avez un compte, cliquez sur
        <a style=\"margin-top: 10px ;text-align: center\" href=\"";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_user_login");
        echo "\">Connexion</a>
    </p>
</div>
<div class=\"col-sm-3\"></div>

";
        
        $__internal_2947be2034465539ebd925dc6527e11e5beb95d0df65203449c5e57be7a5d7ca->leave($__internal_2947be2034465539ebd925dc6527e11e5beb95d0df65203449c5e57be7a5d7ca_prof);

        
        $__internal_ee347848f64672b4f085915809c4bcf46fd28535a282eae94a5db6e6aa4919cb->leave($__internal_ee347848f64672b4f085915809c4bcf46fd28535a282eae94a5db6e6aa4919cb_prof);

    }

    public function getTemplateName()
    {
        return "ProjetUserBundle:Security:signup.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 48,  132 => 45,  126 => 43,  115 => 35,  110 => 33,  103 => 29,  98 => 27,  91 => 23,  86 => 21,  79 => 17,  74 => 14,  69 => 11,  60 => 8,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'ProjetMainBundle:Main:layout.html.twig' %}

{% block content %}
    <h3 style=\"text-align: center; font-family: Pacifico; font-size: 40px ;margin-bottom: 30px; margin-top: 40px\">Inscription</h3>

    {% for message in app.flashes('notice') %}
        <div style=\"text-align: center;\" class=\"flash-notice alert alert-info\">
            <strong>{{ message }}</strong>
        </div>
    {% endfor %}

    <div class=\"col-sm-3\"></div>
    <div style=\"font-family: Verdana\" class=\"formdiv col-sm-6\">
        {{ form_start(form) }}

        {# Les erreurs générales du formulaire. #}
        {{ form_errors(form) }}

    <div class=\"form-group\">
        {# Génération du label. #}
        {{ form_label(form.name, \"Nom d'utilisateur:\", {'attr': {'class': 'formlabel'}}) }}
        {# Génération de l'input. #}
        {{ form_widget(form.name,{'attr':{'class':'form-control','placeholder':'Nom et Prénom'}} ) }}
    </div>
    <div class=\"form-group\">
        {# Génération du label. #}
        {{ form_label(form.mail, \"Email:\", {'attr': {'class': 'formlabel'}}) }}
        {# Génération de l'input. #}
        {{ form_widget(form.mail,{'attr':{'class':'form-control','placeholder':'nom.prenom@gmail.com'}} ) }}
    </div>
    <div class=\"form-group\">
        {# Génération du label. #}
        {{ form_label(form.pwd, \"Password:\", {'attr': {'class': 'formlabel'}}) }}
        {# Génération de l'input. #}
        {{ form_widget(form.pwd,{'attr':{'class':'form-control','type':'password','placeholder':'********'}} ) }}
    </div>

    <div class=\"checkbox\">
        <label style=\"font-family: Verdana ;font-weight: normal ;float: right; max-width:96%; margin-top: 5px; margin-bottom: 20px; margin-right: 35px;\"><input id=\"showhide\" type=\"checkbox\" style=\"margin-right: 5px;\"> Montrer/Cacher le mot de passe</label>
    </div><br>
    <div style=\"text-align: center\">
        {#{{ form_widget(form.connection) }}<br>#}
        {{ form_widget(form.signup) }}
    </div>
    {{ form_end(form) }}

    <p style=\"text-align: center; margin-top: 10px\"> Si vous avez un compte, cliquez sur
        <a style=\"margin-top: 10px ;text-align: center\" href=\"{{ path('projet_user_login') }}\">Connexion</a>
    </p>
</div>
<div class=\"col-sm-3\"></div>

{% endblock %}", "ProjetUserBundle:Security:signup.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/UserBundle/Resources/views/Security/signup.html.twig");
    }
}
