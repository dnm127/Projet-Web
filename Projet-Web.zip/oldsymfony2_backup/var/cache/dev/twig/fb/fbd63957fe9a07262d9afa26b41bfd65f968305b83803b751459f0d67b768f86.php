<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_6802be08a67c1b9381498d15cbf8ae28ab9b07a813e21c8892bfeb8be0c07296 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b5763ae46592533b1df9b922cb1fb2ea8014b1685e54e90b3eb8982c063e7da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b5763ae46592533b1df9b922cb1fb2ea8014b1685e54e90b3eb8982c063e7da->enter($__internal_1b5763ae46592533b1df9b922cb1fb2ea8014b1685e54e90b3eb8982c063e7da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_bf96fd44025738eca0b1f54061a2801d9bf9ddb41c951097c606fd1f3814f9ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf96fd44025738eca0b1f54061a2801d9bf9ddb41c951097c606fd1f3814f9ba->enter($__internal_bf96fd44025738eca0b1f54061a2801d9bf9ddb41c951097c606fd1f3814f9ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_1b5763ae46592533b1df9b922cb1fb2ea8014b1685e54e90b3eb8982c063e7da->leave($__internal_1b5763ae46592533b1df9b922cb1fb2ea8014b1685e54e90b3eb8982c063e7da_prof);

        
        $__internal_bf96fd44025738eca0b1f54061a2801d9bf9ddb41c951097c606fd1f3814f9ba->leave($__internal_bf96fd44025738eca0b1f54061a2801d9bf9ddb41c951097c606fd1f3814f9ba_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
