<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_629e5dff37dc7490581bdb8e0e30699e97f8cb22485a74f2301dd94bc8f46489 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_151d3629978296bdc66640a9ad042ecfd6b2d40a639f2969759eafbc077a20a3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_151d3629978296bdc66640a9ad042ecfd6b2d40a639f2969759eafbc077a20a3->enter($__internal_151d3629978296bdc66640a9ad042ecfd6b2d40a639f2969759eafbc077a20a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_ac119d1e10365b59d394c85f3e8ad29b819bd081dd89942f92ad91dada1875db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac119d1e10365b59d394c85f3e8ad29b819bd081dd89942f92ad91dada1875db->enter($__internal_ac119d1e10365b59d394c85f3e8ad29b819bd081dd89942f92ad91dada1875db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_151d3629978296bdc66640a9ad042ecfd6b2d40a639f2969759eafbc077a20a3->leave($__internal_151d3629978296bdc66640a9ad042ecfd6b2d40a639f2969759eafbc077a20a3_prof);

        
        $__internal_ac119d1e10365b59d394c85f3e8ad29b819bd081dd89942f92ad91dada1875db->leave($__internal_ac119d1e10365b59d394c85f3e8ad29b819bd081dd89942f92ad91dada1875db_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_row.html.php");
    }
}
