<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_767552aac3883dcf4295cd4219a1d517f5f0e78308e7e1b6366649ee287a35ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c6f15622c93b6192deca61006cc68021ee0ca790b2e76dc9a5dbf058d4083d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c6f15622c93b6192deca61006cc68021ee0ca790b2e76dc9a5dbf058d4083d3->enter($__internal_9c6f15622c93b6192deca61006cc68021ee0ca790b2e76dc9a5dbf058d4083d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $__internal_1992889a8daa0c534fde11eecf6123be744f18827c94f5add1e59de9ddc69ed3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1992889a8daa0c534fde11eecf6123be744f18827c94f5add1e59de9ddc69ed3->enter($__internal_1992889a8daa0c534fde11eecf6123be744f18827c94f5add1e59de9ddc69ed3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c6f15622c93b6192deca61006cc68021ee0ca790b2e76dc9a5dbf058d4083d3->leave($__internal_9c6f15622c93b6192deca61006cc68021ee0ca790b2e76dc9a5dbf058d4083d3_prof);

        
        $__internal_1992889a8daa0c534fde11eecf6123be744f18827c94f5add1e59de9ddc69ed3->leave($__internal_1992889a8daa0c534fde11eecf6123be744f18827c94f5add1e59de9ddc69ed3_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_e7c10a6acf086931ff14ef4b32fb3229bbeecb129e10a950421e3a4dad44cfc9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7c10a6acf086931ff14ef4b32fb3229bbeecb129e10a950421e3a4dad44cfc9->enter($__internal_e7c10a6acf086931ff14ef4b32fb3229bbeecb129e10a950421e3a4dad44cfc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_6469070896253c797abfb2f97ade59054ccfa98cb70dec93e1143d4c18339930 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6469070896253c797abfb2f97ade59054ccfa98cb70dec93e1143d4c18339930->enter($__internal_6469070896253c797abfb2f97ade59054ccfa98cb70dec93e1143d4c18339930_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_6469070896253c797abfb2f97ade59054ccfa98cb70dec93e1143d4c18339930->leave($__internal_6469070896253c797abfb2f97ade59054ccfa98cb70dec93e1143d4c18339930_prof);

        
        $__internal_e7c10a6acf086931ff14ef4b32fb3229bbeecb129e10a950421e3a4dad44cfc9->leave($__internal_e7c10a6acf086931ff14ef4b32fb3229bbeecb129e10a950421e3a4dad44cfc9_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:show.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Group/show.html.twig");
    }
}
