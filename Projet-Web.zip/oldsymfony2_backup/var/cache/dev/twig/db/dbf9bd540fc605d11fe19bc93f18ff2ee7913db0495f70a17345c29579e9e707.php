<?php

/* FOSUserBundle:Registration:confirmed.html.twig */
class __TwigTemplate_75ad1b9de0138ae115edfb36e3cbfaf7c35d7b692ac8761ef682558cb9f71af6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:confirmed.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_468acd784ce34c08660d74683817930ed52285b9af0eb33bfe67119037ea9beb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_468acd784ce34c08660d74683817930ed52285b9af0eb33bfe67119037ea9beb->enter($__internal_468acd784ce34c08660d74683817930ed52285b9af0eb33bfe67119037ea9beb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:confirmed.html.twig"));

        $__internal_49bc107de8a9b5614415420fa2a2f99886aef4a5ff8212a12cd278d94c0f65e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49bc107de8a9b5614415420fa2a2f99886aef4a5ff8212a12cd278d94c0f65e6->enter($__internal_49bc107de8a9b5614415420fa2a2f99886aef4a5ff8212a12cd278d94c0f65e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:confirmed.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_468acd784ce34c08660d74683817930ed52285b9af0eb33bfe67119037ea9beb->leave($__internal_468acd784ce34c08660d74683817930ed52285b9af0eb33bfe67119037ea9beb_prof);

        
        $__internal_49bc107de8a9b5614415420fa2a2f99886aef4a5ff8212a12cd278d94c0f65e6->leave($__internal_49bc107de8a9b5614415420fa2a2f99886aef4a5ff8212a12cd278d94c0f65e6_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_8b2f9b47beeb31b5ff2eb0a7893456866fd8a5810160be7370fa10852e525b23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b2f9b47beeb31b5ff2eb0a7893456866fd8a5810160be7370fa10852e525b23->enter($__internal_8b2f9b47beeb31b5ff2eb0a7893456866fd8a5810160be7370fa10852e525b23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_d7d2deebb30b3a9facf038c42d17db6508e94429de7b0b4fce33d54ef5cb2096 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7d2deebb30b3a9facf038c42d17db6508e94429de7b0b4fce33d54ef5cb2096->enter($__internal_d7d2deebb30b3a9facf038c42d17db6508e94429de7b0b4fce33d54ef5cb2096_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.confirmed", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
    ";
        // line 7
        if ((isset($context["targetUrl"]) ? $context["targetUrl"] : $this->getContext($context, "targetUrl"))) {
            // line 8
            echo "    <p><a href=\"";
            echo twig_escape_filter($this->env, (isset($context["targetUrl"]) ? $context["targetUrl"] : $this->getContext($context, "targetUrl")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.back", array(), "FOSUserBundle"), "html", null, true);
            echo "</a></p>
    ";
        }
        
        $__internal_d7d2deebb30b3a9facf038c42d17db6508e94429de7b0b4fce33d54ef5cb2096->leave($__internal_d7d2deebb30b3a9facf038c42d17db6508e94429de7b0b4fce33d54ef5cb2096_prof);

        
        $__internal_8b2f9b47beeb31b5ff2eb0a7893456866fd8a5810160be7370fa10852e525b23->leave($__internal_8b2f9b47beeb31b5ff2eb0a7893456866fd8a5810160be7370fa10852e525b23_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:confirmed.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 8,  54 => 7,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.confirmed'|trans({'%username%': user.username}) }}</p>
    {% if targetUrl %}
    <p><a href=\"{{ targetUrl }}\">{{ 'registration.back'|trans }}</a></p>
    {% endif %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:confirmed.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/confirmed.html.twig");
    }
}
