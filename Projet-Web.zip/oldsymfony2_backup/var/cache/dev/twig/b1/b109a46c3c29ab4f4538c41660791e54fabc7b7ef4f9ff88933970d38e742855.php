<?php

/* @Framework/Form/button_attributes.html.php */
class __TwigTemplate_2e7ab44003dc861383d91a70360ccfb22efe7a6bd675f57a1efb26ca2f962562 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1bee182eb72e1f455e24b4341d0435fb582c3b10aa646736521d435dbd77ab1a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1bee182eb72e1f455e24b4341d0435fb582c3b10aa646736521d435dbd77ab1a->enter($__internal_1bee182eb72e1f455e24b4341d0435fb582c3b10aa646736521d435dbd77ab1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        $__internal_ea30fb3354992ed55097b4c7b89a9f6a34f868ced71703e3a399039afe716a25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea30fb3354992ed55097b4c7b89a9f6a34f868ced71703e3a399039afe716a25->enter($__internal_ea30fb3354992ed55097b4c7b89a9f6a34f868ced71703e3a399039afe716a25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_1bee182eb72e1f455e24b4341d0435fb582c3b10aa646736521d435dbd77ab1a->leave($__internal_1bee182eb72e1f455e24b4341d0435fb582c3b10aa646736521d435dbd77ab1a_prof);

        
        $__internal_ea30fb3354992ed55097b4c7b89a9f6a34f868ced71703e3a399039afe716a25->leave($__internal_ea30fb3354992ed55097b4c7b89a9f6a34f868ced71703e3a399039afe716a25_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/button_attributes.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_attributes.html.php");
    }
}
