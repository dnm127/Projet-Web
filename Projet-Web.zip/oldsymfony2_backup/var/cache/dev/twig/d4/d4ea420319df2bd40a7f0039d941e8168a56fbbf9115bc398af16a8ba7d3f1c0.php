<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_1f88676d193f7cd0bb0252a415adaf322d95fd2c26e299992907078cd098ab14 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d4098541d05fcb9fbb7880605eb26a48ebafa9e4c9a1a338eab552cb1bb0b632 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4098541d05fcb9fbb7880605eb26a48ebafa9e4c9a1a338eab552cb1bb0b632->enter($__internal_d4098541d05fcb9fbb7880605eb26a48ebafa9e4c9a1a338eab552cb1bb0b632_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_7050bd5081c62724e616f16ab99a95d8e92e1d33218fac5a64c5dc7b0359d971 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7050bd5081c62724e616f16ab99a95d8e92e1d33218fac5a64c5dc7b0359d971->enter($__internal_7050bd5081c62724e616f16ab99a95d8e92e1d33218fac5a64c5dc7b0359d971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_d4098541d05fcb9fbb7880605eb26a48ebafa9e4c9a1a338eab552cb1bb0b632->leave($__internal_d4098541d05fcb9fbb7880605eb26a48ebafa9e4c9a1a338eab552cb1bb0b632_prof);

        
        $__internal_7050bd5081c62724e616f16ab99a95d8e92e1d33218fac5a64c5dc7b0359d971->leave($__internal_7050bd5081c62724e616f16ab99a95d8e92e1d33218fac5a64c5dc7b0359d971_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/submit_widget.html.php");
    }
}
