<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_79889f502230514a80af45a8baf509962953ed37256f44dd468c051751e6a737 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c251698ef8eb4f1802acc880b956399d6c670981edecb33a36b54c0e422a88d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c251698ef8eb4f1802acc880b956399d6c670981edecb33a36b54c0e422a88d7->enter($__internal_c251698ef8eb4f1802acc880b956399d6c670981edecb33a36b54c0e422a88d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $__internal_7b41719d4260297ee39bffc52d50c3c84008f7741cafc917e99d92d4889e8926 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b41719d4260297ee39bffc52d50c3c84008f7741cafc917e99d92d4889e8926->enter($__internal_7b41719d4260297ee39bffc52d50c3c84008f7741cafc917e99d92d4889e8926_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c251698ef8eb4f1802acc880b956399d6c670981edecb33a36b54c0e422a88d7->leave($__internal_c251698ef8eb4f1802acc880b956399d6c670981edecb33a36b54c0e422a88d7_prof);

        
        $__internal_7b41719d4260297ee39bffc52d50c3c84008f7741cafc917e99d92d4889e8926->leave($__internal_7b41719d4260297ee39bffc52d50c3c84008f7741cafc917e99d92d4889e8926_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_5d151dcd717b08a8b9e3d8c0f1c0610d816260843cb183bbb0d753ea7bd80b57 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d151dcd717b08a8b9e3d8c0f1c0610d816260843cb183bbb0d753ea7bd80b57->enter($__internal_5d151dcd717b08a8b9e3d8c0f1c0610d816260843cb183bbb0d753ea7bd80b57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_9a035a638720df0891e67cf607d892eb32c388332e0827af0c6611a4b0fbf53a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a035a638720df0891e67cf607d892eb32c388332e0827af0c6611a4b0fbf53a->enter($__internal_9a035a638720df0891e67cf607d892eb32c388332e0827af0c6611a4b0fbf53a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_9a035a638720df0891e67cf607d892eb32c388332e0827af0c6611a4b0fbf53a->leave($__internal_9a035a638720df0891e67cf607d892eb32c388332e0827af0c6611a4b0fbf53a_prof);

        
        $__internal_5d151dcd717b08a8b9e3d8c0f1c0610d816260843cb183bbb0d753ea7bd80b57->leave($__internal_5d151dcd717b08a8b9e3d8c0f1c0610d816260843cb183bbb0d753ea7bd80b57_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/list_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:list.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Group/list.html.twig");
    }
}
