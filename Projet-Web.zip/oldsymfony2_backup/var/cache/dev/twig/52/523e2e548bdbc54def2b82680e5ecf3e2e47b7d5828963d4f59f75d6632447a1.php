<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_0d3b9fee3d87f37dae62cfa7d7d184cefa079d37d0aedd4a8f5c45c5e67c3019 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b026390464bb22c1f686328734a481ca97db12fd1840ff770ed1489427a482c6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b026390464bb22c1f686328734a481ca97db12fd1840ff770ed1489427a482c6->enter($__internal_b026390464bb22c1f686328734a481ca97db12fd1840ff770ed1489427a482c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        $__internal_2308dc5994bf618f596f2a9b0cac0c0c737f6fc19aedbc7327c66c7754c610a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2308dc5994bf618f596f2a9b0cac0c0c737f6fc19aedbc7327c66c7754c610a6->enter($__internal_2308dc5994bf618f596f2a9b0cac0c0c737f6fc19aedbc7327c66c7754c610a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_b026390464bb22c1f686328734a481ca97db12fd1840ff770ed1489427a482c6->leave($__internal_b026390464bb22c1f686328734a481ca97db12fd1840ff770ed1489427a482c6_prof);

        
        $__internal_2308dc5994bf618f596f2a9b0cac0c0c737f6fc19aedbc7327c66c7754c610a6->leave($__internal_2308dc5994bf618f596f2a9b0cac0c0c737f6fc19aedbc7327c66c7754c610a6_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_c69e8f752a02a3e85ec6b7813ef9a0ed112a5f472eaea10abe77595e573679eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c69e8f752a02a3e85ec6b7813ef9a0ed112a5f472eaea10abe77595e573679eb->enter($__internal_c69e8f752a02a3e85ec6b7813ef9a0ed112a5f472eaea10abe77595e573679eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_1621bb4ffc81461145164b531494732100093d44800eee1ab7494bee6a2b6910 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1621bb4ffc81461145164b531494732100093d44800eee1ab7494bee6a2b6910->enter($__internal_1621bb4ffc81461145164b531494732100093d44800eee1ab7494bee6a2b6910_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        
        $__internal_1621bb4ffc81461145164b531494732100093d44800eee1ab7494bee6a2b6910->leave($__internal_1621bb4ffc81461145164b531494732100093d44800eee1ab7494bee6a2b6910_prof);

        
        $__internal_c69e8f752a02a3e85ec6b7813ef9a0ed112a5f472eaea10abe77595e573679eb->leave($__internal_c69e8f752a02a3e85ec6b7813ef9a0ed112a5f472eaea10abe77595e573679eb_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_13e1829eaab40dcd86a08253697edb0897411dd94fe5f7d3433224d3d190b80b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13e1829eaab40dcd86a08253697edb0897411dd94fe5f7d3433224d3d190b80b->enter($__internal_13e1829eaab40dcd86a08253697edb0897411dd94fe5f7d3433224d3d190b80b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_02defc8f755c7b82f4faa663471f5a47fe6fce82007151b9403913b13058cd48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02defc8f755c7b82f4faa663471f5a47fe6fce82007151b9403913b13058cd48->enter($__internal_02defc8f755c7b82f4faa663471f5a47fe6fce82007151b9403913b13058cd48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_02defc8f755c7b82f4faa663471f5a47fe6fce82007151b9403913b13058cd48->leave($__internal_02defc8f755c7b82f4faa663471f5a47fe6fce82007151b9403913b13058cd48_prof);

        
        $__internal_13e1829eaab40dcd86a08253697edb0897411dd94fe5f7d3433224d3d190b80b->leave($__internal_13e1829eaab40dcd86a08253697edb0897411dd94fe5f7d3433224d3d190b80b_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_817e6286eb1c6f3ede8c82d8dc89003cbd2be090f918af4e0bd3bd380f677d00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_817e6286eb1c6f3ede8c82d8dc89003cbd2be090f918af4e0bd3bd380f677d00->enter($__internal_817e6286eb1c6f3ede8c82d8dc89003cbd2be090f918af4e0bd3bd380f677d00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_bf985693c1922f88e26a3e3e2745de93ca4af2a2a11a5be236e1e4cd230886dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf985693c1922f88e26a3e3e2745de93ca4af2a2a11a5be236e1e4cd230886dd->enter($__internal_bf985693c1922f88e26a3e3e2745de93ca4af2a2a11a5be236e1e4cd230886dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_bf985693c1922f88e26a3e3e2745de93ca4af2a2a11a5be236e1e4cd230886dd->leave($__internal_bf985693c1922f88e26a3e3e2745de93ca4af2a2a11a5be236e1e4cd230886dd_prof);

        
        $__internal_817e6286eb1c6f3ede8c82d8dc89003cbd2be090f918af4e0bd3bd380f677d00->leave($__internal_817e6286eb1c6f3ede8c82d8dc89003cbd2be090f918af4e0bd3bd380f677d00_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 13,  73 => 10,  64 => 8,  54 => 4,  45 => 2,  35 => 13,  33 => 8,  30 => 7,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Registration:email.txt.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/email.txt.twig");
    }
}
