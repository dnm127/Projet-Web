<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_06ce00634d62188ba19342b0962f29e25d9736e8d0f0aaa19009149a4e5b181a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_357d319526c7293efc993165ea888b0880c5be53d1f37b5f60866dbcd937caa5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_357d319526c7293efc993165ea888b0880c5be53d1f37b5f60866dbcd937caa5->enter($__internal_357d319526c7293efc993165ea888b0880c5be53d1f37b5f60866dbcd937caa5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        $__internal_0295ad78150366b154d5b042b79efc68887aeadec60e252eb3a0d2f16f27d959 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0295ad78150366b154d5b042b79efc68887aeadec60e252eb3a0d2f16f27d959->enter($__internal_0295ad78150366b154d5b042b79efc68887aeadec60e252eb3a0d2f16f27d959_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_357d319526c7293efc993165ea888b0880c5be53d1f37b5f60866dbcd937caa5->leave($__internal_357d319526c7293efc993165ea888b0880c5be53d1f37b5f60866dbcd937caa5_prof);

        
        $__internal_0295ad78150366b154d5b042b79efc68887aeadec60e252eb3a0d2f16f27d959->leave($__internal_0295ad78150366b154d5b042b79efc68887aeadec60e252eb3a0d2f16f27d959_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
", "@Framework/Form/datetime_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/datetime_widget.html.php");
    }
}
