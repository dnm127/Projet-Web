<?php

/* ::base.html.twig */
class __TwigTemplate_022e5fbe7553c6a016dcf07c24e69cb5d15b6be45fa6378c7d9809f11e8f699d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4aa7dfb1e39aa88ae323fca52186a38bdaa60aaaeac0cf6aa308b34219e1a7e2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4aa7dfb1e39aa88ae323fca52186a38bdaa60aaaeac0cf6aa308b34219e1a7e2->enter($__internal_4aa7dfb1e39aa88ae323fca52186a38bdaa60aaaeac0cf6aa308b34219e1a7e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_0d463ba0af3f630ecabf8069a5120ecbded27292c9527e5a80bbdab4ae403bab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d463ba0af3f630ecabf8069a5120ecbded27292c9527e5a80bbdab4ae403bab->enter($__internal_0d463ba0af3f630ecabf8069a5120ecbded27292c9527e5a80bbdab4ae403bab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_4aa7dfb1e39aa88ae323fca52186a38bdaa60aaaeac0cf6aa308b34219e1a7e2->leave($__internal_4aa7dfb1e39aa88ae323fca52186a38bdaa60aaaeac0cf6aa308b34219e1a7e2_prof);

        
        $__internal_0d463ba0af3f630ecabf8069a5120ecbded27292c9527e5a80bbdab4ae403bab->leave($__internal_0d463ba0af3f630ecabf8069a5120ecbded27292c9527e5a80bbdab4ae403bab_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_2081b68f989694036f8c32871fe51a6572b5d6b52e617925702f53fe1fef6f34 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2081b68f989694036f8c32871fe51a6572b5d6b52e617925702f53fe1fef6f34->enter($__internal_2081b68f989694036f8c32871fe51a6572b5d6b52e617925702f53fe1fef6f34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ef639ce1952237c8814a33343e1eba156c92e8bedef446ba5d87bbc74efed14d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef639ce1952237c8814a33343e1eba156c92e8bedef446ba5d87bbc74efed14d->enter($__internal_ef639ce1952237c8814a33343e1eba156c92e8bedef446ba5d87bbc74efed14d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_ef639ce1952237c8814a33343e1eba156c92e8bedef446ba5d87bbc74efed14d->leave($__internal_ef639ce1952237c8814a33343e1eba156c92e8bedef446ba5d87bbc74efed14d_prof);

        
        $__internal_2081b68f989694036f8c32871fe51a6572b5d6b52e617925702f53fe1fef6f34->leave($__internal_2081b68f989694036f8c32871fe51a6572b5d6b52e617925702f53fe1fef6f34_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_14960a41b085e56afcaf60c7dd549e7a42a55902a526de075cd1707fc40c8d12 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14960a41b085e56afcaf60c7dd549e7a42a55902a526de075cd1707fc40c8d12->enter($__internal_14960a41b085e56afcaf60c7dd549e7a42a55902a526de075cd1707fc40c8d12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_f416d22404c0f08ab773208c9aa98e3f50d3dd78368eb92da5be9feac9f28f47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f416d22404c0f08ab773208c9aa98e3f50d3dd78368eb92da5be9feac9f28f47->enter($__internal_f416d22404c0f08ab773208c9aa98e3f50d3dd78368eb92da5be9feac9f28f47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_f416d22404c0f08ab773208c9aa98e3f50d3dd78368eb92da5be9feac9f28f47->leave($__internal_f416d22404c0f08ab773208c9aa98e3f50d3dd78368eb92da5be9feac9f28f47_prof);

        
        $__internal_14960a41b085e56afcaf60c7dd549e7a42a55902a526de075cd1707fc40c8d12->leave($__internal_14960a41b085e56afcaf60c7dd549e7a42a55902a526de075cd1707fc40c8d12_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_784589d933828ecec61055fadf690df8d10f45c2eedc892f22804064585ee175 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_784589d933828ecec61055fadf690df8d10f45c2eedc892f22804064585ee175->enter($__internal_784589d933828ecec61055fadf690df8d10f45c2eedc892f22804064585ee175_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1937b35ddae2daaeadf144c0f8edafa3f350b441c3e533a59b349166489772da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1937b35ddae2daaeadf144c0f8edafa3f350b441c3e533a59b349166489772da->enter($__internal_1937b35ddae2daaeadf144c0f8edafa3f350b441c3e533a59b349166489772da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_1937b35ddae2daaeadf144c0f8edafa3f350b441c3e533a59b349166489772da->leave($__internal_1937b35ddae2daaeadf144c0f8edafa3f350b441c3e533a59b349166489772da_prof);

        
        $__internal_784589d933828ecec61055fadf690df8d10f45c2eedc892f22804064585ee175->leave($__internal_784589d933828ecec61055fadf690df8d10f45c2eedc892f22804064585ee175_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_be96b45ebe0f35a036b04141e68bfa3a9974d26dc380db2076a6b5b0b42c0ae9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be96b45ebe0f35a036b04141e68bfa3a9974d26dc380db2076a6b5b0b42c0ae9->enter($__internal_be96b45ebe0f35a036b04141e68bfa3a9974d26dc380db2076a6b5b0b42c0ae9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_93f48f26ec177875cfd674c660af0a36ffcd14a8326094b7757c313cc93b2fbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93f48f26ec177875cfd674c660af0a36ffcd14a8326094b7757c313cc93b2fbf->enter($__internal_93f48f26ec177875cfd674c660af0a36ffcd14a8326094b7757c313cc93b2fbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_93f48f26ec177875cfd674c660af0a36ffcd14a8326094b7757c313cc93b2fbf->leave($__internal_93f48f26ec177875cfd674c660af0a36ffcd14a8326094b7757c313cc93b2fbf_prof);

        
        $__internal_be96b45ebe0f35a036b04141e68bfa3a9974d26dc380db2076a6b5b0b42c0ae9->leave($__internal_be96b45ebe0f35a036b04141e68bfa3a9974d26dc380db2076a6b5b0b42c0ae9_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/app/Resources/views/base.html.twig");
    }
}
