<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_943a4328cdd144004632f2c9e4935dfa903361c2014566a699f381fc36887d64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51e9a8e2a3fa8dffd120358994026ca46172412c8f20013633ecb3a765a08461 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51e9a8e2a3fa8dffd120358994026ca46172412c8f20013633ecb3a765a08461->enter($__internal_51e9a8e2a3fa8dffd120358994026ca46172412c8f20013633ecb3a765a08461_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_2eac753a222acbbe32339213c7433ca3d6a0bebd9d04e9ffa9f73546dac4ce2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2eac753a222acbbe32339213c7433ca3d6a0bebd9d04e9ffa9f73546dac4ce2b->enter($__internal_2eac753a222acbbe32339213c7433ca3d6a0bebd9d04e9ffa9f73546dac4ce2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_51e9a8e2a3fa8dffd120358994026ca46172412c8f20013633ecb3a765a08461->leave($__internal_51e9a8e2a3fa8dffd120358994026ca46172412c8f20013633ecb3a765a08461_prof);

        
        $__internal_2eac753a222acbbe32339213c7433ca3d6a0bebd9d04e9ffa9f73546dac4ce2b->leave($__internal_2eac753a222acbbe32339213c7433ca3d6a0bebd9d04e9ffa9f73546dac4ce2b_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_2c1a142633cd5377ebf8ba8301c2f3e6d0e6167a4e7c3c09812738ab9ac67c93 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c1a142633cd5377ebf8ba8301c2f3e6d0e6167a4e7c3c09812738ab9ac67c93->enter($__internal_2c1a142633cd5377ebf8ba8301c2f3e6d0e6167a4e7c3c09812738ab9ac67c93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_8fe71a5b1851e8169aa8721bfe013d010943f496315c9ea5c8e4c25b05034fc6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fe71a5b1851e8169aa8721bfe013d010943f496315c9ea5c8e4c25b05034fc6->enter($__internal_8fe71a5b1851e8169aa8721bfe013d010943f496315c9ea5c8e4c25b05034fc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_8fe71a5b1851e8169aa8721bfe013d010943f496315c9ea5c8e4c25b05034fc6->leave($__internal_8fe71a5b1851e8169aa8721bfe013d010943f496315c9ea5c8e4c25b05034fc6_prof);

        
        $__internal_2c1a142633cd5377ebf8ba8301c2f3e6d0e6167a4e7c3c09812738ab9ac67c93->leave($__internal_2c1a142633cd5377ebf8ba8301c2f3e6d0e6167a4e7c3c09812738ab9ac67c93_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
