<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_81561cd895801615cefaa548cf3a21cdc1e7b993a07e69816fd119705675aa93 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_424d054e972a80a0d9e9c7bb49b52a59d08b74491cc6ac1bef516c6f95a19a72 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_424d054e972a80a0d9e9c7bb49b52a59d08b74491cc6ac1bef516c6f95a19a72->enter($__internal_424d054e972a80a0d9e9c7bb49b52a59d08b74491cc6ac1bef516c6f95a19a72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_73d9003047dfe8605ce1277d98bb79230f57b2fc2c44a9b66422523cffe0d5e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73d9003047dfe8605ce1277d98bb79230f57b2fc2c44a9b66422523cffe0d5e5->enter($__internal_73d9003047dfe8605ce1277d98bb79230f57b2fc2c44a9b66422523cffe0d5e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_424d054e972a80a0d9e9c7bb49b52a59d08b74491cc6ac1bef516c6f95a19a72->leave($__internal_424d054e972a80a0d9e9c7bb49b52a59d08b74491cc6ac1bef516c6f95a19a72_prof);

        
        $__internal_73d9003047dfe8605ce1277d98bb79230f57b2fc2c44a9b66422523cffe0d5e5->leave($__internal_73d9003047dfe8605ce1277d98bb79230f57b2fc2c44a9b66422523cffe0d5e5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/number_widget.html.php");
    }
}
