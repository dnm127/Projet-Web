<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_b1e652da32a121dbb8420f08580f829f0afd94d02972d3743319a50b5d03d8d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f655fcbfb13b69a31c90f3eaec015ff35c0cc90c1984a6d494919d490bdca2fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f655fcbfb13b69a31c90f3eaec015ff35c0cc90c1984a6d494919d490bdca2fc->enter($__internal_f655fcbfb13b69a31c90f3eaec015ff35c0cc90c1984a6d494919d490bdca2fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_efc86dc50fc3b8289b80027fb8d6e9b409ff791a33d23d51ca290b4c28cd5116 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efc86dc50fc3b8289b80027fb8d6e9b409ff791a33d23d51ca290b4c28cd5116->enter($__internal_efc86dc50fc3b8289b80027fb8d6e9b409ff791a33d23d51ca290b4c28cd5116_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_f655fcbfb13b69a31c90f3eaec015ff35c0cc90c1984a6d494919d490bdca2fc->leave($__internal_f655fcbfb13b69a31c90f3eaec015ff35c0cc90c1984a6d494919d490bdca2fc_prof);

        
        $__internal_efc86dc50fc3b8289b80027fb8d6e9b409ff791a33d23d51ca290b4c28cd5116->leave($__internal_efc86dc50fc3b8289b80027fb8d6e9b409ff791a33d23d51ca290b4c28cd5116_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_row.html.php");
    }
}
