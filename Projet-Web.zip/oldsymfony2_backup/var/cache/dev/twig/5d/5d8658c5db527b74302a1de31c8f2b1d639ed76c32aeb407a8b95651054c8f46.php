<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_16d4e425067b83270263d2ae5505873e1b1f6d56b651c1a55a64baf940e3fe1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e5f74fc491d83082d635767526370630941b8af8fae7fe6665ec5ce36aedfe0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e5f74fc491d83082d635767526370630941b8af8fae7fe6665ec5ce36aedfe0->enter($__internal_4e5f74fc491d83082d635767526370630941b8af8fae7fe6665ec5ce36aedfe0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_0812616a0d8f044bd159169589791db58906ad8e473cbc48fd0486c980a0ce0f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0812616a0d8f044bd159169589791db58906ad8e473cbc48fd0486c980a0ce0f->enter($__internal_0812616a0d8f044bd159169589791db58906ad8e473cbc48fd0486c980a0ce0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_4e5f74fc491d83082d635767526370630941b8af8fae7fe6665ec5ce36aedfe0->leave($__internal_4e5f74fc491d83082d635767526370630941b8af8fae7fe6665ec5ce36aedfe0_prof);

        
        $__internal_0812616a0d8f044bd159169589791db58906ad8e473cbc48fd0486c980a0ce0f->leave($__internal_0812616a0d8f044bd159169589791db58906ad8e473cbc48fd0486c980a0ce0f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_errors.html.php");
    }
}
