<?php

/* FOSUserBundle:ChangePassword:change_password.html.twig */
class __TwigTemplate_b0cd0f7b2b7e05d1d71da0366149b163412f6fac0b9339fccd3fd1c0566533cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_180c5e235858eb31da56af302d0912b3e9ff47876e37565c2fd59ae29d1ca999 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_180c5e235858eb31da56af302d0912b3e9ff47876e37565c2fd59ae29d1ca999->enter($__internal_180c5e235858eb31da56af302d0912b3e9ff47876e37565c2fd59ae29d1ca999_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password.html.twig"));

        $__internal_c614e3daadc8cffdda937a58c67e64b4f834d87f2216d848693e29b84ff75986 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c614e3daadc8cffdda937a58c67e64b4f834d87f2216d848693e29b84ff75986->enter($__internal_c614e3daadc8cffdda937a58c67e64b4f834d87f2216d848693e29b84ff75986_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_180c5e235858eb31da56af302d0912b3e9ff47876e37565c2fd59ae29d1ca999->leave($__internal_180c5e235858eb31da56af302d0912b3e9ff47876e37565c2fd59ae29d1ca999_prof);

        
        $__internal_c614e3daadc8cffdda937a58c67e64b4f834d87f2216d848693e29b84ff75986->leave($__internal_c614e3daadc8cffdda937a58c67e64b4f834d87f2216d848693e29b84ff75986_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_364c1906c916609a99ea98841f55826fa7f0dc4209072041599bd4035d6b0bc4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_364c1906c916609a99ea98841f55826fa7f0dc4209072041599bd4035d6b0bc4->enter($__internal_364c1906c916609a99ea98841f55826fa7f0dc4209072041599bd4035d6b0bc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_c4f3e454d6eccb0705ea47920124bad4fde6c4e51ff13d1fa42de23a73a22617 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4f3e454d6eccb0705ea47920124bad4fde6c4e51ff13d1fa42de23a73a22617->enter($__internal_c4f3e454d6eccb0705ea47920124bad4fde6c4e51ff13d1fa42de23a73a22617_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/ChangePassword/change_password_content.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 4)->display($context);
        
        $__internal_c4f3e454d6eccb0705ea47920124bad4fde6c4e51ff13d1fa42de23a73a22617->leave($__internal_c4f3e454d6eccb0705ea47920124bad4fde6c4e51ff13d1fa42de23a73a22617_prof);

        
        $__internal_364c1906c916609a99ea98841f55826fa7f0dc4209072041599bd4035d6b0bc4->leave($__internal_364c1906c916609a99ea98841f55826fa7f0dc4209072041599bd4035d6b0bc4_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:change_password.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/ChangePassword/change_password_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:ChangePassword:change_password.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/ChangePassword/change_password.html.twig");
    }
}
