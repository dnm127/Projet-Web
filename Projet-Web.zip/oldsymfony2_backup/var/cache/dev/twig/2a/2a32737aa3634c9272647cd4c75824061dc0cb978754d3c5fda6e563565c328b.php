<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_6afd84b4b390eaf3e016b941e569747cf037ddb9234a465d12c8cec73ba5546f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69754993571f70bee5ade1327975115645f5004b8d5fc44dbedda1d698fec9b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_69754993571f70bee5ade1327975115645f5004b8d5fc44dbedda1d698fec9b2->enter($__internal_69754993571f70bee5ade1327975115645f5004b8d5fc44dbedda1d698fec9b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_572bd1dae022bc98e4aa8ba78636fbc59b77775ea4d94f6ab0dee4320e5064c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_572bd1dae022bc98e4aa8ba78636fbc59b77775ea4d94f6ab0dee4320e5064c2->enter($__internal_572bd1dae022bc98e4aa8ba78636fbc59b77775ea4d94f6ab0dee4320e5064c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_69754993571f70bee5ade1327975115645f5004b8d5fc44dbedda1d698fec9b2->leave($__internal_69754993571f70bee5ade1327975115645f5004b8d5fc44dbedda1d698fec9b2_prof);

        
        $__internal_572bd1dae022bc98e4aa8ba78636fbc59b77775ea4d94f6ab0dee4320e5064c2->leave($__internal_572bd1dae022bc98e4aa8ba78636fbc59b77775ea4d94f6ab0dee4320e5064c2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
