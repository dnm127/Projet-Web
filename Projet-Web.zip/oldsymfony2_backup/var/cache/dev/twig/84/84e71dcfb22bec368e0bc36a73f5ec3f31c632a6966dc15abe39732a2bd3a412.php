<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_fd7f4d71f8ac3e4401fa9822dc17d36493a2828d39e6ba9af33aee32f6bd53c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12a031b6353960248fff9c991c8304f1d0e8fb8656d5e79a7a778fc984cd8b93 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12a031b6353960248fff9c991c8304f1d0e8fb8656d5e79a7a778fc984cd8b93->enter($__internal_12a031b6353960248fff9c991c8304f1d0e8fb8656d5e79a7a778fc984cd8b93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_df328915ae76b91dc469bfe706b5bf54dda7734e0afb35787f231f259578b277 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df328915ae76b91dc469bfe706b5bf54dda7734e0afb35787f231f259578b277->enter($__internal_df328915ae76b91dc469bfe706b5bf54dda7734e0afb35787f231f259578b277_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_12a031b6353960248fff9c991c8304f1d0e8fb8656d5e79a7a778fc984cd8b93->leave($__internal_12a031b6353960248fff9c991c8304f1d0e8fb8656d5e79a7a778fc984cd8b93_prof);

        
        $__internal_df328915ae76b91dc469bfe706b5bf54dda7734e0afb35787f231f259578b277->leave($__internal_df328915ae76b91dc469bfe706b5bf54dda7734e0afb35787f231f259578b277_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget.html.php");
    }
}
