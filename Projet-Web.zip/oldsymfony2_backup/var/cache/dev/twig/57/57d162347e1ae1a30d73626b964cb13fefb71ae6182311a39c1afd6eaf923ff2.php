<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_1babac52968fb43dd8594519c98a8759092d1726d1bc32e920a1cd63a34dcea8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9321547245708f2ea00e012d7ed24e040e0545835181ceb2eb4bf65554174331 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9321547245708f2ea00e012d7ed24e040e0545835181ceb2eb4bf65554174331->enter($__internal_9321547245708f2ea00e012d7ed24e040e0545835181ceb2eb4bf65554174331_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_5a10fa14ba5dc6eff9e1c19f016378daaa5a17807cf2628c32a6bfa3cae82fbb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a10fa14ba5dc6eff9e1c19f016378daaa5a17807cf2628c32a6bfa3cae82fbb->enter($__internal_5a10fa14ba5dc6eff9e1c19f016378daaa5a17807cf2628c32a6bfa3cae82fbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_9321547245708f2ea00e012d7ed24e040e0545835181ceb2eb4bf65554174331->leave($__internal_9321547245708f2ea00e012d7ed24e040e0545835181ceb2eb4bf65554174331_prof);

        
        $__internal_5a10fa14ba5dc6eff9e1c19f016378daaa5a17807cf2628c32a6bfa3cae82fbb->leave($__internal_5a10fa14ba5dc6eff9e1c19f016378daaa5a17807cf2628c32a6bfa3cae82fbb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
