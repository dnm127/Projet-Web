<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_4cf3aa60ff183caff474818c73a8b24c9260d5adcebaddd18fa8174a2ccebb88 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a5d0eeff7da6775b43395c5926d8bb73ee8915ff43bafad58abe7737718014c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5d0eeff7da6775b43395c5926d8bb73ee8915ff43bafad58abe7737718014c1->enter($__internal_a5d0eeff7da6775b43395c5926d8bb73ee8915ff43bafad58abe7737718014c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_4c3d119d44885c8788c7baa670fafe564bf28016182dc11da790d3df87d1cebe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c3d119d44885c8788c7baa670fafe564bf28016182dc11da790d3df87d1cebe->enter($__internal_4c3d119d44885c8788c7baa670fafe564bf28016182dc11da790d3df87d1cebe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_a5d0eeff7da6775b43395c5926d8bb73ee8915ff43bafad58abe7737718014c1->leave($__internal_a5d0eeff7da6775b43395c5926d8bb73ee8915ff43bafad58abe7737718014c1_prof);

        
        $__internal_4c3d119d44885c8788c7baa670fafe564bf28016182dc11da790d3df87d1cebe->leave($__internal_4c3d119d44885c8788c7baa670fafe564bf28016182dc11da790d3df87d1cebe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/search_widget.html.php");
    }
}
