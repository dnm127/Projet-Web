<?php

/* ProjetMainBundle:Main:layout.html.twig */
class __TwigTemplate_64b5c6e173fc1e760ae6a62ff326bbb880644643094dbc572d13512dcdf0ff67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'banner' => array($this, 'block_banner'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d1e0c8e56c92e768278634c0e4b72928e162143e2c01a5669357ea135e10270 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d1e0c8e56c92e768278634c0e4b72928e162143e2c01a5669357ea135e10270->enter($__internal_6d1e0c8e56c92e768278634c0e4b72928e162143e2c01a5669357ea135e10270_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:layout.html.twig"));

        $__internal_2c8f49283f7c0c13cbd714c801b5e34703ffb93493ac46050ccd28b49aac97a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c8f49283f7c0c13cbd714c801b5e34703ffb93493ac46050ccd28b49aac97a8->enter($__internal_2c8f49283f7c0c13cbd714c801b5e34703ffb93493ac46050ccd28b49aac97a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:layout.html.twig"));

        // line 2
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <!--CSS Layout-->
    ";
        // line 9
        echo "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    ";
        // line 12
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-3.2.1.min.js"), "html", null, true);
        echo "\"></script>

    ";
        // line 15
        echo "    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
    <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>

    ";
        // line 20
        echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/foodstyle.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/playvideo.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/user.css"), "html", null, true);
        echo "\">

    ";
        // line 25
        echo "    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">

    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/cuisine.ico"), "html", null, true);
        echo "\" />
    <!-------------->
</head>

<body onload=\"setInterval(myCounter, 1000)\">
    <!-- Top -->
    <div class=\"container-fluid\">
        <div class=\"row\">
            <!-- Nav bar -->
            <header style=\"height: 500px\" class=\"backgroundimg\">
                <nav style=\"background-color: transparent; border: none\" class=\"navbar navbar-default\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button id=\"togglebutton\" type=\"button\" data-target=\"#navbarCollapse\" data-toggle=\"collapse\" class=\"navbar-toggle\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span style=\"font-size: 27px;\">☰</span>
                        </button>
                        <a  href=\"";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_homepage");
        echo "\" class=\"navbar-brand\"><img id=\"logo\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/cutlery.png"), "html", null, true);
        echo "\"></a>
                    </div>
                    <!-- Collection of nav links, forms, and other content for toggling -->
                    <div id=\"navbarCollapse\" class=\"collapse navbar-collapse\">
                        <ul id=\"rightofmenu\" class=\"nav navbar-nav navbar-right\">
                            <!-- <li class=\"togglelist\" ><a href=\"#\" style=\"color: white\"><button class=\"buttonright\" onclick=\"scroll_to()\">About us</button></a></li> -->
                            ";
        // line 52
        if ((null === $this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 53
            echo "                                <li class=\"togglelist\" ><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_user_login");
            echo "\" style=\"color: white\"><button class=\"buttonright\" type=\"button\" id=\"loginbutton\" >Connexion</button></a></li>
                            ";
        } elseif ( !(null === $this->getAttribute(        // line 54
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 55
            echo "                                <li class=\"togglelist\" ><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
            echo "\" style=\"color: white\"><button class=\"buttonright\" type=\"button\" id=\"loginbutton\" >Déconnexion</button></a></li>
                            ";
        }
        // line 57
        echo "                        </ul>
                        <ul id=\"rightofmenu\" class=\"nav navbar-nav navbar-right\">
                            ";
        // line 59
        if ((null === $this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 60
            echo "                                <li class=\"togglelist\" ><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_user_signup");
            echo "\" style=\"color: white\"><button class=\"buttonright\" type=\"button\" id=\"loginbutton\">Inscription</button></a></li>
                            ";
        } elseif ( !(null === $this->getAttribute(        // line 61
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 62
            echo "                                <li class=\"togglelist\" ><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_user_profile", array("username" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()))), "html", null, true);
            echo "\" style=\"color: white\"><button class=\"buttonrightmod\" type=\"button\" id=\"loginbutton\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo "</button></a></li>
                            ";
        }
        // line 64
        echo "                        </ul>
                    </div>
                </nav>
                <!---End Nav-->

                <p id=\"banner\" class=\"col-sm-12\">";
        // line 69
        $this->displayBlock('banner', $context, $blocks);
        echo "</p>

                ";
        // line 72
        echo "                <div style=\"text-align: center;\">
                    <a href=\"";
        // line 73
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_recipe");
        echo "\"><button id=\"explore\">Découvrir</button></a>
                ";
        // line 75
        echo "                    ";
        if ( !(null === $this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 76
            echo "                        <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_addvideo");
            echo "\"><button id=\"upload\">Déposer</button></a>
                    ";
        } elseif ((null === $this->getAttribute(        // line 77
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 78
            echo "                        <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_user_login");
            echo "\"><button id=\"upload\">Déposer</button></a>
                    ";
        }
        // line 80
        echo "                </div>

            </header>

        </div>
    </div>
    <!--End Top-->
    <div >

    ";
        // line 89
        $this->displayBlock('content', $context, $blocks);
        // line 102
        echo "    </div>
    <!--Content-->

    <!--End Content-->

    <!-- About us modal -->
        <div class=\"modal fade\" id=\"aboutModal\" role=\"dialog\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" style=\" color: white\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h2 style=\"text-align: center; font-family: 'Pacifico'; text-shadow: 2px 0 0 #fff, -2px 0 0 #fff, 0 2px 0 #fff, 0 -2px 0 #fff, 1px 1px #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff;\" class=\"modal-title\">Goûter</h2>
                    </div>
                    <div class=\"modal-body\">
                        <p style=\"text-align: center; font-size: 14px; font-family: Futura; font-size: 17px\">Ce site sert à vous donner les recettes de cuisines détaillées et <br>
                            aussi vous permet de partager vos vidéos avec les autres personnes</p><br>
                    </div>
                </div>
            </div>
        </div>
    <!-- End modal -->
    <!-- Contact modal -->
        <div class=\"modal fade\" id=\"contactModal\" role=\"dialog\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" style=\" color: white\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h2 style=\"text-align: center; font-family: 'Pacifico'; text-shadow: 2px 0 0 #fff, -2px 0 0 #fff, 0 2px 0 #fff, 0 -2px 0 #fff, 1px 1px #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff;\" class=\"modal-title\">Goûter</h2>
                    </div>
                    <div class=\"modal-body\">
                        <p style=\"text-align: center; font-size: 18px\"><br>
                            <span style=\"letter-spacing: 2px; margin-top: 5px; margin-bottom: 15px;\" class=\"glyphicon glyphicon-phone-alt\"></span> &nbsp; <a style=\"font-family: Futura; font-size: 18px; letter-spacing: 1px\" href=\"tel:+33123456789\">+33 1 23 45 67 89</a><br>
                            <span style=\"letter-spacing: 2px;\" class=\"glyphicon glyphicon-envelope\"></span> &nbsp; <a style=\"font-family: Futura; letter-spacing: 1px; font-size: 18px\" href=\"mailto:Gouter@gmail.com\">Gouter@gouter.com</a>
                        </p><br>
                    </div>
                </div>
            </div>
        </div>
    <!-- End modal -->
    <!--Footer-->
    <footer class=\"col-sm-12 text-center\">
        <a id=\"about\" data-toggle=\"modal\" data-target=\"#aboutModal\" href=\"#\">About us</a>
        <a id=\"contact\" data-toggle=\"modal\" data-target=\"#contactModal\" href=\"#\">Contact</a>
    </footer>
    <!--End Footer-->

    <!-- Javascript -->
    <script src=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/foodfunction.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/playvideo.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/user.js"), "html", null, true);
        echo "\"></script>
    <!---------------->
</body>

</html>";
        
        $__internal_6d1e0c8e56c92e768278634c0e4b72928e162143e2c01a5669357ea135e10270->leave($__internal_6d1e0c8e56c92e768278634c0e4b72928e162143e2c01a5669357ea135e10270_prof);

        
        $__internal_2c8f49283f7c0c13cbd714c801b5e34703ffb93493ac46050ccd28b49aac97a8->leave($__internal_2c8f49283f7c0c13cbd714c801b5e34703ffb93493ac46050ccd28b49aac97a8_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_528ac0b9096e86fbedd4a9c129a8f9d39d8f10d4a6842cdb5ecc6f8fb8cdfe5d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_528ac0b9096e86fbedd4a9c129a8f9d39d8f10d4a6842cdb5ecc6f8fb8cdfe5d->enter($__internal_528ac0b9096e86fbedd4a9c129a8f9d39d8f10d4a6842cdb5ecc6f8fb8cdfe5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d362b31931be448ada25c7bfcd98be303944d069ef699f9967a021d2f01d42a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d362b31931be448ada25c7bfcd98be303944d069ef699f9967a021d2f01d42a3->enter($__internal_d362b31931be448ada25c7bfcd98be303944d069ef699f9967a021d2f01d42a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Goûter";
        
        $__internal_d362b31931be448ada25c7bfcd98be303944d069ef699f9967a021d2f01d42a3->leave($__internal_d362b31931be448ada25c7bfcd98be303944d069ef699f9967a021d2f01d42a3_prof);

        
        $__internal_528ac0b9096e86fbedd4a9c129a8f9d39d8f10d4a6842cdb5ecc6f8fb8cdfe5d->leave($__internal_528ac0b9096e86fbedd4a9c129a8f9d39d8f10d4a6842cdb5ecc6f8fb8cdfe5d_prof);

    }

    // line 69
    public function block_banner($context, array $blocks = array())
    {
        $__internal_9ebfa0fdfe45c121e71d3aa9dea74c77cbc931891bc4cbfcf92fbb46f81dd103 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ebfa0fdfe45c121e71d3aa9dea74c77cbc931891bc4cbfcf92fbb46f81dd103->enter($__internal_9ebfa0fdfe45c121e71d3aa9dea74c77cbc931891bc4cbfcf92fbb46f81dd103_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "banner"));

        $__internal_7a0be7a73d4a6b48a9e2d012aed8c3f536f3997985dbfd0eebbb0b79c94383e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a0be7a73d4a6b48a9e2d012aed8c3f536f3997985dbfd0eebbb0b79c94383e6->enter($__internal_7a0be7a73d4a6b48a9e2d012aed8c3f536f3997985dbfd0eebbb0b79c94383e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "banner"));

        echo " Goûter ";
        
        $__internal_7a0be7a73d4a6b48a9e2d012aed8c3f536f3997985dbfd0eebbb0b79c94383e6->leave($__internal_7a0be7a73d4a6b48a9e2d012aed8c3f536f3997985dbfd0eebbb0b79c94383e6_prof);

        
        $__internal_9ebfa0fdfe45c121e71d3aa9dea74c77cbc931891bc4cbfcf92fbb46f81dd103->leave($__internal_9ebfa0fdfe45c121e71d3aa9dea74c77cbc931891bc4cbfcf92fbb46f81dd103_prof);

    }

    // line 89
    public function block_content($context, array $blocks = array())
    {
        $__internal_aa623e8bed18021361df347540691a767b41aa4a3c8107c2f9811054a973e733 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa623e8bed18021361df347540691a767b41aa4a3c8107c2f9811054a973e733->enter($__internal_aa623e8bed18021361df347540691a767b41aa4a3c8107c2f9811054a973e733_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_7fe488410e0bc4415e594fd72ba31a5e1b617b603ce20598451461f80f2fd964 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fe488410e0bc4415e594fd72ba31a5e1b617b603ce20598451461f80f2fd964->enter($__internal_7fe488410e0bc4415e594fd72ba31a5e1b617b603ce20598451461f80f2fd964_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 90
        echo "
            <br>
            <br>
            <br>
            <br>
            <h1> Default Content </h1>
            <br>
            <br>
            <br>
            <br>
            <br>
    ";
        
        $__internal_7fe488410e0bc4415e594fd72ba31a5e1b617b603ce20598451461f80f2fd964->leave($__internal_7fe488410e0bc4415e594fd72ba31a5e1b617b603ce20598451461f80f2fd964_prof);

        
        $__internal_aa623e8bed18021361df347540691a767b41aa4a3c8107c2f9811054a973e733->leave($__internal_aa623e8bed18021361df347540691a767b41aa4a3c8107c2f9811054a973e733_prof);

    }

    public function getTemplateName()
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  313 => 90,  304 => 89,  286 => 69,  268 => 6,  253 => 151,  249 => 150,  245 => 149,  196 => 102,  194 => 89,  183 => 80,  177 => 78,  175 => 77,  170 => 76,  167 => 75,  163 => 73,  160 => 72,  155 => 69,  148 => 64,  140 => 62,  138 => 61,  133 => 60,  131 => 59,  127 => 57,  121 => 55,  119 => 54,  114 => 53,  112 => 52,  101 => 46,  81 => 29,  75 => 25,  70 => 22,  66 => 21,  61 => 20,  56 => 17,  52 => 16,  49 => 15,  43 => 12,  39 => 9,  34 => 6,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src\\Projet\\MainBundle\\Resources\\views\\Main\\layout.html.twig #}
<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>{% block title %}Goûter{% endblock %}</title>
    <!--CSS Layout-->
    {#Responsive#}
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    {#jQuery#}
    <script src=\"{{ asset('js/jquery-3.2.1.min.js') }}\"></script>

    {#Boostrap CDN#}
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
    <script src=\"{{ asset('js/jquery.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.min.js') }}\"></script>

    {#CSS#}
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('css/foodstyle.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('css/playvideo.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('css/user.css')}}\">

    {#Font family#}
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">

    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('img/cuisine.ico') }}\" />
    <!-------------->
</head>

<body onload=\"setInterval(myCounter, 1000)\">
    <!-- Top -->
    <div class=\"container-fluid\">
        <div class=\"row\">
            <!-- Nav bar -->
            <header style=\"height: 500px\" class=\"backgroundimg\">
                <nav style=\"background-color: transparent; border: none\" class=\"navbar navbar-default\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button id=\"togglebutton\" type=\"button\" data-target=\"#navbarCollapse\" data-toggle=\"collapse\" class=\"navbar-toggle\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span style=\"font-size: 27px;\">☰</span>
                        </button>
                        <a  href=\"{{ path('projet_main_homepage') }}\" class=\"navbar-brand\"><img id=\"logo\" src=\"{{asset('img/cutlery.png')}}\"></a>
                    </div>
                    <!-- Collection of nav links, forms, and other content for toggling -->
                    <div id=\"navbarCollapse\" class=\"collapse navbar-collapse\">
                        <ul id=\"rightofmenu\" class=\"nav navbar-nav navbar-right\">
                            <!-- <li class=\"togglelist\" ><a href=\"#\" style=\"color: white\"><button class=\"buttonright\" onclick=\"scroll_to()\">About us</button></a></li> -->
                            {% if app.user is null %}
                                <li class=\"togglelist\" ><a href=\"{{ path('projet_user_login') }}\" style=\"color: white\"><button class=\"buttonright\" type=\"button\" id=\"loginbutton\" >Connexion</button></a></li>
                            {% elseif app.user is not null %}
                                <li class=\"togglelist\" ><a href=\"{{ path('logout') }}\" style=\"color: white\"><button class=\"buttonright\" type=\"button\" id=\"loginbutton\" >Déconnexion</button></a></li>
                            {% endif %}
                        </ul>
                        <ul id=\"rightofmenu\" class=\"nav navbar-nav navbar-right\">
                            {% if app.user is null %}
                                <li class=\"togglelist\" ><a href=\"{{ path('projet_user_signup') }}\" style=\"color: white\"><button class=\"buttonright\" type=\"button\" id=\"loginbutton\">Inscription</button></a></li>
                            {% elseif app.user is not null %}
                                <li class=\"togglelist\" ><a href=\"{{ path('projet_user_profile',{'username':app.user.username}) }}\" style=\"color: white\"><button class=\"buttonrightmod\" type=\"button\" id=\"loginbutton\">{{ app.user.username }}</button></a></li>
                            {% endif %}
                        </ul>
                    </div>
                </nav>
                <!---End Nav-->

                <p id=\"banner\" class=\"col-sm-12\">{% block banner %} Goûter {% endblock %}</p>

                {# See all #}
                <div style=\"text-align: center;\">
                    <a href=\"{{ path('projet_main_show_recipe') }}\"><button id=\"explore\">Découvrir</button></a>
                {# Upload - connection required #}
                    {% if app.user is not null %}
                        <a href=\"{{ path('projet_main_addvideo') }}\"><button id=\"upload\">Déposer</button></a>
                    {% elseif app.user is null %}
                        <a href=\"{{ path('projet_user_login') }}\"><button id=\"upload\">Déposer</button></a>
                    {% endif %}
                </div>

            </header>

        </div>
    </div>
    <!--End Top-->
    <div >

    {% block content %}

            <br>
            <br>
            <br>
            <br>
            <h1> Default Content </h1>
            <br>
            <br>
            <br>
            <br>
            <br>
    {% endblock %}
    </div>
    <!--Content-->

    <!--End Content-->

    <!-- About us modal -->
        <div class=\"modal fade\" id=\"aboutModal\" role=\"dialog\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" style=\" color: white\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h2 style=\"text-align: center; font-family: 'Pacifico'; text-shadow: 2px 0 0 #fff, -2px 0 0 #fff, 0 2px 0 #fff, 0 -2px 0 #fff, 1px 1px #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff;\" class=\"modal-title\">Goûter</h2>
                    </div>
                    <div class=\"modal-body\">
                        <p style=\"text-align: center; font-size: 14px; font-family: Futura; font-size: 17px\">Ce site sert à vous donner les recettes de cuisines détaillées et <br>
                            aussi vous permet de partager vos vidéos avec les autres personnes</p><br>
                    </div>
                </div>
            </div>
        </div>
    <!-- End modal -->
    <!-- Contact modal -->
        <div class=\"modal fade\" id=\"contactModal\" role=\"dialog\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" style=\" color: white\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h2 style=\"text-align: center; font-family: 'Pacifico'; text-shadow: 2px 0 0 #fff, -2px 0 0 #fff, 0 2px 0 #fff, 0 -2px 0 #fff, 1px 1px #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff;\" class=\"modal-title\">Goûter</h2>
                    </div>
                    <div class=\"modal-body\">
                        <p style=\"text-align: center; font-size: 18px\"><br>
                            <span style=\"letter-spacing: 2px; margin-top: 5px; margin-bottom: 15px;\" class=\"glyphicon glyphicon-phone-alt\"></span> &nbsp; <a style=\"font-family: Futura; font-size: 18px; letter-spacing: 1px\" href=\"tel:+33123456789\">+33 1 23 45 67 89</a><br>
                            <span style=\"letter-spacing: 2px;\" class=\"glyphicon glyphicon-envelope\"></span> &nbsp; <a style=\"font-family: Futura; letter-spacing: 1px; font-size: 18px\" href=\"mailto:Gouter@gmail.com\">Gouter@gouter.com</a>
                        </p><br>
                    </div>
                </div>
            </div>
        </div>
    <!-- End modal -->
    <!--Footer-->
    <footer class=\"col-sm-12 text-center\">
        <a id=\"about\" data-toggle=\"modal\" data-target=\"#aboutModal\" href=\"#\">About us</a>
        <a id=\"contact\" data-toggle=\"modal\" data-target=\"#contactModal\" href=\"#\">Contact</a>
    </footer>
    <!--End Footer-->

    <!-- Javascript -->
    <script src=\"{{ asset('js/foodfunction.js')}}\"></script>
    <script src=\"{{ asset('js/playvideo.js')}}\"></script>
    <script src=\"{{ asset('js/user.js')}}\"></script>
    <!---------------->
</body>

</html>", "ProjetMainBundle:Main:layout.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/MainBundle/Resources/views/Main/layout.html.twig");
    }
}
