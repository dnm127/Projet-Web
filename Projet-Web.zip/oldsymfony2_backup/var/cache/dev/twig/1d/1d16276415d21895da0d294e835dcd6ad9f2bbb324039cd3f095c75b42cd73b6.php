<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_2ba0f56f9b19d48b6fd3b1473c856c7adbf9078996062e107dc532644b28ffe6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fe0b79e7e7a0bc078cb5a2235a4aeb29eb9814a904e1a400ed1eb08b32142051 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe0b79e7e7a0bc078cb5a2235a4aeb29eb9814a904e1a400ed1eb08b32142051->enter($__internal_fe0b79e7e7a0bc078cb5a2235a4aeb29eb9814a904e1a400ed1eb08b32142051_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_d4acbb55d11e966657a62e19d9912b27682f3bb112caee4ce1f936b9b09a6ba1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4acbb55d11e966657a62e19d9912b27682f3bb112caee4ce1f936b9b09a6ba1->enter($__internal_d4acbb55d11e966657a62e19d9912b27682f3bb112caee4ce1f936b9b09a6ba1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_fe0b79e7e7a0bc078cb5a2235a4aeb29eb9814a904e1a400ed1eb08b32142051->leave($__internal_fe0b79e7e7a0bc078cb5a2235a4aeb29eb9814a904e1a400ed1eb08b32142051_prof);

        
        $__internal_d4acbb55d11e966657a62e19d9912b27682f3bb112caee4ce1f936b9b09a6ba1->leave($__internal_d4acbb55d11e966657a62e19d9912b27682f3bb112caee4ce1f936b9b09a6ba1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_widget.html.php");
    }
}
