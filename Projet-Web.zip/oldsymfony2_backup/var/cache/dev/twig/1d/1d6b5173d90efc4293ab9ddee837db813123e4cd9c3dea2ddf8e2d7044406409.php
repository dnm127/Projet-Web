<?php

/* WebProfilerBundle:Collector:exception.css.twig */
class __TwigTemplate_24e56448187296e7e3554138bf0e199198f874c9fc61a67f1d3113cf3c0276c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68987f33f8322c8ac3da3d4d810eb05192b67f82490f5f6069cd8542a96207c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68987f33f8322c8ac3da3d4d810eb05192b67f82490f5f6069cd8542a96207c9->enter($__internal_68987f33f8322c8ac3da3d4d810eb05192b67f82490f5f6069cd8542a96207c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        $__internal_a41bf65c1a3bfc0421dd7c40e4e46a06c8a067dac0dc85f0a8abf4cacd585a7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a41bf65c1a3bfc0421dd7c40e4e46a06c8a067dac0dc85f0a8abf4cacd585a7f->enter($__internal_a41bf65c1a3bfc0421dd7c40e4e46a06c8a067dac0dc85f0a8abf4cacd585a7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
";
        
        $__internal_68987f33f8322c8ac3da3d4d810eb05192b67f82490f5f6069cd8542a96207c9->leave($__internal_68987f33f8322c8ac3da3d4d810eb05192b67f82490f5f6069cd8542a96207c9_prof);

        
        $__internal_a41bf65c1a3bfc0421dd7c40e4e46a06c8a067dac0dc85f0a8abf4cacd585a7f->leave($__internal_a41bf65c1a3bfc0421dd7c40e4e46a06c8a067dac0dc85f0a8abf4cacd585a7f_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
", "WebProfilerBundle:Collector:exception.css.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.css.twig");
    }
}
