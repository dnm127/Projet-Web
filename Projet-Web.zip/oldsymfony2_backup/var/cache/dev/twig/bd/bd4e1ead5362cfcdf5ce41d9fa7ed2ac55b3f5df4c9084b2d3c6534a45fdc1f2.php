<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_187aa2b4c8e3becf82f43d4af1b5dba22cdfa7469d4486c1208bf810ea936ba4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ffbea92c4180b9cc4fbf648dc1d6d8ce7f26f6da99e0eb6c72b7884a9a6f8745 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffbea92c4180b9cc4fbf648dc1d6d8ce7f26f6da99e0eb6c72b7884a9a6f8745->enter($__internal_ffbea92c4180b9cc4fbf648dc1d6d8ce7f26f6da99e0eb6c72b7884a9a6f8745_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $__internal_7685ef032d1cbd5ea4fc85c54795ab0e3183574b2e562fffa1ef32e3c3b581f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7685ef032d1cbd5ea4fc85c54795ab0e3183574b2e562fffa1ef32e3c3b581f0->enter($__internal_7685ef032d1cbd5ea4fc85c54795ab0e3183574b2e562fffa1ef32e3c3b581f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ffbea92c4180b9cc4fbf648dc1d6d8ce7f26f6da99e0eb6c72b7884a9a6f8745->leave($__internal_ffbea92c4180b9cc4fbf648dc1d6d8ce7f26f6da99e0eb6c72b7884a9a6f8745_prof);

        
        $__internal_7685ef032d1cbd5ea4fc85c54795ab0e3183574b2e562fffa1ef32e3c3b581f0->leave($__internal_7685ef032d1cbd5ea4fc85c54795ab0e3183574b2e562fffa1ef32e3c3b581f0_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_6c14e8797e1c9573846d3173499a1d70e328860ee43987ba4426da3668852041 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c14e8797e1c9573846d3173499a1d70e328860ee43987ba4426da3668852041->enter($__internal_6c14e8797e1c9573846d3173499a1d70e328860ee43987ba4426da3668852041_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_701ded3a5d0cfb01a86a0de522a729eaf98170d2a59d45b4fadbf24ea63d61a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_701ded3a5d0cfb01a86a0de522a729eaf98170d2a59d45b4fadbf24ea63d61a5->enter($__internal_701ded3a5d0cfb01a86a0de522a729eaf98170d2a59d45b4fadbf24ea63d61a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_701ded3a5d0cfb01a86a0de522a729eaf98170d2a59d45b4fadbf24ea63d61a5->leave($__internal_701ded3a5d0cfb01a86a0de522a729eaf98170d2a59d45b4fadbf24ea63d61a5_prof);

        
        $__internal_6c14e8797e1c9573846d3173499a1d70e328860ee43987ba4426da3668852041->leave($__internal_6c14e8797e1c9573846d3173499a1d70e328860ee43987ba4426da3668852041_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:edit.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Group/edit.html.twig");
    }
}
