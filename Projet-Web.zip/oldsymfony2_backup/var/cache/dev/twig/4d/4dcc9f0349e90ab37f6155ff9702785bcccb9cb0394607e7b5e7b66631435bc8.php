<?php

/* FOSUserBundle:Profile:email_update_confirmation.txt.twig */
class __TwigTemplate_13083d77fc6ebb45f6f48c366bfe84e83f9449956fd594de971f0c45f0d0341e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_32b6d3841d294ee8cde1931da4ff3ce77c2244b60836d8bcece8573e6823d2c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32b6d3841d294ee8cde1931da4ff3ce77c2244b60836d8bcece8573e6823d2c2->enter($__internal_32b6d3841d294ee8cde1931da4ff3ce77c2244b60836d8bcece8573e6823d2c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:email_update_confirmation.txt.twig"));

        $__internal_9cc26e75e9b7d98572b58edcb3acb4bb724961014d87f640226637450e293edd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cc26e75e9b7d98572b58edcb3acb4bb724961014d87f640226637450e293edd->enter($__internal_9cc26e75e9b7d98572b58edcb3acb4bb724961014d87f640226637450e293edd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:email_update_confirmation.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 5
        echo "
";
        // line 6
        $this->displayBlock('body_text', $context, $blocks);
        // line 9
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_32b6d3841d294ee8cde1931da4ff3ce77c2244b60836d8bcece8573e6823d2c2->leave($__internal_32b6d3841d294ee8cde1931da4ff3ce77c2244b60836d8bcece8573e6823d2c2_prof);

        
        $__internal_9cc26e75e9b7d98572b58edcb3acb4bb724961014d87f640226637450e293edd->leave($__internal_9cc26e75e9b7d98572b58edcb3acb4bb724961014d87f640226637450e293edd_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_e28ac457ba539668d57cbaea793e22f02cfd2c85e647f9fdb06920a2d4ac4def = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e28ac457ba539668d57cbaea793e22f02cfd2c85e647f9fdb06920a2d4ac4def->enter($__internal_e28ac457ba539668d57cbaea793e22f02cfd2c85e647f9fdb06920a2d4ac4def_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_db4ab974cacd4c3aa835f2321988f902e852a9ccf14442a0d9aca443f0e61f8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db4ab974cacd4c3aa835f2321988f902e852a9ccf14442a0d9aca443f0e61f8c->enter($__internal_db4ab974cacd4c3aa835f2321988f902e852a9ccf14442a0d9aca443f0e61f8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("email_update.email.subject", array(), "FOSUserBundle");
        echo "
";
        
        $__internal_db4ab974cacd4c3aa835f2321988f902e852a9ccf14442a0d9aca443f0e61f8c->leave($__internal_db4ab974cacd4c3aa835f2321988f902e852a9ccf14442a0d9aca443f0e61f8c_prof);

        
        $__internal_e28ac457ba539668d57cbaea793e22f02cfd2c85e647f9fdb06920a2d4ac4def->leave($__internal_e28ac457ba539668d57cbaea793e22f02cfd2c85e647f9fdb06920a2d4ac4def_prof);

    }

    // line 6
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_614bd2f1179ee6b7dd52fdbb7aa54eeac5be5fe8c465fc6f34952677af7b2042 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_614bd2f1179ee6b7dd52fdbb7aa54eeac5be5fe8c465fc6f34952677af7b2042->enter($__internal_614bd2f1179ee6b7dd52fdbb7aa54eeac5be5fe8c465fc6f34952677af7b2042_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_6204249b64c2c1ca4e31d4332c720c7a8e02ca1e75be0f3126cbbb49a7a9a2b8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6204249b64c2c1ca4e31d4332c720c7a8e02ca1e75be0f3126cbbb49a7a9a2b8->enter($__internal_6204249b64c2c1ca4e31d4332c720c7a8e02ca1e75be0f3126cbbb49a7a9a2b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("email_update.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_6204249b64c2c1ca4e31d4332c720c7a8e02ca1e75be0f3126cbbb49a7a9a2b8->leave($__internal_6204249b64c2c1ca4e31d4332c720c7a8e02ca1e75be0f3126cbbb49a7a9a2b8_prof);

        
        $__internal_614bd2f1179ee6b7dd52fdbb7aa54eeac5be5fe8c465fc6f34952677af7b2042->leave($__internal_614bd2f1179ee6b7dd52fdbb7aa54eeac5be5fe8c465fc6f34952677af7b2042_prof);

    }

    // line 9
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_4261fc88fcfd2019444dddc06f9bf045f560d189f49989559cb62a220f6f294c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4261fc88fcfd2019444dddc06f9bf045f560d189f49989559cb62a220f6f294c->enter($__internal_4261fc88fcfd2019444dddc06f9bf045f560d189f49989559cb62a220f6f294c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_0e36deec9ec12b4f019e00f94724ed42c864e67937b3e7a26343208207bd18c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e36deec9ec12b4f019e00f94724ed42c864e67937b3e7a26343208207bd18c2->enter($__internal_0e36deec9ec12b4f019e00f94724ed42c864e67937b3e7a26343208207bd18c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_0e36deec9ec12b4f019e00f94724ed42c864e67937b3e7a26343208207bd18c2->leave($__internal_0e36deec9ec12b4f019e00f94724ed42c864e67937b3e7a26343208207bd18c2_prof);

        
        $__internal_4261fc88fcfd2019444dddc06f9bf045f560d189f49989559cb62a220f6f294c->leave($__internal_4261fc88fcfd2019444dddc06f9bf045f560d189f49989559cb62a220f6f294c_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:email_update_confirmation.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  87 => 9,  75 => 7,  66 => 6,  54 => 3,  45 => 2,  35 => 9,  33 => 6,  30 => 5,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{{ 'email_update.email.subject'|trans }}
{% endblock %}

{% block body_text %}
{{ 'email_update.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Profile:email_update_confirmation.txt.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/email_update_confirmation.txt.twig");
    }
}
