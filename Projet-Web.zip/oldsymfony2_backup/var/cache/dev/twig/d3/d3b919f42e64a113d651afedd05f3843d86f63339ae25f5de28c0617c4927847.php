<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_82c7993965fde99ecf69c8097676a5e48ec12b53dae12640ab117480774d056c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7d3f8b102d6a94d1704067c2284e5b5fd0afac5aff750a41070f91aaaea289f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7d3f8b102d6a94d1704067c2284e5b5fd0afac5aff750a41070f91aaaea289f->enter($__internal_d7d3f8b102d6a94d1704067c2284e5b5fd0afac5aff750a41070f91aaaea289f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $__internal_6fa02f9e4f79109925a9e090b9e5d0d55e9f1060838e1936a2938e0ae3cdb36e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fa02f9e4f79109925a9e090b9e5d0d55e9f1060838e1936a2938e0ae3cdb36e->enter($__internal_6fa02f9e4f79109925a9e090b9e5d0d55e9f1060838e1936a2938e0ae3cdb36e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d7d3f8b102d6a94d1704067c2284e5b5fd0afac5aff750a41070f91aaaea289f->leave($__internal_d7d3f8b102d6a94d1704067c2284e5b5fd0afac5aff750a41070f91aaaea289f_prof);

        
        $__internal_6fa02f9e4f79109925a9e090b9e5d0d55e9f1060838e1936a2938e0ae3cdb36e->leave($__internal_6fa02f9e4f79109925a9e090b9e5d0d55e9f1060838e1936a2938e0ae3cdb36e_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cd56468e78bebc0c1c0c24ebf7b7d945cbeff6144910bc326a64f0bf84a1b113 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cd56468e78bebc0c1c0c24ebf7b7d945cbeff6144910bc326a64f0bf84a1b113->enter($__internal_cd56468e78bebc0c1c0c24ebf7b7d945cbeff6144910bc326a64f0bf84a1b113_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_f27f8ee7a35660b9e178c20d2f4d9a8c3317461f0f26c2ab8fb5503259ddfe59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f27f8ee7a35660b9e178c20d2f4d9a8c3317461f0f26c2ab8fb5503259ddfe59->enter($__internal_f27f8ee7a35660b9e178c20d2f4d9a8c3317461f0f26c2ab8fb5503259ddfe59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Profile/edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_f27f8ee7a35660b9e178c20d2f4d9a8c3317461f0f26c2ab8fb5503259ddfe59->leave($__internal_f27f8ee7a35660b9e178c20d2f4d9a8c3317461f0f26c2ab8fb5503259ddfe59_prof);

        
        $__internal_cd56468e78bebc0c1c0c24ebf7b7d945cbeff6144910bc326a64f0bf84a1b113->leave($__internal_cd56468e78bebc0c1c0c24ebf7b7d945cbeff6144910bc326a64f0bf84a1b113_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Profile/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:edit.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/edit.html.twig");
    }
}
