<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_6b4916d2004a4f8ede0b9a978dccc570eb5eefd5440914c7cb9728a5367bb188 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_59ded29387d56c1c9da3bd3f4faf206edb52a483a48d9975cc5f755d572f8e74 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59ded29387d56c1c9da3bd3f4faf206edb52a483a48d9975cc5f755d572f8e74->enter($__internal_59ded29387d56c1c9da3bd3f4faf206edb52a483a48d9975cc5f755d572f8e74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_9f3e51f2e0162489da87bc2c98fb14740d6180e33edce1e9d81eca7949366236 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f3e51f2e0162489da87bc2c98fb14740d6180e33edce1e9d81eca7949366236->enter($__internal_9f3e51f2e0162489da87bc2c98fb14740d6180e33edce1e9d81eca7949366236_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_59ded29387d56c1c9da3bd3f4faf206edb52a483a48d9975cc5f755d572f8e74->leave($__internal_59ded29387d56c1c9da3bd3f4faf206edb52a483a48d9975cc5f755d572f8e74_prof);

        
        $__internal_9f3e51f2e0162489da87bc2c98fb14740d6180e33edce1e9d81eca7949366236->leave($__internal_9f3e51f2e0162489da87bc2c98fb14740d6180e33edce1e9d81eca7949366236_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/widget_container_attributes.html.php");
    }
}
