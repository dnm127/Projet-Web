<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_72f275caede84b6c552a3eba18bf762b34306eb98f1b56394a3c648f76956f1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68c60a000895389b6f7c05a9f133635e17c0391fa22c3b96cb2f42685837e199 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68c60a000895389b6f7c05a9f133635e17c0391fa22c3b96cb2f42685837e199->enter($__internal_68c60a000895389b6f7c05a9f133635e17c0391fa22c3b96cb2f42685837e199_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        $__internal_b06d6beb9c8bc972b9fb43a80bac058707744e10e8b1bd954f7a6c81098b3fda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b06d6beb9c8bc972b9fb43a80bac058707744e10e8b1bd954f7a6c81098b3fda->enter($__internal_b06d6beb9c8bc972b9fb43a80bac058707744e10e8b1bd954f7a6c81098b3fda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_68c60a000895389b6f7c05a9f133635e17c0391fa22c3b96cb2f42685837e199->leave($__internal_68c60a000895389b6f7c05a9f133635e17c0391fa22c3b96cb2f42685837e199_prof);

        
        $__internal_b06d6beb9c8bc972b9fb43a80bac058707744e10e8b1bd954f7a6c81098b3fda->leave($__internal_b06d6beb9c8bc972b9fb43a80bac058707744e10e8b1bd954f7a6c81098b3fda_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_6c8ceb0017d47f7383166ff722baa31db1bda02dc2e51f65bb3d807235e833e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c8ceb0017d47f7383166ff722baa31db1bda02dc2e51f65bb3d807235e833e4->enter($__internal_6c8ceb0017d47f7383166ff722baa31db1bda02dc2e51f65bb3d807235e833e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_49e157891b23df3eaa98564796a380f91f16695ca84a506150a6b42df7f7f5b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49e157891b23df3eaa98564796a380f91f16695ca84a506150a6b42df7f7f5b9->enter($__internal_49e157891b23df3eaa98564796a380f91f16695ca84a506150a6b42df7f7f5b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        
        $__internal_49e157891b23df3eaa98564796a380f91f16695ca84a506150a6b42df7f7f5b9->leave($__internal_49e157891b23df3eaa98564796a380f91f16695ca84a506150a6b42df7f7f5b9_prof);

        
        $__internal_6c8ceb0017d47f7383166ff722baa31db1bda02dc2e51f65bb3d807235e833e4->leave($__internal_6c8ceb0017d47f7383166ff722baa31db1bda02dc2e51f65bb3d807235e833e4_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_c83451aa05073f939b873230bc366dcd8c5ac8057a3a35064d195217ee4adb4f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c83451aa05073f939b873230bc366dcd8c5ac8057a3a35064d195217ee4adb4f->enter($__internal_c83451aa05073f939b873230bc366dcd8c5ac8057a3a35064d195217ee4adb4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_6936b7d55703311b17259daa1d43d44d939e86489854ccbc12afe17e1acb2b63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6936b7d55703311b17259daa1d43d44d939e86489854ccbc12afe17e1acb2b63->enter($__internal_6936b7d55703311b17259daa1d43d44d939e86489854ccbc12afe17e1acb2b63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_6936b7d55703311b17259daa1d43d44d939e86489854ccbc12afe17e1acb2b63->leave($__internal_6936b7d55703311b17259daa1d43d44d939e86489854ccbc12afe17e1acb2b63_prof);

        
        $__internal_c83451aa05073f939b873230bc366dcd8c5ac8057a3a35064d195217ee4adb4f->leave($__internal_c83451aa05073f939b873230bc366dcd8c5ac8057a3a35064d195217ee4adb4f_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_3bdbdcf406d20e0cf9c39316089344949ba703a82082109a2f43a3c00ac84894 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3bdbdcf406d20e0cf9c39316089344949ba703a82082109a2f43a3c00ac84894->enter($__internal_3bdbdcf406d20e0cf9c39316089344949ba703a82082109a2f43a3c00ac84894_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_560914ce4d5ff5850951026ae9e8e5f52ca8a441845f8e207e1be08d5e919ff3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_560914ce4d5ff5850951026ae9e8e5f52ca8a441845f8e207e1be08d5e919ff3->enter($__internal_560914ce4d5ff5850951026ae9e8e5f52ca8a441845f8e207e1be08d5e919ff3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_560914ce4d5ff5850951026ae9e8e5f52ca8a441845f8e207e1be08d5e919ff3->leave($__internal_560914ce4d5ff5850951026ae9e8e5f52ca8a441845f8e207e1be08d5e919ff3_prof);

        
        $__internal_3bdbdcf406d20e0cf9c39316089344949ba703a82082109a2f43a3c00ac84894->leave($__internal_3bdbdcf406d20e0cf9c39316089344949ba703a82082109a2f43a3c00ac84894_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 13,  73 => 10,  64 => 8,  54 => 4,  45 => 2,  35 => 13,  33 => 8,  30 => 7,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'resetting.email.subject'|trans({'%username%': user.username}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Resetting:email.txt.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/email.txt.twig");
    }
}
