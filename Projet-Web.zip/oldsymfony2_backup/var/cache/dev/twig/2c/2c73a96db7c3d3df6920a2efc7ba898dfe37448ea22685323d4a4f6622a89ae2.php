<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_9686a4200268e8228f08a645977c6ab94f42aa617b6e80356a4d3defaa116264 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_344023da6b7a6bc1f811d75389725be87f61792b185b8099b48b39d3ee501620 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_344023da6b7a6bc1f811d75389725be87f61792b185b8099b48b39d3ee501620->enter($__internal_344023da6b7a6bc1f811d75389725be87f61792b185b8099b48b39d3ee501620_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_988e2321557aec8bca62d9392b199662f364b14be76b455797600fbb16c7042b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_988e2321557aec8bca62d9392b199662f364b14be76b455797600fbb16c7042b->enter($__internal_988e2321557aec8bca62d9392b199662f364b14be76b455797600fbb16c7042b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_344023da6b7a6bc1f811d75389725be87f61792b185b8099b48b39d3ee501620->leave($__internal_344023da6b7a6bc1f811d75389725be87f61792b185b8099b48b39d3ee501620_prof);

        
        $__internal_988e2321557aec8bca62d9392b199662f364b14be76b455797600fbb16c7042b->leave($__internal_988e2321557aec8bca62d9392b199662f364b14be76b455797600fbb16c7042b_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_8ec9585cafc72eff481a29378a43db24a06036938c0d2339b27596a6c5a78982 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ec9585cafc72eff481a29378a43db24a06036938c0d2339b27596a6c5a78982->enter($__internal_8ec9585cafc72eff481a29378a43db24a06036938c0d2339b27596a6c5a78982_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_483345802ae47d4a9c3ef3bd7ee91303e244236189efe2245316d69e00e5ce49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_483345802ae47d4a9c3ef3bd7ee91303e244236189efe2245316d69e00e5ce49->enter($__internal_483345802ae47d4a9c3ef3bd7ee91303e244236189efe2245316d69e00e5ce49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_483345802ae47d4a9c3ef3bd7ee91303e244236189efe2245316d69e00e5ce49->leave($__internal_483345802ae47d4a9c3ef3bd7ee91303e244236189efe2245316d69e00e5ce49_prof);

        
        $__internal_8ec9585cafc72eff481a29378a43db24a06036938c0d2339b27596a6c5a78982->leave($__internal_8ec9585cafc72eff481a29378a43db24a06036938c0d2339b27596a6c5a78982_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_4ae7637daad4e5cc6aa7cd95a763e782fdc01a999b33d73c3cca1decbf29427d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ae7637daad4e5cc6aa7cd95a763e782fdc01a999b33d73c3cca1decbf29427d->enter($__internal_4ae7637daad4e5cc6aa7cd95a763e782fdc01a999b33d73c3cca1decbf29427d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_a715382a0c7b8cb7bfe572f2bd42d03ccd3a89e683e6ed0cb5daca1eb61e450c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a715382a0c7b8cb7bfe572f2bd42d03ccd3a89e683e6ed0cb5daca1eb61e450c->enter($__internal_a715382a0c7b8cb7bfe572f2bd42d03ccd3a89e683e6ed0cb5daca1eb61e450c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_a715382a0c7b8cb7bfe572f2bd42d03ccd3a89e683e6ed0cb5daca1eb61e450c->leave($__internal_a715382a0c7b8cb7bfe572f2bd42d03ccd3a89e683e6ed0cb5daca1eb61e450c_prof);

        
        $__internal_4ae7637daad4e5cc6aa7cd95a763e782fdc01a999b33d73c3cca1decbf29427d->leave($__internal_4ae7637daad4e5cc6aa7cd95a763e782fdc01a999b33d73c3cca1decbf29427d_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d2afec89c034c245e858931133790d421b582d1495a768b9a304f0cddfa24d1f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d2afec89c034c245e858931133790d421b582d1495a768b9a304f0cddfa24d1f->enter($__internal_d2afec89c034c245e858931133790d421b582d1495a768b9a304f0cddfa24d1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_73c667221b9afd641112e3c455b77c305d7488be962d0961201cae49a31c19e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73c667221b9afd641112e3c455b77c305d7488be962d0961201cae49a31c19e0->enter($__internal_73c667221b9afd641112e3c455b77c305d7488be962d0961201cae49a31c19e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_73c667221b9afd641112e3c455b77c305d7488be962d0961201cae49a31c19e0->leave($__internal_73c667221b9afd641112e3c455b77c305d7488be962d0961201cae49a31c19e0_prof);

        
        $__internal_d2afec89c034c245e858931133790d421b582d1495a768b9a304f0cddfa24d1f->leave($__internal_d2afec89c034c245e858931133790d421b582d1495a768b9a304f0cddfa24d1f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
