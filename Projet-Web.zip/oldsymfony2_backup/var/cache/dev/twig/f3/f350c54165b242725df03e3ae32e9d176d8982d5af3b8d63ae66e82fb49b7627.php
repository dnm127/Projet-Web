<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_6345b9a229c59d32a6438fb9b06336ec4df8ce4b96e430931cffc1106f2e4e97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a5a2a9d67f3bc3a9d01d9bf02e4f2e5322222ab3d4fcded595543206ffcf81d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a5a2a9d67f3bc3a9d01d9bf02e4f2e5322222ab3d4fcded595543206ffcf81d->enter($__internal_6a5a2a9d67f3bc3a9d01d9bf02e4f2e5322222ab3d4fcded595543206ffcf81d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_61f652de55b92d0b2d63b10147549c250bb4eae15751f93d21c1a5c0012dfc14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_61f652de55b92d0b2d63b10147549c250bb4eae15751f93d21c1a5c0012dfc14->enter($__internal_61f652de55b92d0b2d63b10147549c250bb4eae15751f93d21c1a5c0012dfc14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_6a5a2a9d67f3bc3a9d01d9bf02e4f2e5322222ab3d4fcded595543206ffcf81d->leave($__internal_6a5a2a9d67f3bc3a9d01d9bf02e4f2e5322222ab3d4fcded595543206ffcf81d_prof);

        
        $__internal_61f652de55b92d0b2d63b10147549c250bb4eae15751f93d21c1a5c0012dfc14->leave($__internal_61f652de55b92d0b2d63b10147549c250bb4eae15751f93d21c1a5c0012dfc14_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
