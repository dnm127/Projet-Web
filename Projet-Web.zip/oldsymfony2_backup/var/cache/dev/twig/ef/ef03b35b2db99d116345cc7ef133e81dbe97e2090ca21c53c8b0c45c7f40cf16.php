<?php

/* ProjetUserBundle:Security:login_check.html.twig */
class __TwigTemplate_e010edeaebd13c63450ccfe3346ad47eb345f5e7429dbc7e70504d8e27c96cd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetUserBundle:Security:login_check.html.twig", 3);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d3dd4be518f2b576cae40d1354fb634585411caf0dce9adb1ef742c45e393c6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d3dd4be518f2b576cae40d1354fb634585411caf0dce9adb1ef742c45e393c6->enter($__internal_9d3dd4be518f2b576cae40d1354fb634585411caf0dce9adb1ef742c45e393c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:login_check.html.twig"));

        $__internal_1919ec12b89512b35c17e8e6d1e8774fd6ccd99b47ffd37e07dab3d7822b1f3b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1919ec12b89512b35c17e8e6d1e8774fd6ccd99b47ffd37e07dab3d7822b1f3b->enter($__internal_1919ec12b89512b35c17e8e6d1e8774fd6ccd99b47ffd37e07dab3d7822b1f3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:login_check.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9d3dd4be518f2b576cae40d1354fb634585411caf0dce9adb1ef742c45e393c6->leave($__internal_9d3dd4be518f2b576cae40d1354fb634585411caf0dce9adb1ef742c45e393c6_prof);

        
        $__internal_1919ec12b89512b35c17e8e6d1e8774fd6ccd99b47ffd37e07dab3d7822b1f3b->leave($__internal_1919ec12b89512b35c17e8e6d1e8774fd6ccd99b47ffd37e07dab3d7822b1f3b_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_2415e33e61397cdb9569287db7b6a349920cbb94d1e3adaddf12bc9c984741b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2415e33e61397cdb9569287db7b6a349920cbb94d1e3adaddf12bc9c984741b1->enter($__internal_2415e33e61397cdb9569287db7b6a349920cbb94d1e3adaddf12bc9c984741b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_67106954c29aa04a55937daf08f2e397ebe66ceb81325534ee54cb0bdd254704 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67106954c29aa04a55937daf08f2e397ebe66ceb81325534ee54cb0bdd254704->enter($__internal_67106954c29aa04a55937daf08f2e397ebe66ceb81325534ee54cb0bdd254704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "
   ";
        // line 8
        echo "    ";
        // line 9
        echo "    ";
        // line 10
        echo "       ";
        // line 11
        echo "    ";
        // line 12
        echo "   ";
        // line 13
        echo "   ";
        // line 14
        echo "      ";
        // line 15
        echo "      ";
        // line 16
        echo "   ";
        // line 17
        echo "
   ";
        // line 19
        echo "   ";
        // line 20
        echo "
   ";
        // line 21
        if ((null === $this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            // line 22
            echo "      <p> Username: Null </p>
   ";
        } else {
            // line 24
            echo "      <p> Username: ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo "</p>
      <p> Email: ";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "email", array()), "html", null, true);
            echo "</p>
   ";
        }
        
        $__internal_67106954c29aa04a55937daf08f2e397ebe66ceb81325534ee54cb0bdd254704->leave($__internal_67106954c29aa04a55937daf08f2e397ebe66ceb81325534ee54cb0bdd254704_prof);

        
        $__internal_2415e33e61397cdb9569287db7b6a349920cbb94d1e3adaddf12bc9c984741b1->leave($__internal_2415e33e61397cdb9569287db7b6a349920cbb94d1e3adaddf12bc9c984741b1_prof);

    }

    public function getTemplateName()
    {
        return "ProjetUserBundle:Security:login_check.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 25,  84 => 24,  80 => 22,  78 => 21,  75 => 20,  73 => 19,  70 => 17,  68 => 16,  66 => 15,  64 => 14,  62 => 13,  60 => 12,  58 => 11,  56 => 10,  54 => 9,  52 => 8,  49 => 6,  40 => 5,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/UserBundle/Resources/views/Security/login_check.html.twig #}

{% extends \"ProjetMainBundle:Main:layout.html.twig\" %}

{% block content %}

   {#<p>#}
    {# On affiche tous les messages flash dont le nom est « info » #}
    {#{% for message in app.session.flashbag.get('info') %}#}
       {#<p>Message flash : {{ message }}</p>#}
    {#{% endfor %}#}
   {#</p>#}
   {#<p>#}
      {#Ici nous pourrons lire l'annonce ayant comme id : <br />#}
      {#Mais pour l'instant, nous ne savons pas encore le faire, cela viendra !#}
   {#</p>#}

   {#<h2> User Info </h2>#}
   {#<br>#}

   {% if app.user is null %}
      <p> Username: Null </p>
   {% else %}
      <p> Username: {{ app.user.username }}</p>
      <p> Email: {{ app.user.email }}</p>
   {% endif %}
{% endblock %}", "ProjetUserBundle:Security:login_check.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/UserBundle/Resources/views/Security/login_check.html.twig");
    }
}
