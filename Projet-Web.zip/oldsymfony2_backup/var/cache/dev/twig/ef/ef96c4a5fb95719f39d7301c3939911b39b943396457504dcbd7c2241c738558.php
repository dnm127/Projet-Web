<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_92c4c16fe90ae45b7e50bfe5aa01b5f6e01341dcb956b13f441361b68673d946 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_21ac8bdb8872cf914931b2ae16a7f918b2d0f6d42825ad50ae2e7abebd350c23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_21ac8bdb8872cf914931b2ae16a7f918b2d0f6d42825ad50ae2e7abebd350c23->enter($__internal_21ac8bdb8872cf914931b2ae16a7f918b2d0f6d42825ad50ae2e7abebd350c23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_9056e0a61655c419cd0d75710311020485c629fcbfecdc61b0d03269f6550b31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9056e0a61655c419cd0d75710311020485c629fcbfecdc61b0d03269f6550b31->enter($__internal_9056e0a61655c419cd0d75710311020485c629fcbfecdc61b0d03269f6550b31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_21ac8bdb8872cf914931b2ae16a7f918b2d0f6d42825ad50ae2e7abebd350c23->leave($__internal_21ac8bdb8872cf914931b2ae16a7f918b2d0f6d42825ad50ae2e7abebd350c23_prof);

        
        $__internal_9056e0a61655c419cd0d75710311020485c629fcbfecdc61b0d03269f6550b31->leave($__internal_9056e0a61655c419cd0d75710311020485c629fcbfecdc61b0d03269f6550b31_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
