<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_d710e7ed16c18f0504d5f91d400a6c996ab5f8d92eace2554193e8bcb124937a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb73d691096847496fae556bdb1abbc1d5384592e0d1cda5b4a966f530978a74 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb73d691096847496fae556bdb1abbc1d5384592e0d1cda5b4a966f530978a74->enter($__internal_cb73d691096847496fae556bdb1abbc1d5384592e0d1cda5b4a966f530978a74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_307454919d6f340873dff723823c0324ad744b7fd4d6b1ea6860ee129a8a7817 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_307454919d6f340873dff723823c0324ad744b7fd4d6b1ea6860ee129a8a7817->enter($__internal_307454919d6f340873dff723823c0324ad744b7fd4d6b1ea6860ee129a8a7817_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_cb73d691096847496fae556bdb1abbc1d5384592e0d1cda5b4a966f530978a74->leave($__internal_cb73d691096847496fae556bdb1abbc1d5384592e0d1cda5b4a966f530978a74_prof);

        
        $__internal_307454919d6f340873dff723823c0324ad744b7fd4d6b1ea6860ee129a8a7817->leave($__internal_307454919d6f340873dff723823c0324ad744b7fd4d6b1ea6860ee129a8a7817_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
