<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_7c0eb4a933adb72ad8c55e92047cc9a227a3d982099fb8a08783c3f19e14eba6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd95fee59540f00766d2b1780d21896bc5403b6991da78f51293ff57cc01291c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd95fee59540f00766d2b1780d21896bc5403b6991da78f51293ff57cc01291c->enter($__internal_fd95fee59540f00766d2b1780d21896bc5403b6991da78f51293ff57cc01291c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_f59ed5e04be29928c43234d11681872e6ca523f2bed8ae6351e9b1116752d336 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f59ed5e04be29928c43234d11681872e6ca523f2bed8ae6351e9b1116752d336->enter($__internal_f59ed5e04be29928c43234d11681872e6ca523f2bed8ae6351e9b1116752d336_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_fd95fee59540f00766d2b1780d21896bc5403b6991da78f51293ff57cc01291c->leave($__internal_fd95fee59540f00766d2b1780d21896bc5403b6991da78f51293ff57cc01291c_prof);

        
        $__internal_f59ed5e04be29928c43234d11681872e6ca523f2bed8ae6351e9b1116752d336->leave($__internal_f59ed5e04be29928c43234d11681872e6ca523f2bed8ae6351e9b1116752d336_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/collection_widget.html.php");
    }
}
