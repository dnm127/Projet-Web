<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_bd1fc7b3fabd538759b30c9d2c371a08aab40d4c2b76808f84b16773da70163b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6cd54a8dfdd49902b3db4e38870d5b87ac23c903965b0651d06bdc70feb482d8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cd54a8dfdd49902b3db4e38870d5b87ac23c903965b0651d06bdc70feb482d8->enter($__internal_6cd54a8dfdd49902b3db4e38870d5b87ac23c903965b0651d06bdc70feb482d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_2718d122c9ef294f825353a7d79d69d6c491ab989117a4014ecadf6389af41e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2718d122c9ef294f825353a7d79d69d6c491ab989117a4014ecadf6389af41e8->enter($__internal_2718d122c9ef294f825353a7d79d69d6c491ab989117a4014ecadf6389af41e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_6cd54a8dfdd49902b3db4e38870d5b87ac23c903965b0651d06bdc70feb482d8->leave($__internal_6cd54a8dfdd49902b3db4e38870d5b87ac23c903965b0651d06bdc70feb482d8_prof);

        
        $__internal_2718d122c9ef294f825353a7d79d69d6c491ab989117a4014ecadf6389af41e8->leave($__internal_2718d122c9ef294f825353a7d79d69d6c491ab989117a4014ecadf6389af41e8_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
