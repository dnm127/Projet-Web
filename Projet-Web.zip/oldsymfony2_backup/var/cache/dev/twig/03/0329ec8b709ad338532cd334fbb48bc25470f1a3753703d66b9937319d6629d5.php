<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_7323d476f9469c5128a7316d645120c09567e66e251c63abb52239e168880530 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f404bd6596f895d122d87c8b7c6f4ae87535ea2086877c7ca5d3abdc00cc57a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f404bd6596f895d122d87c8b7c6f4ae87535ea2086877c7ca5d3abdc00cc57a->enter($__internal_3f404bd6596f895d122d87c8b7c6f4ae87535ea2086877c7ca5d3abdc00cc57a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_07982eaf475242293bc0fdde1ac44136b7b48e4853cefc11b6e1526b1e3cf8bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07982eaf475242293bc0fdde1ac44136b7b48e4853cefc11b6e1526b1e3cf8bc->enter($__internal_07982eaf475242293bc0fdde1ac44136b7b48e4853cefc11b6e1526b1e3cf8bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_3f404bd6596f895d122d87c8b7c6f4ae87535ea2086877c7ca5d3abdc00cc57a->leave($__internal_3f404bd6596f895d122d87c8b7c6f4ae87535ea2086877c7ca5d3abdc00cc57a_prof);

        
        $__internal_07982eaf475242293bc0fdde1ac44136b7b48e4853cefc11b6e1526b1e3cf8bc->leave($__internal_07982eaf475242293bc0fdde1ac44136b7b48e4853cefc11b6e1526b1e3cf8bc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/url_widget.html.php");
    }
}
