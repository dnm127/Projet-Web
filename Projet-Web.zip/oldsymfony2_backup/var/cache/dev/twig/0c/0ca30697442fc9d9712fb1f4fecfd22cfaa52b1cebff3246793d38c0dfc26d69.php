<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_1f5dfc6c29e4a91284415f9864f199561d50dba9fb54c166beede1ccf0fa358d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9d342e0754ecd3ee5959978a8de7e7133912e4fc5d82252d4a82edb4f01f8dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9d342e0754ecd3ee5959978a8de7e7133912e4fc5d82252d4a82edb4f01f8dc->enter($__internal_c9d342e0754ecd3ee5959978a8de7e7133912e4fc5d82252d4a82edb4f01f8dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $__internal_53bc7493cfe38557d3361a3512ace2496a7801b1987fd316e18244889153aff7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53bc7493cfe38557d3361a3512ace2496a7801b1987fd316e18244889153aff7->enter($__internal_53bc7493cfe38557d3361a3512ace2496a7801b1987fd316e18244889153aff7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c9d342e0754ecd3ee5959978a8de7e7133912e4fc5d82252d4a82edb4f01f8dc->leave($__internal_c9d342e0754ecd3ee5959978a8de7e7133912e4fc5d82252d4a82edb4f01f8dc_prof);

        
        $__internal_53bc7493cfe38557d3361a3512ace2496a7801b1987fd316e18244889153aff7->leave($__internal_53bc7493cfe38557d3361a3512ace2496a7801b1987fd316e18244889153aff7_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_2164d480c91a7574c38f180274d84db458fd0f399f91c97a69601e87591e26d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2164d480c91a7574c38f180274d84db458fd0f399f91c97a69601e87591e26d3->enter($__internal_2164d480c91a7574c38f180274d84db458fd0f399f91c97a69601e87591e26d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_06e55350f88884943d6562d4424e7577acfb3e41156bf80e240d990db1349fdb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06e55350f88884943d6562d4424e7577acfb3e41156bf80e240d990db1349fdb->enter($__internal_06e55350f88884943d6562d4424e7577acfb3e41156bf80e240d990db1349fdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_06e55350f88884943d6562d4424e7577acfb3e41156bf80e240d990db1349fdb->leave($__internal_06e55350f88884943d6562d4424e7577acfb3e41156bf80e240d990db1349fdb_prof);

        
        $__internal_2164d480c91a7574c38f180274d84db458fd0f399f91c97a69601e87591e26d3->leave($__internal_2164d480c91a7574c38f180274d84db458fd0f399f91c97a69601e87591e26d3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/reset_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:reset.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/reset.html.twig");
    }
}
