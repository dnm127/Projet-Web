<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_f3dbc4680563fc20d0f56968621e8515a0943d71d71139c8564e120522b6f795 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fcb87ea8b33e9c255d4e23fca71bea59af00efaed35dc727e8fb6db2e31e92b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fcb87ea8b33e9c255d4e23fca71bea59af00efaed35dc727e8fb6db2e31e92b8->enter($__internal_fcb87ea8b33e9c255d4e23fca71bea59af00efaed35dc727e8fb6db2e31e92b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_36da4162a5e1adb01b53da163f19a78c20fc4e30639ff4608c35e88739112637 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36da4162a5e1adb01b53da163f19a78c20fc4e30639ff4608c35e88739112637->enter($__internal_36da4162a5e1adb01b53da163f19a78c20fc4e30639ff4608c35e88739112637_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_fcb87ea8b33e9c255d4e23fca71bea59af00efaed35dc727e8fb6db2e31e92b8->leave($__internal_fcb87ea8b33e9c255d4e23fca71bea59af00efaed35dc727e8fb6db2e31e92b8_prof);

        
        $__internal_36da4162a5e1adb01b53da163f19a78c20fc4e30639ff4608c35e88739112637->leave($__internal_36da4162a5e1adb01b53da163f19a78c20fc4e30639ff4608c35e88739112637_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rows.html.php");
    }
}
