<?php

/* ProjetMainBundle:Main:recette.html.twig */
class __TwigTemplate_45e88de9f030db1f9954645a600d15bc25f9a60f7372dbcfd54f2d9399122326 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetMainBundle:Main:recette.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'banner' => array($this, 'block_banner'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_398151226ff89af03fddb7481f2fe15f1c14480c23843ac083031552ce5eb4f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_398151226ff89af03fddb7481f2fe15f1c14480c23843ac083031552ce5eb4f5->enter($__internal_398151226ff89af03fddb7481f2fe15f1c14480c23843ac083031552ce5eb4f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:recette.html.twig"));

        $__internal_d639b8047b292e3b6d524e94a13d45de18490f784b675c04d5fce4e1fb64d103 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d639b8047b292e3b6d524e94a13d45de18490f784b675c04d5fce4e1fb64d103->enter($__internal_d639b8047b292e3b6d524e94a13d45de18490f784b675c04d5fce4e1fb64d103_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetMainBundle:Main:recette.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_398151226ff89af03fddb7481f2fe15f1c14480c23843ac083031552ce5eb4f5->leave($__internal_398151226ff89af03fddb7481f2fe15f1c14480c23843ac083031552ce5eb4f5_prof);

        
        $__internal_d639b8047b292e3b6d524e94a13d45de18490f784b675c04d5fce4e1fb64d103->leave($__internal_d639b8047b292e3b6d524e94a13d45de18490f784b675c04d5fce4e1fb64d103_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_784199cb60e2ea2b3f8b61b413d9b8de47b26f44c28757d4e1361c048249c19e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_784199cb60e2ea2b3f8b61b413d9b8de47b26f44c28757d4e1361c048249c19e->enter($__internal_784199cb60e2ea2b3f8b61b413d9b8de47b26f44c28757d4e1361c048249c19e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2364cc1f3c39d6a95d08fd9429ce71418898907653d041a0a99564097a9bd744 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2364cc1f3c39d6a95d08fd9429ce71418898907653d041a0a99564097a9bd744->enter($__internal_2364cc1f3c39d6a95d08fd9429ce71418898907653d041a0a99564097a9bd744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Recettes ";
        
        $__internal_2364cc1f3c39d6a95d08fd9429ce71418898907653d041a0a99564097a9bd744->leave($__internal_2364cc1f3c39d6a95d08fd9429ce71418898907653d041a0a99564097a9bd744_prof);

        
        $__internal_784199cb60e2ea2b3f8b61b413d9b8de47b26f44c28757d4e1361c048249c19e->leave($__internal_784199cb60e2ea2b3f8b61b413d9b8de47b26f44c28757d4e1361c048249c19e_prof);

    }

    // line 7
    public function block_banner($context, array $blocks = array())
    {
        $__internal_52913a0f7e8a0ddbff3d37bafac7a509dbdd7912f198241e10ce629cb172ab97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52913a0f7e8a0ddbff3d37bafac7a509dbdd7912f198241e10ce629cb172ab97->enter($__internal_52913a0f7e8a0ddbff3d37bafac7a509dbdd7912f198241e10ce629cb172ab97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "banner"));

        $__internal_9cf20f71c91232f2e537641f6bde99867577996dd1ba64562a84288a745282c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cf20f71c91232f2e537641f6bde99867577996dd1ba64562a84288a745282c5->enter($__internal_9cf20f71c91232f2e537641f6bde99867577996dd1ba64562a84288a745282c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "banner"));

        echo " Recettes ";
        
        $__internal_9cf20f71c91232f2e537641f6bde99867577996dd1ba64562a84288a745282c5->leave($__internal_9cf20f71c91232f2e537641f6bde99867577996dd1ba64562a84288a745282c5_prof);

        
        $__internal_52913a0f7e8a0ddbff3d37bafac7a509dbdd7912f198241e10ce629cb172ab97->leave($__internal_52913a0f7e8a0ddbff3d37bafac7a509dbdd7912f198241e10ce629cb172ab97_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_d4005b8f99c5e2568c5dd39541b27b082563f179660bf277f3b37df082003503 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4005b8f99c5e2568c5dd39541b27b082563f179660bf277f3b37df082003503->enter($__internal_d4005b8f99c5e2568c5dd39541b27b082563f179660bf277f3b37df082003503_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_af7c9d2321f4c1070c83674d37a7324ca5a817451b78675e612052b16fe78f79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af7c9d2321f4c1070c83674d37a7324ca5a817451b78675e612052b16fe78f79->enter($__internal_af7c9d2321f4c1070c83674d37a7324ca5a817451b78675e612052b16fe78f79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "    ";
        // line 11
        echo "
    <div style=\"background-color: #f2f2f2; margin-bottom: 25px\">
        <span style=\" font-family: Futura; font-size: 20px; margin-left: 20px; font-weight: bold\">Filtrer: </span>

        <span class=\"dropdown\">

          <button class=\"filter dropdown-toggle\" type=\"button\" data-toggle=\"dropdown\">Catégorie
            <span class=\"caret\"></span></button>
            ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), 'form_start', array("attr" => array("class" => "dropdown-menu", "id" => "catefilter", "method" => "POST")));
        echo "
            <span style=\"font-family: Futura; margin-top: 7px\">Choisir la catégorie</span><br>
            <div>
                ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat0", array()), 'widget', array("attr" => array("style" => "margin-top: 15px", "name" => "critere")));
        echo "
                ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat0", array()), 'label', array("label" => "Entrée"));
        echo "<br>
                ";
        // line 24
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat1", array()), 'widget', array("attr" => array("name" => "critere")));
        echo "
                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat1", array()), 'label', array("label" => "Plat"));
        echo "<br>
                ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat2", array()), 'widget', array("attr" => array("name" => "critere")));
        echo "
                ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat2", array()), 'label', array("label" => "Dessert"));
        echo "<br>
                ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat3", array()), 'widget', array("attr" => array("name" => "critere")));
        echo "
                ";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat3", array()), 'label', array("label" => "Boisson"));
        echo "<br>
                ";
        // line 30
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat4", array()), 'widget', array("attr" => array("name" => "critere")));
        echo "
                ";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat4", array()), 'label', array("label" => "Soupe"));
        echo "<br>
                ";
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat5", array()), 'widget', array("attr" => array("name" => "critere")));
        echo "
                ";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "cat5", array()), 'label', array("label" => "Sauce"));
        echo "<br>
            </div>
            ";
        // line 35
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), "filtrer", array()), 'widget');
        echo "
            <button class=\"cancel\" type=\"button\" id=\"annulercate\">Annuler</button>
            ";
        // line 37
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["catefilter"]) ? $context["catefilter"] : $this->getContext($context, "catefilter")), 'form_end');
        echo "
        </span>


        <span class=\"dropdown\">
            <button class=\"filter dropdown-toggle\" type=\"button\" data-toggle=\"dropdown\">Date
                <span class=\"caret\"></span></button>
            ";
        // line 44
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["date"]) ? $context["date"] : $this->getContext($context, "date")), 'form_start', array("attr" => array("class" => "dropdown-menu")));
        echo "
            ";
        // line 45
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["date"]) ? $context["date"] : $this->getContext($context, "date")), 'errors');
        echo "
            <span style=\"font-family: Futura; margin-top: 7px\">Jour/mois/année</span><br>
            ";
        // line 47
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["date"]) ? $context["date"] : $this->getContext($context, "date")), 'errors');
        echo "
            ";
        // line 48
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["date"]) ? $context["date"] : $this->getContext($context, "date")), "date", array()), 'widget', array("attr" => array("style" => "margin-top: 15px")));
        echo "
            ";
        // line 49
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["date"]) ? $context["date"] : $this->getContext($context, "date")), "choose", array()), 'widget', array("attr" => array("value" => "Valider")));
        echo "
            ";
        // line 50
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["date"]) ? $context["date"] : $this->getContext($context, "date")), 'form_end');
        echo "
        </span>
    </div>

    ";
        // line 55
        echo "
    ";
        // line 57
        echo "    ";
        if ( !twig_test_empty((isset($context["resultCate"]) ? $context["resultCate"] : $this->getContext($context, "resultCate")))) {
            // line 58
            echo "        <span style=\"font-family: Verdana; font-weight: bold; font-size: 22px; margin: 0px 0px 30px 25px; text-decoration: underline\">Résultat filtré par Catégorie </span><br>
        <div style=\"background-color: #1b6d85\">
            ";
            // line 60
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["resultCate"]) ? $context["resultCate"] : $this->getContext($context, "resultCate")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["src"]) {
                // line 61
                echo "                <p style=\"margin-top: 30px\"></p>
                ";
                // line 62
                if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 1)) {
                    // line 63
                    echo "                    <div class=\"col-sm-2\"></div>
                ";
                }
                // line 65
                echo "                <div class=\"col-sm-2 imgdiv\">
                    <a class=\"avideo\" href=\"";
                // line 66
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["src"], "id", array()))), "html", null, true);
                echo "\">
                        <img class=\"thumb\" width=\"380\" height=\"200\" src=\"";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute($context["src"], "thumb", array()), "html", null, true);
                echo "\">
                        <div class=\"titrerecette\">";
                // line 68
                echo twig_escape_filter($this->env, $this->getAttribute($context["src"], "title", array()), "html", null, true);
                echo "</div>
                    </a>
                </div>
                ";
                // line 71
                if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 0)) {
                    // line 72
                    echo "                    <div class=\"col-sm-2\"></div>
                    <div class=\"col-sm-12\"></div>
                ";
                }
                // line 75
                echo "            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['src'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 76
            echo "        </div>
    ";
        }
        // line 78
        echo "
    ";
        // line 80
        echo "
    ";
        // line 82
        echo "    ";
        if (((((isset($context["resultDate"]) ? $context["resultDate"] : $this->getContext($context, "resultDate")) != "") && ((isset($context["resultDate"]) ? $context["resultDate"] : $this->getContext($context, "resultDate")) != null)) && twig_test_empty((isset($context["resultCate"]) ? $context["resultCate"] : $this->getContext($context, "resultCate"))))) {
            // line 83
            echo "        <span style=\"font-family: Verdana; font-weight: bold; font-size: 22px; margin: 0px 0px 30px 25px; text-decoration: underline\">Résultat filtré par Date</span><br>
        <div style=\"background-color: #1b6d85\">
            ";
            // line 85
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["resultDate"]) ? $context["resultDate"] : $this->getContext($context, "resultDate")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                // line 86
                echo "                <p style=\"margin-top: 30px\"></p>
                ";
                // line 87
                if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 1)) {
                    // line 88
                    echo "                    <div class=\"col-sm-2\"></div>
                ";
                }
                // line 90
                echo "                <div class=\"col-sm-2 imgdiv\">
                    <a class=\"avideo\" href=\"";
                // line 91
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["res"], "id", array()))), "html", null, true);
                echo "\">
                        <img class=\"thumb\" width=\"380\" height=\"200\" src=\"";
                // line 92
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "thumb", array()), "html", null, true);
                echo "\">
                        <div class=\"titrerecette\">";
                // line 93
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "title", array()), "html", null, true);
                echo "</div>
                    </a>
                </div>
                ";
                // line 96
                if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 0)) {
                    // line 97
                    echo "                    <div class=\"col-sm-2\"></div>
                    <div class=\"col-sm-12\"></div>
                ";
                }
                // line 100
                echo "            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 101
            echo "        </div>
    ";
        }
        // line 103
        echo "
    ";
        // line 105
        echo "
    ";
        // line 107
        echo "    ";
        if (((twig_test_empty((isset($context["resultDate"]) ? $context["resultDate"] : $this->getContext($context, "resultDate"))) && ((isset($context["resultDate"]) ? $context["resultDate"] : $this->getContext($context, "resultDate")) != "")) && twig_test_empty((isset($context["resultCate"]) ? $context["resultCate"] : $this->getContext($context, "resultCate"))))) {
            // line 108
            echo "        <p style=\"text-align: center;font-family: Verdana; font-size: 22px; margin: 15px 0px 30px 25px; \">Aucun résultat :( </p><br>
    ";
        }
        // line 110
        echo "
    ";
        // line 112
        echo "
    ";
        // line 114
        echo "    ";
        if ((((isset($context["resultDate"]) ? $context["resultDate"] : $this->getContext($context, "resultDate")) == null) && twig_test_empty((isset($context["resultCate"]) ? $context["resultCate"] : $this->getContext($context, "resultCate"))))) {
            // line 115
            echo "        <div style=\"background-color: #1b6d85\">
            ";
            // line 116
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["all"]) ? $context["all"] : $this->getContext($context, "all")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["allvideos"]) {
                // line 117
                echo "                <p style=\"margin-top: 30px\"></p>
                ";
                // line 118
                if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 1)) {
                    // line 119
                    echo "                    <div class=\"col-sm-2\"></div>
                ";
                }
                // line 121
                echo "                <div class=\"col-sm-2 imgdiv\">
                    <a class=\"avideo\" href=\"";
                // line 122
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["allvideos"], "id", array()))), "html", null, true);
                echo "\">
                        <img class=\"thumb\" width=\"380\" height=\"200\" src=\"";
                // line 123
                echo twig_escape_filter($this->env, $this->getAttribute($context["allvideos"], "thumb", array()), "html", null, true);
                echo "\">
                        <div class=\"titrerecette\">";
                // line 124
                echo twig_escape_filter($this->env, $this->getAttribute($context["allvideos"], "title", array()), "html", null, true);
                echo "</div>
                    </a>
                </div>
                ";
                // line 127
                if ((($this->getAttribute($context["loop"], "index", array()) % 4) == 0)) {
                    // line 128
                    echo "                    <div class=\"col-sm-2\"></div>
                    <div class=\"col-sm-12\"></div>
                ";
                }
                // line 131
                echo "            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['allvideos'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 132
            echo "        </div>
    ";
        }
        // line 134
        echo "
";
        
        $__internal_af7c9d2321f4c1070c83674d37a7324ca5a817451b78675e612052b16fe78f79->leave($__internal_af7c9d2321f4c1070c83674d37a7324ca5a817451b78675e612052b16fe78f79_prof);

        
        $__internal_d4005b8f99c5e2568c5dd39541b27b082563f179660bf277f3b37df082003503->leave($__internal_d4005b8f99c5e2568c5dd39541b27b082563f179660bf277f3b37df082003503_prof);

    }

    public function getTemplateName()
    {
        return "ProjetMainBundle:Main:recette.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  449 => 134,  445 => 132,  431 => 131,  426 => 128,  424 => 127,  418 => 124,  414 => 123,  410 => 122,  407 => 121,  403 => 119,  401 => 118,  398 => 117,  381 => 116,  378 => 115,  375 => 114,  372 => 112,  369 => 110,  365 => 108,  362 => 107,  359 => 105,  356 => 103,  352 => 101,  338 => 100,  333 => 97,  331 => 96,  325 => 93,  321 => 92,  317 => 91,  314 => 90,  310 => 88,  308 => 87,  305 => 86,  288 => 85,  284 => 83,  281 => 82,  278 => 80,  275 => 78,  271 => 76,  257 => 75,  252 => 72,  250 => 71,  244 => 68,  240 => 67,  236 => 66,  233 => 65,  229 => 63,  227 => 62,  224 => 61,  207 => 60,  203 => 58,  200 => 57,  197 => 55,  190 => 50,  186 => 49,  182 => 48,  178 => 47,  173 => 45,  169 => 44,  159 => 37,  154 => 35,  149 => 33,  145 => 32,  141 => 31,  137 => 30,  133 => 29,  129 => 28,  125 => 27,  121 => 26,  117 => 25,  113 => 24,  109 => 23,  105 => 22,  99 => 19,  89 => 11,  87 => 10,  78 => 9,  60 => 7,  42 => 5,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#{% extends 'ProjetMainBundle:Main:layout.html.twig' %}#}

{% extends 'ProjetMainBundle:Main:layout.html.twig' %}

{% block title %} Recettes {% endblock %}

{% block banner %} Recettes {% endblock %}

{% block content %}
    {#========================#}

    <div style=\"background-color: #f2f2f2; margin-bottom: 25px\">
        <span style=\" font-family: Futura; font-size: 20px; margin-left: 20px; font-weight: bold\">Filtrer: </span>

        <span class=\"dropdown\">

          <button class=\"filter dropdown-toggle\" type=\"button\" data-toggle=\"dropdown\">Catégorie
            <span class=\"caret\"></span></button>
            {{ form_start(catefilter,{'attr': {'class':'dropdown-menu','id':'catefilter','method':'POST'}}) }}
            <span style=\"font-family: Futura; margin-top: 7px\">Choisir la catégorie</span><br>
            <div>
                {{ form_widget(catefilter.cat0,{'attr':{'style':'margin-top: 15px','name':'critere'}}) }}
                {{ form_label(catefilter.cat0,\"Entrée\") }}<br>
                {{ form_widget(catefilter.cat1,{'attr':{'name':'critere'}}) }}
                {{ form_label(catefilter.cat1,\"Plat\") }}<br>
                {{ form_widget(catefilter.cat2,{'attr':{'name':'critere'}}) }}
                {{ form_label(catefilter.cat2,\"Dessert\") }}<br>
                {{ form_widget(catefilter.cat3,{'attr':{'name':'critere'}}) }}
                {{ form_label(catefilter.cat3,\"Boisson\") }}<br>
                {{ form_widget(catefilter.cat4,{'attr':{'name':'critere'}}) }}
                {{ form_label(catefilter.cat4,\"Soupe\") }}<br>
                {{ form_widget(catefilter.cat5,{'attr':{'name':'critere'}}) }}
                {{ form_label(catefilter.cat5,\"Sauce\") }}<br>
            </div>
            {{ form_widget(catefilter.filtrer)}}
            <button class=\"cancel\" type=\"button\" id=\"annulercate\">Annuler</button>
            {{ form_end(catefilter) }}
        </span>


        <span class=\"dropdown\">
            <button class=\"filter dropdown-toggle\" type=\"button\" data-toggle=\"dropdown\">Date
                <span class=\"caret\"></span></button>
            {{ form_start(date, {'attr': {'class':'dropdown-menu'}}) }}
            {{ form_errors(date) }}
            <span style=\"font-family: Futura; margin-top: 7px\">Jour/mois/année</span><br>
            {{ form_errors(date)}}
            {{ form_widget(date.date,{'attr':{'style':'margin-top: 15px'}}) }}
            {{ form_widget(date.choose,{'attr':{'value':'Valider'}}) }}
            {{ form_end(date) }}
        </span>
    </div>

    {#========================#}

    {# Show by category filter #}
    {% if resultCate is not empty %}
        <span style=\"font-family: Verdana; font-weight: bold; font-size: 22px; margin: 0px 0px 30px 25px; text-decoration: underline\">Résultat filtré par Catégorie </span><br>
        <div style=\"background-color: #1b6d85\">
            {% for src in resultCate %}
                <p style=\"margin-top: 30px\"></p>
                {% if loop.index % 4 == 1  %}
                    <div class=\"col-sm-2\"></div>
                {% endif %}
                <div class=\"col-sm-2 imgdiv\">
                    <a class=\"avideo\" href=\"{{ path('projet_main_show_video',{'id':src.id}) }}\">
                        <img class=\"thumb\" width=\"380\" height=\"200\" src=\"{{ src.thumb }}\">
                        <div class=\"titrerecette\">{{ src.title }}</div>
                    </a>
                </div>
                {% if loop.index % 4 == 0 %}
                    <div class=\"col-sm-2\"></div>
                    <div class=\"col-sm-12\"></div>
                {% endif %}
            {% endfor %}
        </div>
    {% endif %}

    {#==============================#}

    {# Show by date filter #}
    {% if resultDate != '' and resultDate != null and resultCate is empty %}
        <span style=\"font-family: Verdana; font-weight: bold; font-size: 22px; margin: 0px 0px 30px 25px; text-decoration: underline\">Résultat filtré par Date</span><br>
        <div style=\"background-color: #1b6d85\">
            {% for res in resultDate %}
                <p style=\"margin-top: 30px\"></p>
                {% if loop.index % 4 == 1  %}
                    <div class=\"col-sm-2\"></div>
                {% endif %}
                <div class=\"col-sm-2 imgdiv\">
                    <a class=\"avideo\" href=\"{{ path('projet_main_show_video',{'id':res.id}) }}\">
                        <img class=\"thumb\" width=\"380\" height=\"200\" src=\"{{ res.thumb }}\">
                        <div class=\"titrerecette\">{{ res.title }}</div>
                    </a>
                </div>
                {% if loop.index % 4 == 0 %}
                    <div class=\"col-sm-2\"></div>
                    <div class=\"col-sm-12\"></div>
                {% endif %}
            {% endfor %}
        </div>
    {% endif %}

    {#====================================#}

    {# Can not find result #}
    {% if resultDate is empty and resultDate != '' and resultCate is empty %}
        <p style=\"text-align: center;font-family: Verdana; font-size: 22px; margin: 15px 0px 30px 25px; \">Aucun résultat :( </p><br>
    {% endif %}

    {#====================================#}

    {# Show all by default #}
    {% if resultDate == null and resultCate is empty %}
        <div style=\"background-color: #1b6d85\">
            {% for allvideos in all %}
                <p style=\"margin-top: 30px\"></p>
                {% if loop.index % 4 == 1  %}
                    <div class=\"col-sm-2\"></div>
                {% endif %}
                <div class=\"col-sm-2 imgdiv\">
                    <a class=\"avideo\" href=\"{{ path('projet_main_show_video',{'id':allvideos.id}) }}\">
                        <img class=\"thumb\" width=\"380\" height=\"200\" src=\"{{ allvideos.thumb }}\">
                        <div class=\"titrerecette\">{{ allvideos.title }}</div>
                    </a>
                </div>
                {% if loop.index % 4 == 0 %}
                    <div class=\"col-sm-2\"></div>
                    <div class=\"col-sm-12\"></div>
                {% endif %}
            {% endfor %}
        </div>
    {% endif %}

{% endblock %}", "ProjetMainBundle:Main:recette.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/MainBundle/Resources/views/Main/recette.html.twig");
    }
}
