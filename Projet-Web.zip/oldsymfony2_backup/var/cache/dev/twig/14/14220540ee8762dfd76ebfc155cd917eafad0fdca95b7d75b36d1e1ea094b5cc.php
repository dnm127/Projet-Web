<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_be6f5450bdf227f78846ae92299417baac69ae4615caa5d19477ba97dd5d00f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a955f269d8f63b8dd42b7e2c927bd167cd6ca1c896eb195ab545e82c422c281f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a955f269d8f63b8dd42b7e2c927bd167cd6ca1c896eb195ab545e82c422c281f->enter($__internal_a955f269d8f63b8dd42b7e2c927bd167cd6ca1c896eb195ab545e82c422c281f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_f4990d9558d2be9a95c9e8bd90717baf5aaba23af38c12e59d0b3384866eb8da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4990d9558d2be9a95c9e8bd90717baf5aaba23af38c12e59d0b3384866eb8da->enter($__internal_f4990d9558d2be9a95c9e8bd90717baf5aaba23af38c12e59d0b3384866eb8da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_a955f269d8f63b8dd42b7e2c927bd167cd6ca1c896eb195ab545e82c422c281f->leave($__internal_a955f269d8f63b8dd42b7e2c927bd167cd6ca1c896eb195ab545e82c422c281f_prof);

        
        $__internal_f4990d9558d2be9a95c9e8bd90717baf5aaba23af38c12e59d0b3384866eb8da->leave($__internal_f4990d9558d2be9a95c9e8bd90717baf5aaba23af38c12e59d0b3384866eb8da_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
