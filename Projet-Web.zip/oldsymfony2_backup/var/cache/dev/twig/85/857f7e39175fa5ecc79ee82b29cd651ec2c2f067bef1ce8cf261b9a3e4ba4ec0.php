<?php

/* FOSUserBundle:Group:show_content.html.twig */
class __TwigTemplate_bd911bbadb5f67c77533d53eb502e8de4133c86e8aa1fed134858c91aaa3f6e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_339ed185dd08aca46a055e092d7d3a08b6d9a2f4d9e1840398f6f3dd40549765 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_339ed185dd08aca46a055e092d7d3a08b6d9a2f4d9e1840398f6f3dd40549765->enter($__internal_339ed185dd08aca46a055e092d7d3a08b6d9a2f4d9e1840398f6f3dd40549765_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show_content.html.twig"));

        $__internal_5399599d3e19007780f96cc99aa1a73d035a74f40afa9ea7b67a7f7249f5d306 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5399599d3e19007780f96cc99aa1a73d035a74f40afa9ea7b67a7f7249f5d306->enter($__internal_5399599d3e19007780f96cc99aa1a73d035a74f40afa9ea7b67a7f7249f5d306_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_group_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("group.show.name", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "getName", array(), "method"), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_339ed185dd08aca46a055e092d7d3a08b6d9a2f4d9e1840398f6f3dd40549765->leave($__internal_339ed185dd08aca46a055e092d7d3a08b6d9a2f4d9e1840398f6f3dd40549765_prof);

        
        $__internal_5399599d3e19007780f96cc99aa1a73d035a74f40afa9ea7b67a7f7249f5d306->leave($__internal_5399599d3e19007780f96cc99aa1a73d035a74f40afa9ea7b67a7f7249f5d306_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 4,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"fos_user_group_show\">
    <p>{{ 'group.show.name'|trans }}: {{ group.getName() }}</p>
</div>
", "FOSUserBundle:Group:show_content.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Group/show_content.html.twig");
    }
}
