<?php

/* FOSUserBundle:Registration:check_email.html.twig */
class __TwigTemplate_4521c73a9b73a08386631c4fc7c738c44c37cdce8552ee94b00425d731e62055 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d65cf8c173f19684c3a3812104dca15a978b76c3f28afcb1140bdda54b8979d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d65cf8c173f19684c3a3812104dca15a978b76c3f28afcb1140bdda54b8979d->enter($__internal_6d65cf8c173f19684c3a3812104dca15a978b76c3f28afcb1140bdda54b8979d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $__internal_9005725d9d46132a34ce6a4d153530d4754eee4b2ad62b4803d8586cd8c69c50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9005725d9d46132a34ce6a4d153530d4754eee4b2ad62b4803d8586cd8c69c50->enter($__internal_9005725d9d46132a34ce6a4d153530d4754eee4b2ad62b4803d8586cd8c69c50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6d65cf8c173f19684c3a3812104dca15a978b76c3f28afcb1140bdda54b8979d->leave($__internal_6d65cf8c173f19684c3a3812104dca15a978b76c3f28afcb1140bdda54b8979d_prof);

        
        $__internal_9005725d9d46132a34ce6a4d153530d4754eee4b2ad62b4803d8586cd8c69c50->leave($__internal_9005725d9d46132a34ce6a4d153530d4754eee4b2ad62b4803d8586cd8c69c50_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_16a3d8ae0b090f677da846933a980822d02f49b8cc484345ece83c42d7c41249 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16a3d8ae0b090f677da846933a980822d02f49b8cc484345ece83c42d7c41249->enter($__internal_16a3d8ae0b090f677da846933a980822d02f49b8cc484345ece83c42d7c41249_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_8ca063c2d5943c49e1b5d500176b3385e21762ef3dbead62fe563c9146e4faf9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ca063c2d5943c49e1b5d500176b3385e21762ef3dbead62fe563c9146e4faf9->enter($__internal_8ca063c2d5943c49e1b5d500176b3385e21762ef3dbead62fe563c9146e4faf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_8ca063c2d5943c49e1b5d500176b3385e21762ef3dbead62fe563c9146e4faf9->leave($__internal_8ca063c2d5943c49e1b5d500176b3385e21762ef3dbead62fe563c9146e4faf9_prof);

        
        $__internal_16a3d8ae0b090f677da846933a980822d02f49b8cc484345ece83c42d7c41249->leave($__internal_16a3d8ae0b090f677da846933a980822d02f49b8cc484345ece83c42d7c41249_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:check_email.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/check_email.html.twig");
    }
}
