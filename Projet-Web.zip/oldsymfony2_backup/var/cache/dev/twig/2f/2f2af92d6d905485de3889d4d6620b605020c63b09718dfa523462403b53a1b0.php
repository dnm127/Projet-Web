<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_529cbeb72dcdf32bf312a0ea147c6e74336b68fd9e650fafae0e2d0fe72da4ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f73d3e32d2dc3437937aa1e39e92d5ac98b66559f0ad4aafb5f4c7215768585b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f73d3e32d2dc3437937aa1e39e92d5ac98b66559f0ad4aafb5f4c7215768585b->enter($__internal_f73d3e32d2dc3437937aa1e39e92d5ac98b66559f0ad4aafb5f4c7215768585b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $__internal_d24f6415999e2ffedb9e8fc01afaed295cfddf4539ce9e07c7b085d066c6a455 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d24f6415999e2ffedb9e8fc01afaed295cfddf4539ce9e07c7b085d066c6a455->enter($__internal_d24f6415999e2ffedb9e8fc01afaed295cfddf4539ce9e07c7b085d066c6a455_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f73d3e32d2dc3437937aa1e39e92d5ac98b66559f0ad4aafb5f4c7215768585b->leave($__internal_f73d3e32d2dc3437937aa1e39e92d5ac98b66559f0ad4aafb5f4c7215768585b_prof);

        
        $__internal_d24f6415999e2ffedb9e8fc01afaed295cfddf4539ce9e07c7b085d066c6a455->leave($__internal_d24f6415999e2ffedb9e8fc01afaed295cfddf4539ce9e07c7b085d066c6a455_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_7f455055ed822d20ef977d15ea03bbfb52c1a8a9a4f9db7dc021013f5b006155 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f455055ed822d20ef977d15ea03bbfb52c1a8a9a4f9db7dc021013f5b006155->enter($__internal_7f455055ed822d20ef977d15ea03bbfb52c1a8a9a4f9db7dc021013f5b006155_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_a72d7db8d7968a2f5261f566c62bdc4b619ec578bb008ee06f2294ecbb96a06e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a72d7db8d7968a2f5261f566c62bdc4b619ec578bb008ee06f2294ecbb96a06e->enter($__internal_a72d7db8d7968a2f5261f566c62bdc4b619ec578bb008ee06f2294ecbb96a06e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_a72d7db8d7968a2f5261f566c62bdc4b619ec578bb008ee06f2294ecbb96a06e->leave($__internal_a72d7db8d7968a2f5261f566c62bdc4b619ec578bb008ee06f2294ecbb96a06e_prof);

        
        $__internal_7f455055ed822d20ef977d15ea03bbfb52c1a8a9a4f9db7dc021013f5b006155->leave($__internal_7f455055ed822d20ef977d15ea03bbfb52c1a8a9a4f9db7dc021013f5b006155_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/new_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:new.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/friendsofsymfony/user-bundle/Resources/views/Group/new.html.twig");
    }
}
