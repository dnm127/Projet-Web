<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_1e13c40454134db750135f25a4d78b75f0a6cb68d947d6805c392a1ef958659f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1323a37daa36e6adf66eb3dbd89926847bb35bd4f2b25daae74e5dcb06bb65fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1323a37daa36e6adf66eb3dbd89926847bb35bd4f2b25daae74e5dcb06bb65fa->enter($__internal_1323a37daa36e6adf66eb3dbd89926847bb35bd4f2b25daae74e5dcb06bb65fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_d5fa2c35fe5c464c17965c53ad4c02b9632b58fa0fe57a9a938f38dea841ce9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5fa2c35fe5c464c17965c53ad4c02b9632b58fa0fe57a9a938f38dea841ce9c->enter($__internal_d5fa2c35fe5c464c17965c53ad4c02b9632b58fa0fe57a9a938f38dea841ce9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_1323a37daa36e6adf66eb3dbd89926847bb35bd4f2b25daae74e5dcb06bb65fa->leave($__internal_1323a37daa36e6adf66eb3dbd89926847bb35bd4f2b25daae74e5dcb06bb65fa_prof);

        
        $__internal_d5fa2c35fe5c464c17965c53ad4c02b9632b58fa0fe57a9a938f38dea841ce9c->leave($__internal_d5fa2c35fe5c464c17965c53ad4c02b9632b58fa0fe57a9a938f38dea841ce9c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/button_row.html.php");
    }
}
