<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0daaa3d5cfd073d06a3840dd526eb53dc2929fac357308915d14d50f05ae0819 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_08952d6c7a28dce2d9438bcf3733cf1241fe50e311621f7038708046e4e8f853 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08952d6c7a28dce2d9438bcf3733cf1241fe50e311621f7038708046e4e8f853->enter($__internal_08952d6c7a28dce2d9438bcf3733cf1241fe50e311621f7038708046e4e8f853_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_9e3308a2d6494f413ad6333a3a0203ef1435a2f157641c300df8634a7ec5cfc7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e3308a2d6494f413ad6333a3a0203ef1435a2f157641c300df8634a7ec5cfc7->enter($__internal_9e3308a2d6494f413ad6333a3a0203ef1435a2f157641c300df8634a7ec5cfc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_08952d6c7a28dce2d9438bcf3733cf1241fe50e311621f7038708046e4e8f853->leave($__internal_08952d6c7a28dce2d9438bcf3733cf1241fe50e311621f7038708046e4e8f853_prof);

        
        $__internal_9e3308a2d6494f413ad6333a3a0203ef1435a2f157641c300df8634a7ec5cfc7->leave($__internal_9e3308a2d6494f413ad6333a3a0203ef1435a2f157641c300df8634a7ec5cfc7_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_e46968f6b71f88aa187ad68d5c21cd1305d22b9ef8bb9264a18546a359ed081f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e46968f6b71f88aa187ad68d5c21cd1305d22b9ef8bb9264a18546a359ed081f->enter($__internal_e46968f6b71f88aa187ad68d5c21cd1305d22b9ef8bb9264a18546a359ed081f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_0a858b6a727e928f5ff4285ce26863c2a3fc0695f1e425e58179771cd72b918c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a858b6a727e928f5ff4285ce26863c2a3fc0695f1e425e58179771cd72b918c->enter($__internal_0a858b6a727e928f5ff4285ce26863c2a3fc0695f1e425e58179771cd72b918c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_0a858b6a727e928f5ff4285ce26863c2a3fc0695f1e425e58179771cd72b918c->leave($__internal_0a858b6a727e928f5ff4285ce26863c2a3fc0695f1e425e58179771cd72b918c_prof);

        
        $__internal_e46968f6b71f88aa187ad68d5c21cd1305d22b9ef8bb9264a18546a359ed081f->leave($__internal_e46968f6b71f88aa187ad68d5c21cd1305d22b9ef8bb9264a18546a359ed081f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_4a47d92e83e8e3637dbfe3cf4a9710557e971f0b859df811526c32c3f2a210bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4a47d92e83e8e3637dbfe3cf4a9710557e971f0b859df811526c32c3f2a210bf->enter($__internal_4a47d92e83e8e3637dbfe3cf4a9710557e971f0b859df811526c32c3f2a210bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_27fdfbf1f2dbf0296a20498ee72273a1642cf81a5f3d896f6f7fc8233fc3a1c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27fdfbf1f2dbf0296a20498ee72273a1642cf81a5f3d896f6f7fc8233fc3a1c9->enter($__internal_27fdfbf1f2dbf0296a20498ee72273a1642cf81a5f3d896f6f7fc8233fc3a1c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_27fdfbf1f2dbf0296a20498ee72273a1642cf81a5f3d896f6f7fc8233fc3a1c9->leave($__internal_27fdfbf1f2dbf0296a20498ee72273a1642cf81a5f3d896f6f7fc8233fc3a1c9_prof);

        
        $__internal_4a47d92e83e8e3637dbfe3cf4a9710557e971f0b859df811526c32c3f2a210bf->leave($__internal_4a47d92e83e8e3637dbfe3cf4a9710557e971f0b859df811526c32c3f2a210bf_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_23538a44dc9756ca9cc119d997f58e3531db35aad687036a49c9d6294cc75a8a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_23538a44dc9756ca9cc119d997f58e3531db35aad687036a49c9d6294cc75a8a->enter($__internal_23538a44dc9756ca9cc119d997f58e3531db35aad687036a49c9d6294cc75a8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_13f06c5eb9dc13d755d77c1a8d129fcfa45ed947b59f0d583cf492ab4fa9df2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13f06c5eb9dc13d755d77c1a8d129fcfa45ed947b59f0d583cf492ab4fa9df2d->enter($__internal_13f06c5eb9dc13d755d77c1a8d129fcfa45ed947b59f0d583cf492ab4fa9df2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_13f06c5eb9dc13d755d77c1a8d129fcfa45ed947b59f0d583cf492ab4fa9df2d->leave($__internal_13f06c5eb9dc13d755d77c1a8d129fcfa45ed947b59f0d583cf492ab4fa9df2d_prof);

        
        $__internal_23538a44dc9756ca9cc119d997f58e3531db35aad687036a49c9d6294cc75a8a->leave($__internal_23538a44dc9756ca9cc119d997f58e3531db35aad687036a49c9d6294cc75a8a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
