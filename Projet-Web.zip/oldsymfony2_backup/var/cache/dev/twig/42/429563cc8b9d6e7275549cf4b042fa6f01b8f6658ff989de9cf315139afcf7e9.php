<?php

/* ProjetUserBundle:Security:content_user.html.twig */
class __TwigTemplate_b55dbc1704a130c9925980e66fe887eb18cb4379d79bc4e884656516dbb6f82b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("ProjetMainBundle:Main:layout.html.twig", "ProjetUserBundle:Security:content_user.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ProjetMainBundle:Main:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca6959ab9b3a79354e1abb7ee29a1f1f052752ca9cc70cf499376f3cbeb7603c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca6959ab9b3a79354e1abb7ee29a1f1f052752ca9cc70cf499376f3cbeb7603c->enter($__internal_ca6959ab9b3a79354e1abb7ee29a1f1f052752ca9cc70cf499376f3cbeb7603c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:content_user.html.twig"));

        $__internal_4317961d3183cebb28dea3d1370c0b03312dc2ae80778c7289ce1f4ea28ac4b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4317961d3183cebb28dea3d1370c0b03312dc2ae80778c7289ce1f4ea28ac4b2->enter($__internal_4317961d3183cebb28dea3d1370c0b03312dc2ae80778c7289ce1f4ea28ac4b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProjetUserBundle:Security:content_user.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ca6959ab9b3a79354e1abb7ee29a1f1f052752ca9cc70cf499376f3cbeb7603c->leave($__internal_ca6959ab9b3a79354e1abb7ee29a1f1f052752ca9cc70cf499376f3cbeb7603c_prof);

        
        $__internal_4317961d3183cebb28dea3d1370c0b03312dc2ae80778c7289ce1f4ea28ac4b2->leave($__internal_4317961d3183cebb28dea3d1370c0b03312dc2ae80778c7289ce1f4ea28ac4b2_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_9b349e01834bd18661852b5c5ef8a3a910d73b35c7963b8e01ef470b4157c454 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b349e01834bd18661852b5c5ef8a3a910d73b35c7963b8e01ef470b4157c454->enter($__internal_9b349e01834bd18661852b5c5ef8a3a910d73b35c7963b8e01ef470b4157c454_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_fceb7dbf5dfd8128087c7eb7767013dcd0ed076b5f2d532c95414145089abe48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fceb7dbf5dfd8128087c7eb7767013dcd0ed076b5f2d532c95414145089abe48->enter($__internal_fceb7dbf5dfd8128087c7eb7767013dcd0ed076b5f2d532c95414145089abe48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
    ";
        // line 5
        if (((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")) == $this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()))) {
            echo " ";
            // line 6
            echo "        <div style=\"padding-top: 40px; padding-bottom: 30px; text-align: center; \" class=\"col-sm-3\">
            <img id=\"avatar\" width=\"220\" height=\"220\" src=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/profilepic.png"), "html", null, true);
            echo "\">
            <div id=\"usrname\"> ";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
            echo "</div>
            <a id=\"aboutcollapse\" data-toggle=\"collapse\" href=\"#usrintro\">Profil</a>
            <button id=\"changeabout\" onclick=\"notice()\"><span class=\"glyphicon glyphicon-wrench\"></span></button>
            ";
            // line 11
            echo             $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["about"]) ? $context["about"] : $this->getContext($context, "about")), 'form_start', array("attr" => array("id" => "formabout")));
            echo "
            ";
            // line 12
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["about"]) ? $context["about"] : $this->getContext($context, "about")), 'errors');
            echo "
            ";
            // line 13
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["about"]) ? $context["about"] : $this->getContext($context, "about")), "text", array()), 'widget', array("attr" => array("style" => "resize:none; margin-top:10px; margin-right:10px; width:100%", "maxlength" => "100", "rows" => "5")));
            echo "<br>
            ";
            // line 14
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["about"]) ? $context["about"] : $this->getContext($context, "about")), "save", array()), 'widget', array("attr" => array("onclick" => "notice()")));
            echo "
            ";
            // line 15
            echo             $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["about"]) ? $context["about"] : $this->getContext($context, "about")), 'form_end');
            echo "
            <div id=\"notice\"></div>
            <div align=\"left\" class=\"collapse in col-sm-12\" id=\"usrintro\">
                ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "about", array()), "html", null, true);
            echo "
            </div>
        </div>
    ";
        } else {
            // line 22
            echo "        <div style=\"padding-top: 40px; padding-bottom: 30px; text-align: center; \" class=\"col-sm-3\">
            <img id=\"avatar\" width=\"220\" height=\"220\" src=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/profilepic.png"), "html", null, true);
            echo "\">
            <div id=\"usrname\"> ";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
            echo "</div>
            <a id=\"aboutcollapse\" data-toggle=\"collapse\" href=\"#usrintro\">Profil</a>
            ";
            // line 27
            echo "            <div align=\"left\" class=\"collapse in col-sm-12\" id=\"usrintro\">
                ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "about", array()), "html", null, true);
            echo "
            </div>
        </div>
    ";
        }
        // line 32
        echo "
<!-- Profile detail -->
    <div style=\" padding-top: 40px;\" class=\"col-sm-9\">

        <div class=\"tab\">
            <button id=\"default\" class=\"tablinks\" >Vidéos</button>
            <button id=\"liste\" class=\"tablinks\" >Vidéos aimées</button>
            ";
        // line 40
        echo "            ";
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) == (isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")))) {
            // line 41
            echo "            <a style=\"text-decoration: none; float: right\" href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_addvideo");
            echo "\"><button id=\"uploadbtn\"><i class=\"fa fa-cloud-upload\" style=\"font-size:20px\"></i> Déposer</button></a>
            ";
        }
        // line 43
        echo "        </div>

        <div id=\"videos\" class=\"tabcontent after\">
            <div class=\"col-sm-12\">
                ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["uploadedVideos"]) ? $context["uploadedVideos"] : $this->getContext($context, "uploadedVideos")));
        foreach ($context['_seq'] as $context["_key"] => $context["upload"]) {
            // line 48
            echo "                <div style=\"margin-bottom: 15px; border-radius: 10px\" class=\"col-sm-2\">
                    <a style=\"height: 70px; width: 100px; text-decoration: none; color: black\" href=\"";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["upload"], "id", array()))), "html", null, true);
            echo "\">
                        <img style=\"width: 100%; border-radius: 7px 7px 0px 0px\" src=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["upload"], "thumb", array()), "html", null, true);
            echo "\">
                        <div style=\"width: 100%; background-color: #66dd66; border-radius: 0px 0px 7px 7px; padding: 3px 5px 5px 5px; text-align: center; font-family: Pacifico \">";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["upload"], "title", array()), "html", null, true);
            echo "</div>
                    </a>
                </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['upload'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 55
        echo "            </div>

        </div>

        <div id=\"playlists\" class=\"tabcontent after\">
            <div class=\"col-sm-12\">
            ";
        // line 61
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "likedVideos", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["video"]) {
            // line 62
            echo "                <div style=\"margin-bottom: 15px; border-radius: 10px\" class=\"col-sm-2\">
                    <a style=\"height: 70px; width: 100px; text-decoration: none; color: black\" href=\"";
            // line 63
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_main_show_video", array("id" => $this->getAttribute($context["video"], "id", array()))), "html", null, true);
            echo "\">
                        <img style=\"width: 100%; border-radius: 7px 7px 0px 0px\" src=\"";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute($context["video"], "thumb", array()), "html", null, true);
            echo "\">
                        <div style=\"width: 100%; background-color: #66dd66; border-radius: 0px 0px 7px 7px; padding: 3px 5px 5px 5px; text-align: center; font-family: Pacifico \">";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($context["video"], "title", array()), "html", null, true);
            echo "</div>
                    </a>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['video'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "            </div>
        </div>
    </div>

    <div style=\"height: 40px\" class=\"col-sm-12\"></div>

";
        
        $__internal_fceb7dbf5dfd8128087c7eb7767013dcd0ed076b5f2d532c95414145089abe48->leave($__internal_fceb7dbf5dfd8128087c7eb7767013dcd0ed076b5f2d532c95414145089abe48_prof);

        
        $__internal_9b349e01834bd18661852b5c5ef8a3a910d73b35c7963b8e01ef470b4157c454->leave($__internal_9b349e01834bd18661852b5c5ef8a3a910d73b35c7963b8e01ef470b4157c454_prof);

    }

    public function getTemplateName()
    {
        return "ProjetUserBundle:Security:content_user.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 69,  191 => 65,  187 => 64,  183 => 63,  180 => 62,  176 => 61,  168 => 55,  158 => 51,  154 => 50,  150 => 49,  147 => 48,  143 => 47,  137 => 43,  131 => 41,  128 => 40,  119 => 32,  112 => 28,  109 => 27,  104 => 24,  100 => 23,  97 => 22,  90 => 18,  84 => 15,  80 => 14,  76 => 13,  72 => 12,  68 => 11,  62 => 8,  58 => 7,  55 => 6,  52 => 5,  49 => 4,  40 => 3,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src\\Projet\\MainBundle\\Resources\\views\\Main\\content_user.html.twig #}
{% extends 'ProjetMainBundle:Main:layout.html.twig' %}
{% block content %}

    {% if user == app.user %} {# if app.user viewing his own profile #}
        <div style=\"padding-top: 40px; padding-bottom: 30px; text-align: center; \" class=\"col-sm-3\">
            <img id=\"avatar\" width=\"220\" height=\"220\" src=\"{{ asset(\"img/profilepic.png\") }}\">
            <div id=\"usrname\"> {{ user.username }}</div>
            <a id=\"aboutcollapse\" data-toggle=\"collapse\" href=\"#usrintro\">Profil</a>
            <button id=\"changeabout\" onclick=\"notice()\"><span class=\"glyphicon glyphicon-wrench\"></span></button>
            {{ form_start(about,{'attr':{'id':'formabout'}}) }}
            {{ form_errors(about) }}
            {{ form_widget(about.text,{'attr':{'style':'resize:none; margin-top:10px; margin-right:10px; width:100%','maxlength':'100','rows':'5'}}) }}<br>
            {{ form_widget(about.save,{'attr':{'onclick':'notice()'}}) }}
            {{ form_end(about) }}
            <div id=\"notice\"></div>
            <div align=\"left\" class=\"collapse in col-sm-12\" id=\"usrintro\">
                {{ user.about }}
            </div>
        </div>
    {% else %}
        <div style=\"padding-top: 40px; padding-bottom: 30px; text-align: center; \" class=\"col-sm-3\">
            <img id=\"avatar\" width=\"220\" height=\"220\" src=\"{{ asset(\"img/profilepic.png\") }}\">
            <div id=\"usrname\"> {{ user.username }}</div>
            <a id=\"aboutcollapse\" data-toggle=\"collapse\" href=\"#usrintro\">Profil</a>
            {#<div id=\"notice\"></div>#}
            <div align=\"left\" class=\"collapse in col-sm-12\" id=\"usrintro\">
                {{ user.about }}
            </div>
        </div>
    {% endif %}

<!-- Profile detail -->
    <div style=\" padding-top: 40px;\" class=\"col-sm-9\">

        <div class=\"tab\">
            <button id=\"default\" class=\"tablinks\" >Vidéos</button>
            <button id=\"liste\" class=\"tablinks\" >Vidéos aimées</button>
            {# TODO only upload if app.user == user #}
            {% if app.user == user %}
            <a style=\"text-decoration: none; float: right\" href=\"{{ path('projet_main_addvideo') }}\"><button id=\"uploadbtn\"><i class=\"fa fa-cloud-upload\" style=\"font-size:20px\"></i> Déposer</button></a>
            {% endif %}
        </div>

        <div id=\"videos\" class=\"tabcontent after\">
            <div class=\"col-sm-12\">
                {% for upload in uploadedVideos %}
                <div style=\"margin-bottom: 15px; border-radius: 10px\" class=\"col-sm-2\">
                    <a style=\"height: 70px; width: 100px; text-decoration: none; color: black\" href=\"{{ path('projet_main_show_video',{'id':upload.id}) }}\">
                        <img style=\"width: 100%; border-radius: 7px 7px 0px 0px\" src=\"{{ upload.thumb }}\">
                        <div style=\"width: 100%; background-color: #66dd66; border-radius: 0px 0px 7px 7px; padding: 3px 5px 5px 5px; text-align: center; font-family: Pacifico \">{{ upload.title }}</div>
                    </a>
                </div>
                {% endfor %}
            </div>

        </div>

        <div id=\"playlists\" class=\"tabcontent after\">
            <div class=\"col-sm-12\">
            {% for video in user.likedVideos %}
                <div style=\"margin-bottom: 15px; border-radius: 10px\" class=\"col-sm-2\">
                    <a style=\"height: 70px; width: 100px; text-decoration: none; color: black\" href=\"{{ path('projet_main_show_video',{'id':video.id}) }}\">
                        <img style=\"width: 100%; border-radius: 7px 7px 0px 0px\" src=\"{{video.thumb }}\">
                        <div style=\"width: 100%; background-color: #66dd66; border-radius: 0px 0px 7px 7px; padding: 3px 5px 5px 5px; text-align: center; font-family: Pacifico \">{{ video.title }}</div>
                    </a>
                </div>
            {% endfor %}
            </div>
        </div>
    </div>

    <div style=\"height: 40px\" class=\"col-sm-12\"></div>

{% endblock %}


", "ProjetUserBundle:Security:content_user.html.twig", "/Users/dang/Desktop/oldsymfony2_backup/src/Projet/UserBundle/Resources/views/Security/content_user.html.twig");
    }
}
