<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_793fcd2aed26a2b746548aa73c8cc7942f31c45e17af99a41450763a65fbf2ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc9b7234c41c1f174acec2e9690ee55fe8e6e5256ac60d876e542aa15c35ce29 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc9b7234c41c1f174acec2e9690ee55fe8e6e5256ac60d876e542aa15c35ce29->enter($__internal_bc9b7234c41c1f174acec2e9690ee55fe8e6e5256ac60d876e542aa15c35ce29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_c47f8d5fa3175d11b03bf80d26614371ccb71a23b807076a397def243b986140 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c47f8d5fa3175d11b03bf80d26614371ccb71a23b807076a397def243b986140->enter($__internal_c47f8d5fa3175d11b03bf80d26614371ccb71a23b807076a397def243b986140_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_bc9b7234c41c1f174acec2e9690ee55fe8e6e5256ac60d876e542aa15c35ce29->leave($__internal_bc9b7234c41c1f174acec2e9690ee55fe8e6e5256ac60d876e542aa15c35ce29_prof);

        
        $__internal_c47f8d5fa3175d11b03bf80d26614371ccb71a23b807076a397def243b986140->leave($__internal_c47f8d5fa3175d11b03bf80d26614371ccb71a23b807076a397def243b986140_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
