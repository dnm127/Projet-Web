<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_ec060f0c4a7de30cd6d80af9ff400491d9bc25f588142eaa55885b230cdf325b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_760b84f89baa540a7b9ddff2557c4c29aa13c4d1a39a21d636a72ab2436f6ace = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_760b84f89baa540a7b9ddff2557c4c29aa13c4d1a39a21d636a72ab2436f6ace->enter($__internal_760b84f89baa540a7b9ddff2557c4c29aa13c4d1a39a21d636a72ab2436f6ace_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_61fd9083850c8809a1a18acd9686f87fe64840bc0dedf5f659ce0ca1e0a180b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_61fd9083850c8809a1a18acd9686f87fe64840bc0dedf5f659ce0ca1e0a180b4->enter($__internal_61fd9083850c8809a1a18acd9686f87fe64840bc0dedf5f659ce0ca1e0a180b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_760b84f89baa540a7b9ddff2557c4c29aa13c4d1a39a21d636a72ab2436f6ace->leave($__internal_760b84f89baa540a7b9ddff2557c4c29aa13c4d1a39a21d636a72ab2436f6ace_prof);

        
        $__internal_61fd9083850c8809a1a18acd9686f87fe64840bc0dedf5f659ce0ca1e0a180b4->leave($__internal_61fd9083850c8809a1a18acd9686f87fe64840bc0dedf5f659ce0ca1e0a180b4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "/Users/dang/Desktop/oldsymfony2_backup/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
